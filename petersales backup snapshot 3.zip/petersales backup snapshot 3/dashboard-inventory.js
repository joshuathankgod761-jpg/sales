(() => {
  const rows = document.getElementById('inventory-rows');
  const search = document.getElementById('inventory-search');
  const filter = document.getElementById('inventory-filter');
  if (!rows || !search || !filter) return;

  let accounts = [];
  const escapeHtml = value => {
    const node = document.createElement('span');
    node.textContent = String(value ?? '');
    return node.innerHTML;
  };
  const render = () => {
    const term = search.value.trim().toLowerCase();
    const category = filter.value;
    const visible = accounts.filter(account => {
      const searchable = `${account.product_id} ${account.title} ${account.seller} ${account.server}`.toLowerCase();
      return (!term || searchable.includes(term)) && (category === 'all' || account.category === category);
    });
    rows.innerHTML = visible.length ? visible.map(account => {
      const sold = account.status === 'sold';
      const imagePath = String(account.image || '');
      const imageUrl = /^(https?:)?\/\//i.test(imagePath) || imagePath.startsWith('/') ? imagePath : `../${imagePath}`;
      return `<tr><td><div class="listing-cell"><img src="${escapeHtml(imageUrl)}" alt=""><span><strong>${escapeHtml(account.product_id || account.title)}</strong><small>Listing #${Number(account.id)} · ${escapeHtml(account.tier)} · Level ${Number(account.level)}</small></span></div></td><td>${escapeHtml(account.seller)}</td><td>${escapeHtml(account.server)}</td><td><strong>$${Number(account.price || 0).toFixed(2)}</strong></td><td><span class="status-pill ${sold ? 'sold-status' : 'active-status'}">${sold ? 'Sold' : 'Active'}</span></td><td><div class="inventory-row-actions"><button class="inventory-action" type="button" data-action="images" data-id="${Number(account.id)}">Add images (${Number(account.images?.length || 0)})</button><button class="inventory-action" type="button" data-action="status" data-status="${sold ? 'active' : 'sold'}" data-id="${Number(account.id)}">${sold ? 'Restore' : 'Mark sold'}</button><button class="inventory-action danger" type="button" data-action="delete" data-id="${Number(account.id)}">Delete</button></div></td></tr>`;
    }).join('') : '<tr><td colspan="6" class="table-empty">No listings match your search.</td></tr>';
    const summary = document.getElementById('inventory-summary');
    if (summary) summary.textContent = `Showing ${visible.length} of ${accounts.length} listings`;
    const active = document.getElementById('active-listings');
    if (active) active.textContent = accounts.filter(account => account.status !== 'sold').length;
    const navCount = document.getElementById('nav-inventory-count');
    if (navCount) navCount.textContent = accounts.length;
  };

  const load = async () => {
    try {
      const response = await fetch('../api/accounts.php', { cache: 'no-store', credentials: 'same-origin' });
      const result = await response.json();
      if (!response.ok || !result.ok) throw new Error(result.message || 'Could not load inventory.');
      accounts = result.accounts || [];
      render();
    } catch (error) {
      rows.innerHTML = `<tr><td colspan="6" class="table-empty">${escapeHtml(error.message || 'Could not load inventory.')}</td></tr>`;
      const summary = document.getElementById('inventory-summary');
      if (summary) summary.textContent = 'Inventory unavailable';
    }
  };

  search.addEventListener('input', render);
  filter.addEventListener('change', render);
  rows.addEventListener('click', async event => {
    const button = event.target.closest('button[data-action]');
    if (!button) return;
    const id = Number(button.dataset.id);
    if (button.dataset.action === 'delete' && !window.confirm('Delete this listing permanently?')) return;
    if (button.dataset.action === 'images') {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/png,image/jpeg,image/webp';
      input.multiple = true;
      input.onchange = async () => {
        if (!input.files?.length) return;
        const formData = new FormData();
        formData.set('action', 'images');
        formData.set('id', String(id));
        for (const file of input.files) formData.append('images[]', file);
        button.disabled = true;
        try {
          const response = await fetch('../api/accounts.php', { method: 'POST', body: formData });
          const result = await response.json();
          if (!response.ok || !result.ok) throw new Error(result.message || 'Could not update listing images.');
          accounts = accounts.map(account => Number(account.id) === id ? result.account : account);
          render();
        } catch (error) {
          button.disabled = false;
          window.alert(error.message || 'Could not update listing images.');
        }
      };
      input.click();
      return;
    }
    button.disabled = true;
    try {
      const action = button.dataset.action;
      const response = await fetch('../api/accounts.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: action === 'status' ? 'status' : 'delete', id, status: button.dataset.status })
      });
      const result = await response.json();
      if (!response.ok || !result.ok) throw new Error(result.message || 'Could not update listing.');
      accounts = action === 'delete' ? accounts.filter(account => Number(account.id) !== id) : accounts.map(account => Number(account.id) === id ? result.account : account);
      render();
    } catch (error) {
      button.disabled = false;
      window.alert(error.message || 'Could not update listing.');
    }
  });
  load();
  window.setInterval(load, 30000);
})();