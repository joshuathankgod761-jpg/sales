<?php
require_once __DIR__ . '/api/db.php';
petershop_db_bootstrap();
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
$orderId = trim((string) ($_GET['order'] ?? ''));
$orders = [];
foreach (petershop_orders_array() as $candidate) {
    if (isset($candidate['order_id']) && hash_equals((string) $candidate['order_id'], $orderId)) {
        $orders = $candidate;
        break;
    }
}
$accountCredentials = [];
if (($orders['status'] ?? '') === 'confirmed' && !empty($orders['product_id'])) {
    $accounts = petershop_listings_array();
    $matchedAccounts = [];
    foreach ($accounts as $account) {
        $matchesListing = !empty($orders['listing_id']) && (string) ($account['id'] ?? '') === (string) $orders['listing_id'];
        $matchesLegacyProduct = empty($orders['listing_id']) && (strtoupper((string) ($account['product_id'] ?? '')) === strtoupper((string) $orders['product_id']) || (ctype_digit((string) $orders['product_id']) && (string) ($account['id'] ?? '') === (string) $orders['product_id']));
        if ($matchesListing || $matchesLegacyProduct) $matchedAccounts[] = $account;
    }
    if (count($matchedAccounts) === 1) $accountCredentials = $matchedAccounts[0];
}
$approved = !empty($accountCredentials['game_email']) && !empty($accountCredentials['game_password']);
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Account delivery | Peter Shop</title>
  <style>
    * { box-sizing: border-box; }
    body { min-height: 100vh; margin: 0; display: grid; place-items: center; padding: 20px; background: #0a0c0e; color: #f4f6f7; font-family: 'DM Sans', Arial, sans-serif; }
    main { width: min(520px, 100%); padding: 32px; border: 1px solid rgba(255,255,255,.12); border-radius: 14px; background: #15191c; }
    .brand { margin-bottom: 24px; color: #d8ff3e; font-size: 13px; font-weight: 800; letter-spacing: .1em; }
    h1 { margin: 0 0 10px; font-size: 26px; }
    p { color: #9ca7ab; line-height: 1.55; }
    .credential { margin-top: 16px; padding: 14px; border: 1px solid rgba(255,255,255,.1); border-radius: 8px; background: #0e1113; }
    .credential span { display: block; margin-bottom: 6px; color: #859398; font-size: 11px; text-transform: uppercase; }
    .credential strong { display: block; overflow-wrap: anywhere; font-size: 16px; }
    a { display: inline-block; margin-top: 22px; color: #d8ff3e; text-decoration: none; font-weight: 700; }
  </style>
</head>
<body>
  <main>
    <div class="brand">PETER SHOP · SECURE DELIVERY</div>
    <?php if ($approved): ?>
      <h1>Your account is ready</h1>
      <p>Payment approved for <?= htmlspecialchars((string) ($orders['product'] ?? 'your account'), ENT_QUOTES, 'UTF-8') ?>. Keep these login details private.</p>
      <div class="credential"><span>Account email</span><strong><?= htmlspecialchars((string) $accountCredentials['game_email'], ENT_QUOTES, 'UTF-8') ?></strong></div>
      <div class="credential"><span>Account password</span><strong><?= htmlspecialchars((string) $accountCredentials['game_password'], ENT_QUOTES, 'UTF-8') ?></strong></div>
    <?php else: ?>
      <h1>Account not available</h1>
      <p>This delivery link is invalid or payment has not been approved. Return to the payment page or contact Peter Shop support.</p>
    <?php endif; ?>
    <a href="index.php">Return to Peter Shop</a>
  </main>
</body>
</html>
