# Gmail SMTP setup

Seller approval sends the temporary seller login through PHPMailer using Gmail SMTP. Environment variables are preferred, but InfinityFree may not expose them to PHP. On InfinityFree, use the protected config file described below.

## Gmail preparation

1. Use a dedicated Google account for Peter Shop email.
2. Enable 2-Step Verification for that Google account.
3. Create an App Password for mail. Use the 16-character App Password, not the normal Google account password.
4. Use these Gmail SMTP settings:

```text
PETERSHOP_SMTP_HOST=smtp.gmail.com
PETERSHOP_SMTP_PORT=587
PETERSHOP_SMTP_ENCRYPTION=tls
PETERSHOP_SMTP_USERNAME=your-shop-address@gmail.com
PETERSHOP_SMTP_PASSWORD=your-google-app-password
PETERSHOP_SMTP_FROM=your-shop-address@gmail.com
PETERSHOP_SMTP_FROM_NAME=Peter Shop
```

Never use your normal Google password. Keep the App Password private.

## InfinityFree configuration

In InfinityFree File Manager or FTP, open `htdocs/api/` and create a file named `mail-config.php`. Put this PHP array in it and replace the placeholders with your Gmail address and App Password:

```php
<?php
if (!defined('PETER_SHOP_LOAD_MAIL_CONFIG')) {
    http_response_code(404);
    exit;
}

return [
    'host' => 'smtp.gmail.com',
    'port' => 587,
    'encryption' => 'tls',
    'username' => 'your-shop-address@gmail.com',
    'password' => 'your-16-character-google-app-password',
    'from' => 'your-shop-address@gmail.com',
    'from_name' => 'Peter Shop',
];
```

The API loads this file internally. The existing `api/.htaccess` denies web requests to `mail-config.php`, and the PHP guard also prevents direct execution. Do not upload the file with real secrets to a public code repository or share it. Environment variables, if available, override values in this file.

## Install dependency

If the free host does not provide SSH/Composer, run Composer on your computer from the project directory, then upload the generated `vendor/` directory to the live project root using FTP/File Manager. Keep `composer.json` in the project root as well.

```sh
composer install --no-dev --optimize-autoloader
```

This installs PHPMailer from `composer.json`. PHP OpenSSL must be enabled for TLS.

The approval endpoint checks for PHPMailer and Gmail settings before creating a seller account. If configuration or Gmail delivery fails, it rolls back the new seller account and leaves the request pending so it can be retried. A successful SMTP submission marks the request as emailed; Gmail acceptance does not guarantee that the recipient's inbox will not filter the message.
