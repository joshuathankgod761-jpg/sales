<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';
petershop_db_bootstrap();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
session_start();

$input = $_POST;
if (!$input && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $decoded = json_decode((string) file_get_contents('php://input'), true);
    if (is_array($decoded)) $input = $decoded;
}
$listingId = trim((string) ($_GET['listing_id'] ?? $input['listing_id'] ?? ''));
if (!ctype_digit($listingId) || (int) $listingId < 1) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'A valid listing ID is required.']);
    exit;
}

$pdo = petershop_db_connect();
$listingQuery = $pdo->prepare('SELECT owner_email, seller_name FROM listings WHERE id = :id LIMIT 1');
$listingQuery->execute([':id' => (int) $listingId]);
$listing = $listingQuery->fetch();
if (!$listing) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'message' => 'Listing not found.']);
    exit;
}
$ownerEmail = strtolower(trim((string) $listing['owner_email']));
$pdo->prepare('INSERT IGNORE INTO seller_profiles (owner_email, display_name) VALUES (:owner_email, :display_name)')->execute([
    ':owner_email' => $ownerEmail,
    ':display_name' => (string) ($listing['seller_name'] ?? 'Peter Shop Seller'),
]);

$action = trim((string) ($input['action'] ?? ''));
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'delete') {
    if (($_SESSION['auth_user']['area'] ?? '') !== 'admin') {
        http_response_code(403);
        echo json_encode(['ok' => false, 'message' => 'Administrator access is required to remove reviews.']);
        exit;
    }
    $reviewId = filter_var($input['review_id'] ?? null, FILTER_VALIDATE_INT);
    if ($reviewId === false || $reviewId < 1) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'message' => 'A valid review ID is required.']);
        exit;
    }
    $deleteReview = $pdo->prepare('DELETE FROM seller_reviews WHERE id = :id AND owner_email = :owner_email');
    $deleteReview->execute([':id' => $reviewId, ':owner_email' => $ownerEmail]);
    if ($deleteReview->rowCount() < 1) {
        http_response_code(404);
        echo json_encode(['ok' => false, 'message' => 'Review not found for this seller.']);
        exit;
    }
    petershop_sync_seller_profile($pdo, $ownerEmail);
    echo json_encode(['ok' => true, 'message' => 'Review removed.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $profileQuery = $pdo->prepare('SELECT display_name, likes_count, rating, review_count FROM seller_profiles WHERE owner_email = :owner_email');
    $profileQuery->execute([':owner_email' => $ownerEmail]);
    $profile = $profileQuery->fetch() ?: [];
    $reviewQuery = $pdo->prepare('SELECT id, customer_name AS name, title, review, rating, created_at FROM seller_reviews WHERE owner_email = :owner_email ORDER BY created_at DESC, id DESC LIMIT 100');
    $reviewQuery->execute([':owner_email' => $ownerEmail]);
    echo json_encode([
        'ok' => true,
        'seller' => [
            'name' => (string) ($profile['display_name'] ?? $listing['seller_name'] ?? 'Peter Shop Seller'),
            'likes' => (int) ($profile['likes_count'] ?? 0),
            'rating' => number_format((float) ($profile['rating'] ?? 5), 1, '.', ''),
            'reviews' => (int) ($profile['review_count'] ?? 0),
        ],
        'reviews' => $reviewQuery->fetchAll(),
    ], JSON_UNESCAPED_SLASHES);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'message' => 'Method not allowed.']);
    exit;
}

$name = trim((string) ($input['name'] ?? ''));
$email = strtolower(trim((string) ($input['email'] ?? '')));
$title = trim((string) ($input['title'] ?? ''));
$review = trim((string) ($input['review'] ?? ''));
$rating = filter_var($input['rating'] ?? null, FILTER_VALIDATE_INT);
if ($name === '' || mb_strlen($name) > 120 || !filter_var($email, FILTER_VALIDATE_EMAIL)
    || $title === '' || mb_strlen($title) > 180 || $review === '' || mb_strlen($review) > 5000
    || $rating === false || $rating < 1 || $rating > 5) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'Enter your name, valid email, title, review, and a 1 to 5 star rating.']);
    exit;
}

try {
    $pdo->beginTransaction();
    $pdo->prepare('INSERT INTO seller_reviews (owner_email, customer_name, customer_email, title, review, rating) VALUES (:owner_email, :customer_name, :customer_email, :title, :review, :rating)')->execute([
        ':owner_email' => $ownerEmail,
        ':customer_name' => $name,
        ':customer_email' => $email,
        ':title' => $title,
        ':review' => $review,
        ':rating' => $rating,
    ]);
    petershop_sync_seller_profile($pdo, $ownerEmail);
    $pdo->commit();
} catch (PDOException $error) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    if ($error->getCode() === '23000') {
        http_response_code(409);
        echo json_encode(['ok' => false, 'message' => 'A review from this email already exists for this seller.']);
        exit;
    }
    error_log('Peter Shop seller review save failed: ' . $error->getMessage());
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'Could not save your review.']);
    exit;
}

http_response_code(201);
echo json_encode(['ok' => true, 'message' => 'Your review was submitted for this seller.']);
