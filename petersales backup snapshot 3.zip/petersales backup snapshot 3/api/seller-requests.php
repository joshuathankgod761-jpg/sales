<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';
petershop_db_bootstrap();

session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

$lockFile = __DIR__ . '/auth-requests.lock';
$settingsLockFile = __DIR__ . '/admin-settings.lock';

if (($_SESSION['auth_user']['area'] ?? '') !== 'admin') {
    http_response_code(empty($_SESSION['auth_user']) ? 401 : 403);
    echo json_encode(['ok' => false, 'message' => 'Administrator access required.']);
    exit;
}

$loadRequests = static function (): array {
    return petershop_requests_array();
};
$saveRequests = static function (array $requests): bool {
    $pdo = petershop_db_connect();
    $pdo->exec('DELETE FROM seller_requests');
    foreach (($requests['seller_requests'] ?? []) as $request) {
        $pdo->prepare('INSERT INTO seller_requests (name, email, message, status, created_at, reviewed_at, reviewed_by, seller_id, email_status, credentials_emailed_at) VALUES (:name, :email, :message, :status, :created_at, :reviewed_at, :reviewed_by, :seller_id, :email_status, :credentials_emailed_at)')->execute([
            ':name' => (string) ($request['name'] ?? ''),
            ':email' => strtolower(trim((string) ($request['email'] ?? ''))),
            ':message' => (string) ($request['message'] ?? ''),
            ':status' => (string) ($request['status'] ?? 'pending'),
            ':created_at' => (string) ($request['created_at'] ?? date('Y-m-d H:i:s')),
            ':reviewed_at' => !empty($request['reviewed_at']) ? $request['reviewed_at'] : null,
            ':reviewed_by' => isset($request['reviewed_by']) ? (string) $request['reviewed_by'] : null,
            ':seller_id' => isset($request['seller_id']) ? (string) $request['seller_id'] : null,
            ':email_status' => isset($request['email_status']) ? (string) $request['email_status'] : null,
            ':credentials_emailed_at' => isset($request['credentials_emailed_at']) ? $request['credentials_emailed_at'] : null,
        ]);
    }
    petershop_write_json_cache();
    return true;
};
$loadSettings = static function (): array {
    return petershop_admin_settings_record();
};
$saveSettings = static function (array $settings): bool {
    return (bool) (new class($settings) {
        public function __construct(private array $settings) {}
        public function save(): bool {
            $pdo = petershop_db_connect();
            $pdo->prepare('UPDATE settings SET name = :name, email = :email, role = :role, timezone = :timezone, language = :language, password_hash = :password_hash WHERE id = (SELECT id FROM settings ORDER BY id ASC LIMIT 1)')->execute([
                ':name' => (string) ($this->settings['name'] ?? 'Peter Admin'),
                ':email' => (string) ($this->settings['email'] ?? 'admin@petershop.com'),
                ':role' => (string) ($this->settings['role'] ?? 'Administrator'),
                ':timezone' => (string) ($this->settings['timezone'] ?? 'Africa/Lagos (WAT)'),
                ':language' => (string) ($this->settings['language'] ?? 'English'),
                ':password_hash' => (string) ($this->settings['password_hash'] ?? password_hash('admin123', PASSWORD_DEFAULT)),
            ]);
            $pdo->exec('DELETE FROM sellers');
            foreach (($this->settings['sellers'] ?? []) as $seller) {
                $pdo->prepare('INSERT INTO sellers (id, name, role, email, password_hash, status, verified, timezone, language, created_at, banned_at, verified_at) VALUES (:id, :name, :role, :email, :password_hash, :status, :verified, :timezone, :language, :created_at, :banned_at, :verified_at)')->execute([
                    ':id' => (string) ($seller['id'] ?? bin2hex(random_bytes(6))),
                    ':name' => (string) ($seller['name'] ?? ''),
                    ':role' => (string) ($seller['role'] ?? 'Seller'),
                    ':email' => strtolower(trim((string) ($seller['email'] ?? ''))),
                    ':password_hash' => (string) ($seller['password_hash'] ?? ''),
                    ':status' => (string) ($seller['status'] ?? 'active'),
                    ':verified' => !empty($seller['verified']) ? 1 : 0,
                    ':timezone' => (string) ($seller['timezone'] ?? 'Africa/Lagos'),
                    ':language' => (string) ($seller['language'] ?? 'English'),
                    ':created_at' => (string) ($seller['created_at'] ?? date('Y-m-d H:i:s')),
                    ':banned_at' => !empty($seller['banned_at']) ? $seller['banned_at'] : null,
                    ':verified_at' => !empty($seller['verified_at']) ? $seller['verified_at'] : null,
                ]);
            }
            petershop_write_json_cache();
            return true;
        }
    })->save();
};

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $requests = $loadRequests();
    echo json_encode(['ok' => true, 'requests' => $requests['seller_requests']], JSON_UNESCAPED_SLASHES);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'message' => 'Method not allowed.']);
    exit;
}

$input = $_POST;
if (!$input) {
    $decodedInput = json_decode((string) file_get_contents('php://input'), true);
    if (is_array($decodedInput)) $input = $decodedInput;
}
$index = filter_var($input['index'] ?? null, FILTER_VALIDATE_INT);
$status = trim((string) ($input['status'] ?? ''));
if ($index === false || $index === null || $index < 0 || !in_array($status, ['pending', 'approved', 'rejected'], true)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'A valid request and status are required.']);
    exit;
}

if ($status === 'approved') {
    $autoloadFile = dirname(__DIR__) . '/vendor/autoload.php';
    if (!is_file($autoloadFile)) {
        http_response_code(503);
        echo json_encode(['ok' => false, 'message' => 'Gmail delivery is not ready yet. Install the project Composer dependencies first.']);
        exit;
    }
    require_once $autoloadFile;
    $mailerClass = 'PHPMailer\\PHPMailer\\PHPMailer';
    if (!class_exists($mailerClass)) {
        http_response_code(503);
        echo json_encode(['ok' => false, 'message' => 'PHPMailer is unavailable. Install the project Composer dependencies first.']);
        exit;
    }
    $mailConfig = [];
    $mailConfigFile = __DIR__ . '/mail-config.php';
    if (is_file($mailConfigFile)) {
        if (!defined('PETER_SHOP_LOAD_MAIL_CONFIG')) define('PETER_SHOP_LOAD_MAIL_CONFIG', true);
        $loadedMailConfig = require $mailConfigFile;
        if (is_array($loadedMailConfig)) $mailConfig = $loadedMailConfig;
    }
    $mailValue = static function (string $key, string $environmentName, string $default = '') use ($mailConfig): string {
        $environmentValue = getenv($environmentName);
        $value = $environmentValue !== false && $environmentValue !== '' ? $environmentValue : ($mailConfig[$key] ?? $default);
        return trim((string) $value);
    };
    $smtpHost = $mailValue('host', 'PETERSHOP_SMTP_HOST', 'smtp.gmail.com');
    $smtpPort = (int) $mailValue('port', 'PETERSHOP_SMTP_PORT', '587');
    $smtpUsername = $mailValue('username', 'PETERSHOP_SMTP_USERNAME');
    $smtpPassword = $mailValue('password', 'PETERSHOP_SMTP_PASSWORD');
    $smtpEncryption = strtolower($mailValue('encryption', 'PETERSHOP_SMTP_ENCRYPTION', 'tls'));
    $mailFrom = $mailValue('from', 'PETERSHOP_SMTP_FROM', $smtpUsername);
    $mailFromName = $mailValue('from_name', 'PETERSHOP_SMTP_FROM_NAME', 'Peter Shop');
    if ($smtpHost === '' || $smtpPort < 1 || !filter_var($smtpUsername, FILTER_VALIDATE_EMAIL) || $smtpPassword === '' || !filter_var($mailFrom, FILTER_VALIDATE_EMAIL) || !in_array($smtpEncryption, ['tls', 'ssl'], true)) {
        http_response_code(503);
        echo json_encode(['ok' => false, 'message' => 'Gmail SMTP is not configured. Set the Petershop SMTP environment variables on the live server before approving seller requests.']);
        exit;
    }
    $sendCredentials = static function (string $to, string $name, string $temporaryPassword) use ($mailerClass, $smtpHost, $smtpPort, $smtpUsername, $smtpPassword, $smtpEncryption, $mailFrom, $mailFromName): bool {
        try {
            $mailer = new $mailerClass(true);
            $mailer->isSMTP();
            $mailer->Host = $smtpHost;
            $mailer->Port = $smtpPort;
            $mailer->SMTPAuth = true;
            $mailer->Username = $smtpUsername;
            $mailer->Password = $smtpPassword;
            $mailer->SMTPSecure = $smtpEncryption;
            $mailer->Timeout = 15;
            $mailer->CharSet = 'UTF-8';
            $mailer->setFrom($mailFrom, $mailFromName);
            $mailer->addAddress($to, $name);
            $mailer->Subject = 'Your Peter Shop seller account is ready';
            $mailer->Body = "Hello {$name},\n\nYour request to become a Peter Shop seller has been approved.\n\nSign-in email: {$to}\nTemporary password: {$temporaryPassword}\n\nPlease sign in and change your password as soon as possible.\n\nPeter Shop Admin";
            return $mailer->send();
        } catch (Throwable $error) {
            error_log('Peter Shop seller credential email failed: ' . $error->getMessage());
            return false;
        }
    };

    $settingsLock = fopen($settingsLockFile, 'c+');
    if ($settingsLock === false || !flock($settingsLock, LOCK_EX)) {
        if (is_resource($settingsLock)) fclose($settingsLock);
        http_response_code(500);
        echo json_encode(['ok' => false, 'message' => 'Could not lock seller accounts.']);
        exit;
    }
    $lock = fopen($lockFile, 'c+');
    if ($lock === false || !flock($lock, LOCK_EX)) {
        if (is_resource($lock)) fclose($lock);
        flock($settingsLock, LOCK_UN);
        fclose($settingsLock);
        http_response_code(500);
        echo json_encode(['ok' => false, 'message' => 'Could not lock seller requests.']);
        exit;
    }

    try {
        $requests = $loadRequests();
        if (!array_key_exists($index, $requests['seller_requests'])) {
            http_response_code(404);
            echo json_encode(['ok' => false, 'message' => 'Seller request not found.']);
            exit;
        }
        $request = $requests['seller_requests'][$index];
        $email = strtolower(trim((string) ($request['email'] ?? '')));
        $name = trim((string) ($request['name'] ?? ''));
        if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'message' => 'This request does not contain a valid name and email.']);
            exit;
        }
        if (($request['status'] ?? 'pending') === 'approved' && !empty($request['seller_id'])) {
            http_response_code(409);
            echo json_encode(['ok' => false, 'message' => 'This request has already created a seller account.']);
            exit;
        }

        $settings = $loadSettings();
        $settings['sellers'] = is_array($settings['sellers'] ?? null) ? $settings['sellers'] : [];
        foreach ($settings['sellers'] as $seller) {
            if (strtolower((string) ($seller['email'] ?? '')) === $email) {
                http_response_code(409);
                echo json_encode(['ok' => false, 'message' => 'A seller account already exists for this email. Review the Sellers page instead.']);
                exit;
            }
        }

        $temporaryPassword = bin2hex(random_bytes(16));
        $sellerId = 'seller-' . bin2hex(random_bytes(6));
        $settings['sellers'][] = [
            'id' => $sellerId,
            'name' => $name,
            'role' => 'Seller',
            'email' => $email,
            'password_hash' => password_hash($temporaryPassword, PASSWORD_DEFAULT),
            'status' => 'active',
            'verified' => false,
            'created_at' => date(DATE_ATOM),
        ];
        if (!$saveSettings($settings)) {
            http_response_code(500);
            echo json_encode(['ok' => false, 'message' => 'Could not create the seller account.']);
            exit;
        }

        $request['status'] = 'approved';
        $request['seller_id'] = $sellerId;
        $request['reviewed_at'] = date(DATE_ATOM);
        $request['reviewed_by'] = (string) ($_SESSION['auth_user']['email'] ?? '');
        $requests['seller_requests'][$index] = $request;
        if (!$saveRequests($requests)) {
            array_pop($settings['sellers']);
            $saveSettings($settings);
            http_response_code(500);
            echo json_encode(['ok' => false, 'message' => 'Could not save the approval. No seller account was retained.']);
            exit;
        }
    } finally {
        flock($lock, LOCK_UN);
        fclose($lock);
        flock($settingsLock, LOCK_UN);
        fclose($settingsLock);
    }

    if (!$sendCredentials($email, $name, $temporaryPassword)) {
        $settingsLock = fopen($settingsLockFile, 'c+');
        $lock = fopen($lockFile, 'c+');
        if ($settingsLock !== false && $lock !== false && flock($settingsLock, LOCK_EX) && flock($lock, LOCK_EX)) {
            try {
                $settings = $loadSettings();
                $settings['sellers'] = array_values(array_filter($settings['sellers'] ?? [], static fn (array $seller): bool => (string) ($seller['id'] ?? '') !== $sellerId));
                $saveSettings($settings);
                $requests = $loadRequests();
                if (isset($requests['seller_requests'][$index])) {
                    $requests['seller_requests'][$index]['status'] = 'pending';
                    unset($requests['seller_requests'][$index]['seller_id'], $requests['seller_requests'][$index]['reviewed_at'], $requests['seller_requests'][$index]['reviewed_by']);
                    $saveRequests($requests);
                }
            } finally {
                flock($lock, LOCK_UN);
                flock($settingsLock, LOCK_UN);
                fclose($lock);
                fclose($settingsLock);
            }
        } else {
            if (is_resource($lock)) fclose($lock);
            if (is_resource($settingsLock)) fclose($settingsLock);
        }
        http_response_code(503);
        echo json_encode(['ok' => false, 'message' => 'Gmail could not send the credentials email. The seller account was rolled back and the request remains pending. Check the live server SMTP settings and retry approval.']);
        exit;
    }

    $lock = fopen($lockFile, 'c+');
    if ($lock !== false && flock($lock, LOCK_EX)) {
        try {
            $requests = $loadRequests();
            if (isset($requests['seller_requests'][$index])) {
                $requests['seller_requests'][$index]['email_status'] = 'sent';
                $requests['seller_requests'][$index]['credentials_emailed_at'] = date(DATE_ATOM);
                $request = $requests['seller_requests'][$index];
                $saveRequests($requests);
            }
        } finally {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    } elseif (is_resource($lock)) {
        fclose($lock);
    }
    echo json_encode(['ok' => true, 'request' => $request, 'index' => $index, 'message' => 'Seller account created and login credentials emailed.']);
    exit;
}

$lock = fopen($lockFile, 'c+');
if ($lock === false || !flock($lock, LOCK_EX)) {
    if (is_resource($lock)) fclose($lock);
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'Could not lock seller requests.']);
    exit;
}

try {
    $requests = $loadRequests();
    if (!array_key_exists($index, $requests['seller_requests'])) {
        http_response_code(404);
        echo json_encode(['ok' => false, 'message' => 'Seller request not found.']);
        exit;
    }
    if (($requests['seller_requests'][$index]['status'] ?? '') === 'approved' && !empty($requests['seller_requests'][$index]['seller_id'])) {
        http_response_code(409);
        echo json_encode(['ok' => false, 'message' => 'This request already created a seller account and cannot be reopened.']);
        exit;
    }
    $requests['seller_requests'][$index]['status'] = $status;
    $requests['seller_requests'][$index]['reviewed_at'] = date(DATE_ATOM);
    $requests['seller_requests'][$index]['reviewed_by'] = (string) ($_SESSION['auth_user']['email'] ?? '');
    if (!$saveRequests($requests)) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'message' => 'Could not save the request review.']);
        exit;
    }
    echo json_encode(['ok' => true, 'request' => $requests['seller_requests'][$index], 'index' => $index], JSON_UNESCAPED_SLASHES);
} finally {
    flock($lock, LOCK_UN);
    fclose($lock);
}