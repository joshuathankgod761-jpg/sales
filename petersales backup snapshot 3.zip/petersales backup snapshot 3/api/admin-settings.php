<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';
petershop_db_bootstrap();

session_start();
if (empty($_SESSION['auth_user'])) {
    http_response_code(401);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'message' => 'Authentication required.']);
    exit;
}

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

$loadSettings = static function (): array {
    return petershop_admin_settings_record();
};
$saveSettings = static function (array $settings): bool {
    $pdo = petershop_db_connect();
    $admin = $settings;
    $stmt = $pdo->prepare('UPDATE settings SET name = :name, email = :email, role = :role, timezone = :timezone, language = :language, password_hash = :password_hash WHERE id = (SELECT id FROM settings ORDER BY id ASC LIMIT 1)');
    $stmt->execute([
        ':name' => (string) ($admin['name'] ?? 'Peter Admin'),
        ':email' => (string) ($admin['email'] ?? 'admin@petershop.com'),
        ':role' => (string) ($admin['role'] ?? 'Administrator'),
        ':timezone' => (string) ($admin['timezone'] ?? 'Africa/Lagos (WAT)'),
        ':language' => (string) ($admin['language'] ?? 'English'),
        ':password_hash' => (string) ($admin['password_hash'] ?? password_hash('admin123', PASSWORD_DEFAULT)),
    ]);

    $pdo->exec('DELETE FROM sellers');
    foreach (($settings['sellers'] ?? []) as $seller) {
        $pdo->prepare('INSERT INTO sellers (id, name, role, email, password_hash, status, verified, timezone, language, created_at, banned_at, verified_at) VALUES (:id, :name, :role, :email, :password_hash, :status, :verified, :timezone, :language, :created_at, :banned_at, :verified_at)')->execute([
            ':id' => (string) ($seller['id'] ?? bin2hex(random_bytes(6))),
            ':name' => (string) ($seller['name'] ?? ''),
            ':role' => (string) ($seller['role'] ?? 'Seller'),
            ':email' => strtolower(trim((string) ($seller['email'] ?? ''))),
            ':password_hash' => (string) ($seller['password_hash'] ?? ''),
            ':status' => (string) ($seller['status'] ?? 'active'),
            ':verified' => !empty($seller['verified']) ? 1 : 0,
            ':timezone' => (string) ($seller['timezone'] ?? 'Africa/Lagos'),
            ':language' => (string) ($seller['language'] ?? 'English'),
            ':created_at' => (string) ($seller['created_at'] ?? date('Y-m-d H:i:s')),
            ':banned_at' => !empty($seller['banned_at']) ? $seller['banned_at'] : null,
            ':verified_at' => !empty($seller['verified_at']) ? $seller['verified_at'] : null,
        ]);
    }
    return true;
};
$withLock = static function (callable $callback) {
    return $callback();
};
$publicSettings = static function (array $settings): array {
    unset($settings['password_hash']);
    if (isset($settings['sellers']) && is_array($settings['sellers'])) {
        $settings['sellers'] = array_map(static function (array $seller): array {
            unset($seller['password_hash']);
            return $seller;
        }, $settings['sellers']);
    }
    return $settings;
};
$isSeller = ($_SESSION['auth_user']['area'] ?? '') === 'adminseller';
$currentEmail = strtolower((string) ($_SESSION['auth_user']['email'] ?? ''));
$sellerSettings = static function (array $settings) use ($isSeller, $currentEmail): ?array {
    if (!$isSeller) return null;
    foreach (($settings['sellers'] ?? []) as $seller) {
        if (strtolower((string) ($seller['email'] ?? '')) !== $currentEmail) continue;
        return [
            'name' => $seller['name'] ?? '',
            'email' => $seller['email'] ?? '',
            'role' => $seller['role'] ?? 'Seller',
            'timezone' => $seller['timezone'] ?? 'Africa/Lagos (WAT)',
            'language' => $seller['language'] ?? 'English',
        ];
    }
    return null;
};

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $settings = $loadSettings();
    if ($isSeller) {
        $seller = $sellerSettings($settings);
        if ($seller === null) {
            http_response_code(404);
            echo json_encode(['ok' => false, 'message' => 'Seller profile not found.']);
            exit;
        }
        echo json_encode(['ok' => true, 'settings' => $seller], JSON_UNESCAPED_SLASHES);
        exit;
    }
    echo json_encode(['ok' => true, 'settings' => $publicSettings($settings)], JSON_UNESCAPED_SLASHES);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'message' => 'Method not allowed.']);
    exit;
}

$input = $_POST;
if (!$input) {
    $decodedInput = json_decode((string) file_get_contents('php://input'), true);
    if (is_array($decodedInput)) $input = $decodedInput;
}
$action = trim((string) ($input['action'] ?? 'profile'));
$result = $withLock(function () use ($action, $input, $loadSettings, $saveSettings, $publicSettings, $sellerSettings, $isSeller, $currentEmail): array {
    $settings = $loadSettings();
    if ($action === 'profile') {
        $name = trim((string) ($input['name'] ?? ''));
        $email = trim((string) ($input['email'] ?? ''));
        $timezone = trim((string) ($input['timezone'] ?? ''));
        $language = trim((string) ($input['language'] ?? ''));
        if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || $timezone === '' || $language === '') {
            return ['status' => 400, 'body' => ['ok' => false, 'message' => 'Enter a valid name, email, timezone, and language.']];
        }
        if ($isSeller) {
            $updated = false;
            foreach ($settings['sellers'] as $index => $seller) {
                if (strtolower((string) ($seller['email'] ?? '')) !== $currentEmail) continue;
                foreach (['name' => $name, 'email' => $email, 'timezone' => $timezone, 'language' => $language] as $key => $value) $settings['sellers'][$index][$key] = $value;
                $_SESSION['auth_user']['name'] = $name;
                $_SESSION['auth_user']['email'] = $email;
                $updated = true;
                break;
            }
            if (!$updated) return ['status' => 404, 'body' => ['ok' => false, 'message' => 'Seller profile not found.']];
        } else {
            $settings['name'] = $name;
            $settings['email'] = $email;
            $settings['timezone'] = $timezone;
            $settings['language'] = $language;
        }
    } elseif ($action === 'password') {
        $currentPassword = (string) ($input['current_password'] ?? '');
        $newPassword = (string) ($input['new_password'] ?? '');
        $confirmPassword = (string) ($input['confirm_password'] ?? '');
        $passwordHash = (string) ($settings['password_hash'] ?? '');
        $sellerIndex = null;
        if ($isSeller) {
            foreach ($settings['sellers'] as $index => $seller) {
                if (strtolower((string) ($seller['email'] ?? '')) === $currentEmail) { $sellerIndex = $index; $passwordHash = (string) ($seller['password_hash'] ?? ''); break; }
            }
        }
        if (!password_verify($currentPassword, $passwordHash)) {
            return ['status' => 400, 'body' => ['ok' => false, 'message' => 'Current password is incorrect.']];
        }
        if (strlen($newPassword) < 8 || $newPassword !== $confirmPassword) {
            return ['status' => 400, 'body' => ['ok' => false, 'message' => 'Use a matching password with at least 8 characters.']];
        }
        if ($isSeller && $sellerIndex !== null) $settings['sellers'][$sellerIndex]['password_hash'] = password_hash($newPassword, PASSWORD_DEFAULT);
        elseif (!$isSeller) $settings['password_hash'] = password_hash($newPassword, PASSWORD_DEFAULT);
        else return ['status' => 404, 'body' => ['ok' => false, 'message' => 'Seller profile not found.']];
    } elseif ($action === 'add_seller') {
        $name = trim((string) ($input['seller_name'] ?? ''));
        $role = trim((string) ($input['seller_role'] ?? ''));
        $email = trim((string) ($input['seller_email'] ?? ''));
        $password = (string) ($input['seller_password'] ?? '');
        if ($name === '' || $role === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 8) {
            return ['status' => 400, 'body' => ['ok' => false, 'message' => 'Enter a name, role, valid email, and password with at least 8 characters.']];
        }
        $settings['sellers'] = is_array($settings['sellers'] ?? null) ? $settings['sellers'] : [];
        foreach ($settings['sellers'] as $seller) {
            if (strtolower((string) ($seller['email'] ?? '')) === strtolower($email)) {
                return ['status' => 409, 'body' => ['ok' => false, 'message' => 'A seller with this email already exists.']];
            }
        }
        $settings['sellers'][] = [
            'id' => 'seller-' . bin2hex(random_bytes(6)),
            'name' => $name,
            'role' => $role,
            'email' => $email,
            'password_hash' => password_hash($password, PASSWORD_DEFAULT),
            'status' => 'active',
            'verified' => false,
            'created_at' => date(DATE_ATOM),
        ];
    } elseif ($action === 'ban_seller') {
        $sellerId = trim((string) ($input['seller_id'] ?? ''));
        if ($sellerId === '') return ['status' => 400, 'body' => ['ok' => false, 'message' => 'Seller ID is required.']];
        $settings['sellers'] = is_array($settings['sellers'] ?? null) ? $settings['sellers'] : [];
        $found = false;
        foreach ($settings['sellers'] as $index => $seller) {
            if ((string) ($seller['id'] ?? '') !== $sellerId) continue;
            $settings['sellers'][$index]['status'] = 'banned';
            $settings['sellers'][$index]['banned_at'] = date(DATE_ATOM);
            $found = true;
            break;
        }
        if (!$found) return ['status' => 404, 'body' => ['ok' => false, 'message' => 'Seller not found.']];
    } elseif ($action === 'unban_seller') {
        $sellerId = trim((string) ($input['seller_id'] ?? ''));
        if ($sellerId === '') return ['status' => 400, 'body' => ['ok' => false, 'message' => 'Seller ID is required.']];
        $settings['sellers'] = is_array($settings['sellers'] ?? null) ? $settings['sellers'] : [];
        $found = false;
        foreach ($settings['sellers'] as $index => $seller) {
            if ((string) ($seller['id'] ?? '') !== $sellerId) continue;
            $settings['sellers'][$index]['status'] = 'active';
            unset($settings['sellers'][$index]['banned_at']);
            $found = true;
            break;
        }
        if (!$found) return ['status' => 404, 'body' => ['ok' => false, 'message' => 'Seller not found.']];
    } elseif ($action === 'verify_seller') {
        $sellerId = trim((string) ($input['seller_id'] ?? ''));
        if ($sellerId === '') return ['status' => 400, 'body' => ['ok' => false, 'message' => 'Seller ID is required.']];
        $settings['sellers'] = is_array($settings['sellers'] ?? null) ? $settings['sellers'] : [];
        $found = false;
        foreach ($settings['sellers'] as $index => $seller) {
            if ((string) ($seller['id'] ?? '') !== $sellerId) continue;
            if (($seller['status'] ?? 'active') === 'banned') return ['status' => 400, 'body' => ['ok' => false, 'message' => 'A banned seller cannot be verified.']];
            $settings['sellers'][$index]['verified'] = true;
            $settings['sellers'][$index]['verified_at'] = date(DATE_ATOM);
            $found = true;
            break;
        }
        if (!$found) return ['status' => 404, 'body' => ['ok' => false, 'message' => 'Seller not found.']];
    } elseif ($action === 'unverify_seller') {
        $sellerId = trim((string) ($input['seller_id'] ?? ''));
        if ($sellerId === '') return ['status' => 400, 'body' => ['ok' => false, 'message' => 'Seller ID is required.']];
        $settings['sellers'] = is_array($settings['sellers'] ?? null) ? $settings['sellers'] : [];
        $found = false;
        foreach ($settings['sellers'] as $index => $seller) {
            if ((string) ($seller['id'] ?? '') !== $sellerId) continue;
            $settings['sellers'][$index]['verified'] = false;
            unset($settings['sellers'][$index]['verified_at']);
            $found = true;
            break;
        }
        if (!$found) return ['status' => 404, 'body' => ['ok' => false, 'message' => 'Seller not found.']];
    } else {
        return ['status' => 400, 'body' => ['ok' => false, 'message' => 'Unknown settings action.']];
    }
    if (!$saveSettings($settings)) return ['status' => 500, 'body' => ['ok' => false, 'message' => 'Could not save settings.']];
    return ['status' => 200, 'body' => ['ok' => true, 'settings' => $isSeller ? $sellerSettings($settings) : $publicSettings($settings)]];
});
if (!$result) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'Could not lock settings for update.']);
    exit;
}
http_response_code($result['status']);
echo json_encode($result['body'], JSON_UNESCAPED_SLASHES);
