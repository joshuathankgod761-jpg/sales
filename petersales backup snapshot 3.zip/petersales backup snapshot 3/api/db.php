<?php

declare(strict_types=1);

function petershop_db_connect(?string $database = 'petershop'): PDO
{
    static $connections = [];
    if (isset($connections[$database])) {
        return $connections[$database];
    }

    $host = getenv('PETERSHOP_DB_HOST') ?: '127.0.0.1';
    $user = getenv('PETERSHOP_DB_USER') ?: 'root';
    $pass = getenv('PETERSHOP_DB_PASS') ?: '';
    $port = getenv('PETERSHOP_DB_PORT') ?: '3306';

    $driver = new PDO("mysql:host={$host};port={$port};charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    $driver->exec("CREATE DATABASE IF NOT EXISTS `{$database}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

    $pdo = new PDO("mysql:host={$host};port={$port};dbname={$database};charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    $connections[$database] = $pdo;

    return $pdo;
}

function petershop_write_json_cache(): void
{
}

function petershop_db_bootstrap(): void
{
    $pdo = petershop_db_connect();

    $schema = <<<'SQL'
CREATE TABLE IF NOT EXISTS settings (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    role VARCHAR(120) NOT NULL,
    timezone VARCHAR(120) NOT NULL,
    language VARCHAR(120) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_settings_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sellers (
    id VARCHAR(64) NOT NULL,
    name VARCHAR(255) NOT NULL,
    role VARCHAR(120) NOT NULL,
    email VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'active',
    verified TINYINT(1) NOT NULL DEFAULT 0,
    timezone VARCHAR(120) NOT NULL DEFAULT 'Africa/Lagos',
    language VARCHAR(120) NOT NULL DEFAULT 'English',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    banned_at DATETIME NULL,
    verified_at DATETIME NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_sellers_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS password_resets (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    email VARCHAR(255) NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'pending',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    reviewed_at DATETIME NULL,
    PRIMARY KEY (id),
    KEY idx_password_resets_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS seller_requests (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    message TEXT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'pending',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    reviewed_at DATETIME NULL,
    reviewed_by VARCHAR(255) NULL,
    seller_id VARCHAR(64) NULL,
    email_status VARCHAR(32) NULL,
    credentials_emailed_at DATETIME NULL,
    PRIMARY KEY (id),
    KEY idx_seller_requests_status (status),
    KEY idx_seller_requests_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS listings (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    product_id VARCHAR(24) NOT NULL,
    title VARCHAR(255) NOT NULL,
    price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    level INT NOT NULL DEFAULT 0,
    tier VARCHAR(80) NOT NULL DEFAULT 'Bronze',
    tag VARCHAR(255) NOT NULL DEFAULT '',
    meta VARCHAR(255) NOT NULL DEFAULT '',
    description TEXT NOT NULL,
    game_version VARCHAR(80) NOT NULL DEFAULT 'Prime 1',
    server VARCHAR(80) NOT NULL DEFAULT 'Indonesia',
    characters INT NOT NULL DEFAULT 0,
    outfits VARCHAR(500) NOT NULL DEFAULT '',
    emotes VARCHAR(500) NOT NULL DEFAULT '',
    arrival_animation VARCHAR(500) NOT NULL DEFAULT '',
    look_changer VARCHAR(500) NOT NULL DEFAULT '',
    evo_guns INT NOT NULL DEFAULT 0,
    max_evo_guns VARCHAR(255) NOT NULL DEFAULT '',
    booyah_pass VARCHAR(50) NOT NULL DEFAULT 'No',
    elite_pass VARCHAR(50) NOT NULL DEFAULT 'No',
    seller_name VARCHAR(255) NOT NULL,
    rating DECIMAL(3,1) NOT NULL DEFAULT 5.0,
    reviews INT NOT NULL DEFAULT 0,
    likes INT NOT NULL DEFAULT 0,
    status VARCHAR(32) NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    game_email VARCHAR(255) NULL,
    game_password VARCHAR(255) NULL,
    image VARCHAR(500) NOT NULL DEFAULT '',
    category VARCHAR(80) NOT NULL DEFAULT 'mythic',
    featured TINYINT(1) NOT NULL DEFAULT 0,
    owner_email VARCHAR(255) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_listings_product_id (product_id),
    KEY idx_listings_owner (owner_email),
    KEY idx_listings_status (status),
    KEY idx_listings_category (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS listing_images (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    listing_id INT UNSIGNED NOT NULL,
    image_path VARCHAR(500) NOT NULL,
    position INT UNSIGNED NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_listing_images_listing (listing_id, position),
    CONSTRAINT fk_listing_images_listing FOREIGN KEY (listing_id) REFERENCES listings (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS seller_profiles (
    owner_email VARCHAR(255) NOT NULL,
    display_name VARCHAR(255) NOT NULL,
    likes_count INT UNSIGNED NOT NULL DEFAULT 0,
    rating DECIMAL(3,2) NOT NULL DEFAULT 5.00,
    review_count INT UNSIGNED NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (owner_email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS seller_profile_likes (
    owner_email VARCHAR(255) NOT NULL,
    visitor_id CHAR(64) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (owner_email, visitor_id),
    KEY idx_seller_profile_likes_owner (owner_email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS seller_reviews (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    owner_email VARCHAR(255) NOT NULL,
    customer_name VARCHAR(120) NOT NULL,
    customer_email VARCHAR(255) NOT NULL,
    title VARCHAR(180) NOT NULL,
    review TEXT NOT NULL,
    rating TINYINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_seller_review_email (owner_email, customer_email),
    KEY idx_seller_reviews_owner_created (owner_email, created_at),
    KEY idx_seller_reviews_email (owner_email, customer_email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS orders (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    order_id VARCHAR(64) NOT NULL,
    customer_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    method VARCHAR(64) NOT NULL,
    amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    currency VARCHAR(10) NOT NULL DEFAULT 'USD',
    product VARCHAR(255) NOT NULL,
    product_id VARCHAR(24) NOT NULL,
    listing_id INT UNSIGNED NULL,
    seller_email VARCHAR(255) NOT NULL,
    transaction_id VARCHAR(255) NOT NULL,
    payment_detail VARCHAR(255) NULL,
    receipt VARCHAR(500) NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'pending',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    decline_message VARCHAR(255) NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_orders_order_id (order_id),
    KEY idx_orders_seller_email (seller_email),
    KEY idx_orders_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS payment_settings (
    owner_email VARCHAR(255) NOT NULL,
    bank_json LONGTEXT NOT NULL,
    crypto_json LONGTEXT NOT NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (owner_email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SQL;

    foreach (array_filter(array_map('trim', preg_split('/;\s*\R/', $schema)), static fn (string $statement): bool => $statement !== '') as $statement) {
        $pdo->exec($statement . ';');
    }

    $reviewIndexCheck = $pdo->prepare('SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :table_name AND INDEX_NAME = :index_name');
    $reviewIndexCheck->execute([':table_name' => 'seller_reviews', ':index_name' => 'uq_seller_review_email']);
    if ((int) $reviewIndexCheck->fetchColumn() === 0) {
        $pdo->exec('ALTER TABLE seller_reviews ADD UNIQUE KEY uq_seller_review_email (owner_email, customer_email)');
    }

    $pdo->exec("INSERT INTO seller_profiles (owner_email, display_name, likes_count, rating, review_count) SELECT l.owner_email, MAX(l.seller_name), COALESCE((SELECT COUNT(*) FROM seller_profile_likes spl WHERE spl.owner_email = l.owner_email), 0), COALESCE((SELECT AVG(sr.rating) FROM seller_reviews sr WHERE sr.owner_email = l.owner_email), 5.00), COALESCE((SELECT COUNT(*) FROM seller_reviews sr WHERE sr.owner_email = l.owner_email), 0) FROM listings l GROUP BY l.owner_email ON DUPLICATE KEY UPDATE display_name = VALUES(display_name), likes_count = VALUES(likes_count), rating = VALUES(rating), review_count = VALUES(review_count)");

    foreach ([
        'outfits' => "VARCHAR(500) NOT NULL DEFAULT ''",
        'emotes' => "VARCHAR(500) NOT NULL DEFAULT ''",
        'arrival_animation' => "VARCHAR(500) NOT NULL DEFAULT ''",
        'look_changer' => "VARCHAR(500) NOT NULL DEFAULT ''",
        'max_evo_guns' => "VARCHAR(255) NOT NULL DEFAULT ''",
    ] as $column => $definition) {
        $check = $pdo->prepare('SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :table_name AND COLUMN_NAME = :column_name');
        $check->execute([':table_name' => 'listings', ':column_name' => $column]);
        if ((int) $check->fetchColumn() === 0) {
            $pdo->exec("ALTER TABLE listings ADD COLUMN {$column} {$definition}");
        }
    }

    $settingsCount = (int) $pdo->query('SELECT COUNT(*) FROM settings')->fetchColumn();
    if ($settingsCount === 0) {
        $defaultSettings = petershop_default_admin_settings();
        $stmt = $pdo->prepare('INSERT INTO settings (name, email, role, timezone, language, password_hash) VALUES (:name, :email, :role, :timezone, :language, :password_hash)');
        $stmt->execute([
            ':name' => $defaultSettings['name'],
            ':email' => $defaultSettings['email'],
            ':role' => $defaultSettings['role'],
            ':timezone' => $defaultSettings['timezone'],
            ':language' => $defaultSettings['language'],
            ':password_hash' => $defaultSettings['password_hash'],
        ]);
    }

}

function petershop_default_admin_settings(): array
{
    return [
        'name' => 'Peter Admin',
        'email' => 'admin@petershop.com',
        'role' => 'Administrator',
        'timezone' => 'Africa/Lagos (WAT)',
        'language' => 'English',
        'password_hash' => password_hash('admin123', PASSWORD_DEFAULT),
        'sellers' => [],
    ];
}

function petershop_default_admin_email(): string
{
    $record = petershop_admin_settings_record();
    return strtolower(trim((string) ($record['email'] ?? 'admin@petershop.com')));
}

function petershop_admin_settings_record(): array
{
    $pdo = petershop_db_connect();
    $settings = $pdo->query('SELECT * FROM settings ORDER BY id ASC LIMIT 1')->fetch();
    if (!$settings) {
        petershop_db_bootstrap();
        $settings = $pdo->query('SELECT * FROM settings ORDER BY id ASC LIMIT 1')->fetch();
    }
    if (!$settings) {
        return petershop_default_admin_settings();
    }

    $sellerRows = $pdo->query('SELECT * FROM sellers ORDER BY created_at ASC, id ASC')->fetchAll();
    $sellers = [];
    foreach ($sellerRows as $sellerRow) {
        $sellers[] = [
            'id' => (string) ($sellerRow['id'] ?? ''),
            'name' => (string) ($sellerRow['name'] ?? ''),
            'role' => (string) ($sellerRow['role'] ?? 'Seller'),
            'email' => (string) ($sellerRow['email'] ?? ''),
            'password_hash' => (string) ($sellerRow['password_hash'] ?? ''),
            'status' => (string) ($sellerRow['status'] ?? 'active'),
            'verified' => (bool) ((int) ($sellerRow['verified'] ?? 0)),
            'timezone' => (string) ($sellerRow['timezone'] ?? 'Africa/Lagos'),
            'language' => (string) ($sellerRow['language'] ?? 'English'),
            'created_at' => $sellerRow['created_at'] ?? null,
            'banned_at' => $sellerRow['banned_at'] ?? null,
            'verified_at' => $sellerRow['verified_at'] ?? null,
        ];
    }

    return [
        'name' => (string) ($settings['name'] ?? 'Peter Admin'),
        'email' => (string) ($settings['email'] ?? 'admin@petershop.com'),
        'role' => (string) ($settings['role'] ?? 'Administrator'),
        'timezone' => (string) ($settings['timezone'] ?? 'Africa/Lagos (WAT)'),
        'language' => (string) ($settings['language'] ?? 'English'),
        'password_hash' => (string) ($settings['password_hash'] ?? ''),
        'sellers' => $sellers,
    ];
}

function petershop_sync_seller_profile(PDO $pdo, string $ownerEmail): void
{
    $ownerEmail = strtolower(trim($ownerEmail));
    if ($ownerEmail === '') {
        return;
    }

    $statement = $pdo->prepare('INSERT INTO seller_profiles (owner_email, display_name, likes_count, rating, review_count) VALUES (:owner_email, :display_name, 0, 5.00, 0) ON DUPLICATE KEY UPDATE display_name = VALUES(display_name)');
    $statement->execute([
        ':owner_email' => $ownerEmail,
        ':display_name' => 'Peter Shop Seller',
    ]);

    $pdo->prepare('UPDATE seller_profiles SET display_name = COALESCE((SELECT MAX(seller_name) FROM listings WHERE owner_email = :owner_email), display_name), likes_count = (SELECT COUNT(*) FROM seller_profile_likes WHERE owner_email = :owner_email), rating = COALESCE((SELECT AVG(rating) FROM seller_reviews WHERE owner_email = :owner_email), 5.00), review_count = (SELECT COUNT(*) FROM seller_reviews WHERE owner_email = :owner_email) WHERE owner_email = :owner_email')->execute([
        ':owner_email' => $ownerEmail,
    ]);
}

function petershop_listings_array(): array
{
    $pdo = petershop_db_connect();
    $pdo->exec("INSERT INTO seller_profiles (owner_email, display_name, likes_count, rating, review_count) SELECT l.owner_email, MAX(l.seller_name), COALESCE((SELECT COUNT(*) FROM seller_profile_likes spl WHERE spl.owner_email = l.owner_email), 0), COALESCE((SELECT AVG(sr.rating) FROM seller_reviews sr WHERE sr.owner_email = l.owner_email), 5.00), COALESCE((SELECT COUNT(*) FROM seller_reviews sr WHERE sr.owner_email = l.owner_email), 0) FROM listings l GROUP BY l.owner_email ON DUPLICATE KEY UPDATE display_name = VALUES(display_name), likes_count = VALUES(likes_count), rating = VALUES(rating), review_count = VALUES(review_count)");
    $rows = $pdo->query('SELECT * FROM listings ORDER BY id ASC')->fetchAll();
    $sellerProfiles = [];
    foreach ($pdo->query('SELECT owner_email, display_name, likes_count, rating, review_count FROM seller_profiles')->fetchAll() as $profile) {
        $sellerProfiles[strtolower((string) $profile['owner_email'])] = $profile;
    }
    $imageRows = $pdo->query('SELECT listing_id, image_path FROM listing_images ORDER BY listing_id ASC, position ASC, id ASC')->fetchAll();
    $imagesByListing = [];
    foreach ($imageRows as $imageRow) {
        $imagesByListing[(int) $imageRow['listing_id']][] = (string) $imageRow['image_path'];
    }
    $listings = [];
    foreach ($rows as $row) {
        $ownerEmail = strtolower(trim((string) ($row['owner_email'] ?? '')));
        $sellerProfile = $sellerProfiles[$ownerEmail] ?? [];
        $images = $imagesByListing[(int) ($row['id'] ?? 0)] ?? [];
        $legacyImage = (string) ($row['image'] ?? '');
        if (!$images && $legacyImage !== '' && !str_starts_with($legacyImage, 'data:image/')) {
            $images[] = $legacyImage;
        }
        if (!$images) {
            $images[] = 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=900&q=85';
        }
        $listings[] = [
            'id' => (int) ($row['id'] ?? 0),
            'product_id' => (string) ($row['product_id'] ?? ''),
            'title' => (string) ($row['title'] ?? ''),
            'price' => (float) ($row['price'] ?? 0),
            'level' => (int) ($row['level'] ?? 0),
            'tier' => (string) ($row['tier'] ?? 'Bronze'),
            'tag' => (string) ($row['tag'] ?? ''),
            'meta' => (string) ($row['meta'] ?? ''),
            'description' => (string) ($row['description'] ?? ''),
            'gameVersion' => (string) ($row['game_version'] ?? 'Prime 1'),
            'server' => (string) ($row['server'] ?? 'Indonesia'),
            'characters' => (int) ($row['characters'] ?? 0),
            'outfits' => (string) ($row['outfits'] ?? ''),
            'emotes' => (string) ($row['emotes'] ?? ''),
            'arrivalAnimation' => (string) ($row['arrival_animation'] ?? ''),
            'lookChanger' => (string) ($row['look_changer'] ?? ''),
            'evoGuns' => (int) ($row['evo_guns'] ?? 0),
            'maxEvoGuns' => (string) ($row['max_evo_guns'] ?? ''),
            'booyahPass' => (string) ($row['booyah_pass'] ?? 'No'),
            'elitePass' => (string) ($row['elite_pass'] ?? 'No'),
            'seller' => (string) ($sellerProfile['display_name'] ?? $row['seller_name'] ?? 'Peter Admin'),
            'rating' => number_format((float) ($sellerProfile['rating'] ?? 5), 1, '.', ''),
            'reviews' => (int) ($sellerProfile['review_count'] ?? 0),
            'likes' => (int) ($sellerProfile['likes_count'] ?? 0),
            'sellerKey' => hash('sha256', $ownerEmail),
            'sellerLiked' => false,
            'status' => (string) ($row['status'] ?? 'active'),
            'created_at' => $row['created_at'] ?? null,
            'game_email' => $row['game_email'] ?? '',
            'game_password' => $row['game_password'] ?? '',
            'image' => $images[0] ?? '',
            'images' => $images,
            'category' => (string) ($row['category'] ?? 'mythic'),
            'featured' => (bool) ((int) ($row['featured'] ?? 0)),
            'owner_email' => $ownerEmail !== '' ? $ownerEmail : petershop_default_admin_email(),
        ];
    }

    return $listings;
}

function petershop_orders_array(): array
{
    $pdo = petershop_db_connect();
    $rows = $pdo->query('SELECT * FROM orders ORDER BY id ASC')->fetchAll();
    $orders = [];
    foreach ($rows as $row) {
        $orders[] = [
            'id' => (int) ($row['id'] ?? 0),
            'order_id' => (string) ($row['order_id'] ?? ''),
            'customer_name' => (string) ($row['customer_name'] ?? ''),
            'email' => (string) ($row['email'] ?? ''),
            'method' => (string) ($row['method'] ?? 'bank transfer'),
            'amount' => (float) ($row['amount'] ?? 0),
            'currency' => (string) ($row['currency'] ?? 'USD'),
            'product' => (string) ($row['product'] ?? ''),
            'product_id' => (string) ($row['product_id'] ?? ''),
            'listing_id' => isset($row['listing_id']) ? (int) $row['listing_id'] : 0,
            'seller_email' => strtolower(trim((string) ($row['seller_email'] ?? petershop_default_admin_email()))),
            'transaction_id' => (string) ($row['transaction_id'] ?? ''),
            'payment_detail' => (string) ($row['payment_detail'] ?? ''),
            'receipt' => (string) ($row['receipt'] ?? ''),
            'status' => (string) ($row['status'] ?? 'pending'),
            'created_at' => $row['created_at'] ?? null,
            'updated_at' => $row['updated_at'] ?? null,
            'decline_message' => (string) ($row['decline_message'] ?? ''),
        ];
    }
    return $orders;
}

function petershop_payment_store_array(): array
{
    $pdo = petershop_db_connect();
    $rows = $pdo->query('SELECT * FROM payment_settings ORDER BY owner_email ASC')->fetchAll();
    $owners = [];
    foreach ($rows as $row) {
        $owners[strtolower((string) ($row['owner_email'] ?? ''))] = [
            'bank' => json_decode((string) ($row['bank_json'] ?? '[]'), true) ?: [],
            'crypto' => json_decode((string) ($row['crypto_json'] ?? '[]'), true) ?: [],
        ];
    }
    return ['owners' => $owners];
}

function petershop_requests_array(): array
{
    $pdo = petershop_db_connect();
    $rows = $pdo->query('SELECT * FROM seller_requests ORDER BY created_at ASC, id ASC')->fetchAll();
    return ['seller_requests' => $rows];
}

