<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/payment-settings-store.php';
petershop_db_bootstrap();

session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$currentOwnerEmail = strtolower(trim((string) ($_SESSION['auth_user']['email'] ?? '')));
$findAccount = static function (string $productId): ?array {
    $accounts = petershop_listings_array();
    foreach ($accounts as $account) {
        if (strtoupper((string) ($account['product_id'] ?? '')) === strtoupper($productId)) return $account;
        if (ctype_digit($productId) && (string) ($account['id'] ?? '') === $productId) return $account;
    }
    return null;
};
$findAccountById = static function (string $listingId): ?array {
    if (!ctype_digit($listingId)) return null;
    $accounts = petershop_listings_array();
    foreach ($accounts as $account) {
        if ((string) ($account['id'] ?? '') === $listingId) return $account;
    }
    return null;
};
$findListingForOrder = static function (array $order) use ($findAccountById, $findAccount): ?array {
    if (!empty($order['listing_id'])) return $findAccountById((string) $order['listing_id']);
    $productId = strtoupper(trim((string) ($order['product_id'] ?? '')));
    if ($productId === '') return null;
    $recordedOwner = strtolower(trim((string) ($order['seller_email'] ?? '')));
    foreach (petershop_listings_array() as $account) {
        if (strtoupper((string) ($account['product_id'] ?? '')) !== $productId) continue;
        $ownerEmail = strtolower(trim((string) ($account['owner_email'] ?? peter_payment_default_owner_email())));
        if ($recordedOwner !== '' && $ownerEmail !== $recordedOwner) continue;
        return $account;
    }
    return null;
};
$loadOrders = static function (): array {
    return petershop_orders_array();
};
$saveOrders = static function (array $orders): bool {
    $pdo = petershop_db_connect();
    $pdo->beginTransaction();
    try {
        $pdo->exec('DELETE FROM orders');
        foreach ($orders as $order) {
            $pdo->prepare('INSERT INTO orders (order_id, customer_name, email, method, amount, currency, product, product_id, listing_id, seller_email, transaction_id, payment_detail, receipt, status, created_at, updated_at, decline_message) VALUES (:order_id, :customer_name, :email, :method, :amount, :currency, :product, :product_id, :listing_id, :seller_email, :transaction_id, :payment_detail, :receipt, :status, :created_at, :updated_at, :decline_message)')->execute([
            ':order_id' => (string) ($order['order_id'] ?? ''),
            ':customer_name' => (string) ($order['customer_name'] ?? ''),
            ':email' => (string) ($order['email'] ?? ''),
            ':method' => strtolower((string) ($order['method'] ?? 'bank transfer')),
            ':amount' => (string) ($order['amount'] ?? '0'),
            ':currency' => (string) ($order['currency'] ?? 'USD'),
            ':product' => (string) ($order['product'] ?? ''),
            ':product_id' => (string) ($order['product_id'] ?? ''),
            ':listing_id' => !empty($order['listing_id']) ? (int) $order['listing_id'] : null,
            ':seller_email' => strtolower(trim((string) ($order['seller_email'] ?? peter_payment_default_owner_email()))),
            ':transaction_id' => (string) ($order['transaction_id'] ?? ''),
            ':payment_detail' => (string) ($order['payment_detail'] ?? ''),
            ':receipt' => (string) ($order['receipt'] ?? ''),
            ':status' => (string) ($order['status'] ?? 'pending'),
            ':created_at' => (string) ($order['created_at'] ?? date('Y-m-d H:i:s')),
            ':updated_at' => (string) ($order['updated_at'] ?? date('Y-m-d H:i:s')),
            ':decline_message' => (string) ($order['decline_message'] ?? ''),
            ]);
        }
        $pdo->commit();
    } catch (Throwable $error) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        return false;
    }
    return true;
};
$orderOwnerEmail = static function (array $order) use ($findListingForOrder): string {
    $recordedOwner = strtolower(trim((string) ($order['seller_email'] ?? '')));
    if ($recordedOwner !== '') return $recordedOwner;
    $account = $findListingForOrder($order);
    return $account ? strtolower(trim((string) ($account['owner_email'] ?? peter_payment_default_owner_email()))) : '';
};
$orderBelongsToOwner = static function (array $order) use ($currentOwnerEmail, $orderOwnerEmail): bool {
    return $currentOwnerEmail !== '' && $orderOwnerEmail($order) === $currentOwnerEmail;
};

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $orderId = trim((string) ($_GET['order_id'] ?? ''));
    $orders = $loadOrders();
    if ($orderId !== '') {
        foreach ($orders as $order) {
            if (!hash_equals((string) ($order['order_id'] ?? ''), $orderId)) continue;
            $trackingData = ['order_id' => $order['order_id'], 'status' => $order['status'] ?? 'pending', 'decline_message' => $order['decline_message'] ?? ''];
            if (($order['status'] ?? '') === 'confirmed') {
                $account = $findListingForOrder($order);
                $trackingData['has_delivery_credentials'] = $account && !empty($account['game_email']) && !empty($account['game_password']);
            }
            echo json_encode(['ok' => true, 'order' => $trackingData], JSON_UNESCAPED_SLASHES);
            exit;
        }
        http_response_code(404);
        echo json_encode(['ok' => false, 'message' => 'Order not found.']);
        exit;
    }
    if (empty($_SESSION['auth_user'])) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'message' => 'Authentication required.']);
        exit;
    }
    $result = array_values(array_filter($orders, $orderBelongsToOwner));
    echo json_encode(['ok' => true, 'orders' => array_map(static function (array $order): array { unset($order['seller_email']); return $order; }, $result)], JSON_UNESCAPED_SLASHES);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'message' => 'Method not allowed.']);
    exit;
}

$action = trim((string) ($_POST['action'] ?? 'create'));
$orders = $loadOrders();
if (in_array($action, ['status', 'delete'], true) && empty($_SESSION['auth_user'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'message' => 'Authentication required.']);
    exit;
}

if ($action === 'status') {
    $orderId = trim((string) ($_POST['order_id'] ?? ''));
    $status = trim((string) ($_POST['status'] ?? ''));
    if (!in_array($status, ['pending', 'confirmed', 'rejected'], true)) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'message' => 'Invalid order status.']);
        exit;
    }
    foreach ($orders as $index => $order) {
        if (($order['order_id'] ?? '') !== $orderId) continue;
        if (!$orderBelongsToOwner($order)) {
            http_response_code(404);
            echo json_encode(['ok' => false, 'message' => 'Order not found.']);
            exit;
        }
        $account = $findListingForOrder($order);
        if ($status === 'confirmed' && (!$account || empty($account['game_email']) || empty($account['game_password']))) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'message' => 'Credentials are not saved for this FF ID. Add them to the listing before approving payment.']);
            exit;
        }
        if ($status === 'confirmed') {
            $pdo = petershop_db_connect();
            $stmt = $pdo->prepare('UPDATE listings SET status = :status WHERE id = :id');
            $stmt->execute([':status' => 'sold', ':id' => (int) ($account['id'] ?? 0)]);
        }
        $orders[$index]['status'] = $status;
        $orders[$index]['updated_at'] = date(DATE_ATOM);
        if ($status === 'confirmed') {
            unset($orders[$index]['decline_message']);
        } else {
            if ($status === 'rejected') {
                $orders[$index]['decline_message'] = 'Payment was declined. Confirm your payment and try again.';
            } else {
                unset($orders[$index]['decline_message']);
            }
        }
        if (!$saveOrders($orders)) {
            http_response_code(500);
            echo json_encode(['ok' => false, 'message' => 'Could not save order status.']);
            exit;
        }
        echo json_encode(['ok' => true, 'order' => $orders[$index]], JSON_UNESCAPED_SLASHES);
        exit;
    }
    http_response_code(404);
    echo json_encode(['ok' => false, 'message' => 'Order not found.']);
    exit;
}

if ($action === 'delete') {
    $orderId = trim((string) ($_POST['order_id'] ?? ''));
    $remaining = array_values(array_filter($orders, static fn (array $order): bool => ($order['order_id'] ?? '') !== $orderId));
    if (count($remaining) === count($orders)) {
        http_response_code(404);
        echo json_encode(['ok' => false, 'message' => 'Order not found.']);
        exit;
    }
    if (!$saveOrders($remaining)) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'message' => 'Could not delete order.']);
        exit;
    }
    echo json_encode(['ok' => true, 'deleted' => $orderId]);
    exit;
}

$name = trim((string) ($_POST['customer_name'] ?? ''));
$email = trim((string) ($_POST['email'] ?? ''));
$method = strtolower(trim((string) ($_POST['method'] ?? '')));
$amount = (float) ($_POST['amount'] ?? 0);
$product = trim((string) ($_POST['product'] ?? ''));
$transactionId = trim((string) ($_POST['transaction_id'] ?? ''));
$paymentDetail = trim((string) ($_POST['payment_detail'] ?? ''));
$listingId = trim((string) ($_POST['listing_id'] ?? ''));
$productReference = trim((string) ($_POST['product_id'] ?? ''));
if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || !in_array($method, ['bank transfer', 'crypto'], true) || $amount <= 0 || $product === '' || $transactionId === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'Name, valid email, payment method, amount, product, and transaction ID are required.']);
    exit;
}

$availableAccount = $listingId !== '' ? $findAccountById($listingId) : $findAccount($productReference);
if (!$availableAccount) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'message' => 'Account listing not found.']);
    exit;
}
$productReference = (string) ($availableAccount['product_id'] ?? $productReference);
if (!preg_match('/^FF\d+$/i', $productReference)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'This listing does not have a valid product code.']);
    exit;
}
if (($availableAccount['status'] ?? 'active') === 'sold') {
    http_response_code(409);
    echo json_encode(['ok' => false, 'message' => 'This account has already been sold.']);
    exit;
}
$paymentOwner = strtolower((string) ($availableAccount['owner_email'] ?? peter_payment_default_owner_email()));
$ownerPayment = peter_payment_for_owner(peter_payment_store_load(), $paymentOwner);
$bankReady = !empty($ownerPayment['bank']) && !in_array('', (array) $ownerPayment['bank'], true);
$cryptoReady = !empty($ownerPayment['crypto']) && !in_array('', (array) $ownerPayment['crypto'], true);
if (($method === 'bank transfer' && !$bankReady) || ($method === 'crypto' && !$cryptoReady)) {
    http_response_code(409);
    echo json_encode(['ok' => false, 'message' => 'This payment method is not available for this listing.']);
    exit;
}

$receiptPath = '';
if (isset($_FILES['receipt']) && $_FILES['receipt']['error'] !== UPLOAD_ERR_NO_FILE) {
    $receipt = $_FILES['receipt'];
    if ($receipt['error'] !== UPLOAD_ERR_OK || $receipt['size'] > 8 * 1024 * 1024) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'message' => 'Receipt upload failed or is larger than 8 MB.']);
        exit;
    }
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($receipt['tmp_name']);
    $extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'application/pdf' => 'pdf'];
    if (!isset($extensions[$mime])) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'message' => 'Upload a JPG, PNG, WEBP, or PDF receipt.']);
        exit;
    }
    $receiptDirectory = __DIR__ . '/order-receipts';
    if (!is_dir($receiptDirectory) && !mkdir($receiptDirectory, 0755, true) && !is_dir($receiptDirectory)) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'message' => 'Could not create receipt storage.']);
        exit;
    }
    $filename = bin2hex(random_bytes(16)) . '.' . $extensions[$mime];
    if (!move_uploaded_file($receipt['tmp_name'], $receiptDirectory . '/' . $filename)) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'message' => 'Could not store the receipt.']);
        exit;
    }
    $receiptPath = '../api/order-receipts/' . $filename;
}

$orders[] = [
    'order_id' => 'PS-' . strtoupper(bin2hex(random_bytes(24))),
    'customer_name' => $name,
    'email' => $email,
    'method' => $method === 'crypto' ? 'crypto' : 'bank transfer',
    'amount' => round($amount, 2),
    'currency' => strtoupper(trim((string) ($_POST['currency'] ?? 'USD'))),
    'product' => $product,
    'product_id' => strtoupper($productReference),
    'listing_id' => (int) ($availableAccount['id'] ?? 0),
    'seller_email' => $paymentOwner,
    'transaction_id' => $transactionId,
    'payment_detail' => $paymentDetail,
    'receipt' => $receiptPath,
    'status' => 'pending',
    'created_at' => date(DATE_ATOM),
];
$order = $orders[array_key_last($orders)];
if (!$saveOrders($orders)) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'Could not save your order request.']);
    exit;
}

echo json_encode(['ok' => true, 'order' => $order], JSON_UNESCAPED_SLASHES);
