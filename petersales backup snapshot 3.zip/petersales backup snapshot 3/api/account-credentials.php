<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';
petershop_db_bootstrap();

session_start();
require_once __DIR__ . '/payment-settings-store.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

if (empty($_SESSION['auth_user']['email'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'message' => 'Authentication required.']);
    exit;
}

$listingId = trim((string) ($_GET['listing_id'] ?? ''));
if (!ctype_digit($listingId) || (int) $listingId < 1) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'Enter a valid listing ID.']);
    exit;
}

$currentEmail = strtolower(trim((string) $_SESSION['auth_user']['email']));
$findOwnedListing = static function (int $listingId) use ($currentEmail): ?array {
    $pdo = petershop_db_connect();
    $statement = $pdo->prepare('SELECT * FROM listings WHERE id = :id AND owner_email = :owner_email LIMIT 1');
    $statement->execute([':id' => $listingId, ':owner_email' => $currentEmail]);
    $row = $statement->fetch();
    if (!$row) {
        return null;
    }
    return [
        'id' => (int) ($row['id'] ?? 0),
        'product_id' => (string) ($row['product_id'] ?? ''),
        'owner_email' => strtolower((string) ($row['owner_email'] ?? '')),
        'game_email' => (string) ($row['game_email'] ?? ''),
        'game_password' => (string) ($row['game_password'] ?? ''),
    ];
};

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $account = $findOwnedListing((int) $listingId);
    if (!$account) {
        http_response_code(404);
        echo json_encode(['ok' => false, 'message' => 'Listing not found in your inventory.']);
        exit;
    }
    if (empty($account['game_email']) || empty($account['game_password'])) {
        http_response_code(404);
        echo json_encode(['ok' => false, 'message' => 'Credentials have not been saved for this listing.']);
        exit;
    }
    echo json_encode([
        'ok' => true,
        'listing_id' => (int) $account['id'],
        'product_id' => (string) ($account['product_id'] ?? ''),
        'email' => $account['game_email'],
        'password' => $account['game_password'],
    ], JSON_UNESCAPED_SLASHES);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'message' => 'Method not allowed.']);
    exit;
}

$input = $_POST;
if (!$input) {
    $decodedInput = json_decode((string) file_get_contents('php://input'), true);
    if (is_array($decodedInput)) $input = $decodedInput;
}
$email = trim((string) ($input['game_email'] ?? ''));
$password = trim((string) ($input['game_password'] ?? ''));
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'Enter a valid game account email and password.']);
    exit;
}

$account = $findOwnedListing((int) $listingId);
if (!$account) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'message' => 'Listing not found in your inventory.']);
    exit;
}

$pdo = petershop_db_connect();
$statement = $pdo->prepare('UPDATE listings SET game_email = :game_email, game_password = :game_password WHERE id = :id AND owner_email = :owner_email');
$statement->execute([
    ':game_email' => $email,
    ':game_password' => $password,
    ':id' => (int) $listingId,
    ':owner_email' => $currentEmail,
]);

petershop_write_json_cache();

echo json_encode(['ok' => true, 'listing_id' => (int) $listingId, 'product_id' => (string) ($account['product_id'] ?? '')]);
