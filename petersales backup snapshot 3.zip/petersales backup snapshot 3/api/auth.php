<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';
petershop_db_bootstrap();

session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

$loadSettings = static function (): array {
    return petershop_admin_settings_record();
};
$saveRequests = static function (string $key, array $request): bool {
    $pdo = petershop_db_connect();
    if ($key === 'password_resets') {
        $pdo->prepare('INSERT INTO password_resets (email, status, created_at) VALUES (:email, :status, :created_at)')->execute([
            ':email' => strtolower(trim((string) ($request['email'] ?? ''))),
            ':status' => (string) ($request['status'] ?? 'pending'),
            ':created_at' => (string) ($request['created_at'] ?? date('Y-m-d H:i:s')),
        ]);
        return true;
    }

    $pdo->prepare('INSERT INTO seller_requests (name, email, message, status, created_at) VALUES (:name, :email, :message, :status, :created_at)')->execute([
        ':name' => (string) ($request['name'] ?? ''),
        ':email' => strtolower(trim((string) ($request['email'] ?? ''))),
        ':message' => (string) ($request['message'] ?? ''),
        ':status' => (string) ($request['status'] ?? 'pending'),
        ':created_at' => (string) ($request['created_at'] ?? date('Y-m-d H:i:s')),
    ]);
    return true;
};

$input = $_POST;
if (!$input) {
    $decodedInput = json_decode((string) file_get_contents('php://input'), true);
    if (is_array($decodedInput)) $input = $decodedInput;
}
$action = trim((string) ($input['action'] ?? 'login'));
$settings = $loadSettings();

if ($action === 'login') {
    $email = strtolower(trim((string) ($input['email'] ?? '')));
    $password = (string) ($input['password'] ?? '');
    $account = null;
    if ($email !== '' && password_verify($password, (string) ($settings['password_hash'] ?? '')) && strtolower((string) ($settings['email'] ?? '')) === $email) {
        $account = ['name' => $settings['name'] ?? 'Peter Admin', 'email' => $settings['email'], 'role' => 'Administrator', 'area' => 'admin'];
    } else {
        foreach (($settings['sellers'] ?? []) as $seller) {
            if (strtolower((string) ($seller['email'] ?? '')) !== $email || ($seller['status'] ?? 'active') === 'banned' || !password_verify($password, (string) ($seller['password_hash'] ?? ''))) continue;
            $role = strtolower((string) ($seller['role'] ?? 'seller'));
            $account = ['name' => $seller['name'], 'email' => $seller['email'], 'role' => $seller['role'] ?? 'Seller', 'area' => $role === 'admin' ? 'admin' : 'adminseller'];
            break;
        }
    }
    if (!$account) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'message' => 'Invalid email or password.']);
        exit;
    }
    session_regenerate_id(true);
    $_SESSION['auth_user'] = $account;
    echo json_encode(['ok' => true, 'user' => $account], JSON_UNESCAPED_SLASHES);
    exit;
}

if ($action === 'logout') {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
    echo json_encode(['ok' => true]);
    exit;
}

if ($action === 'reset_request') {
    $email = strtolower(trim((string) ($input['email'] ?? '')));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'message' => 'Enter a valid email address.']);
        exit;
    }
    $saveRequests('password_resets', ['email' => $email, 'status' => 'pending', 'created_at' => date(DATE_ATOM)]);
    echo json_encode(['ok' => true, 'message' => 'Reset request received. An administrator will review it.']);
    exit;
}

if ($action === 'seller_request') {
    $name = trim((string) ($input['name'] ?? ''));
    $email = strtolower(trim((string) ($input['email'] ?? '')));
    $message = trim((string) ($input['message'] ?? ''));
    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'message' => 'Enter your name and a valid email address.']);
        exit;
    }
    $saveRequests('seller_requests', ['name' => $name, 'email' => $email, 'message' => $message, 'status' => 'pending', 'created_at' => date(DATE_ATOM)]);
    echo json_encode(['ok' => true, 'message' => 'Seller request received. An administrator will review it.']);
    exit;
}

http_response_code(400);
echo json_encode(['ok' => false, 'message' => 'Unknown authentication action.']);
