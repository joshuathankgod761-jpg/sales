<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';
petershop_db_bootstrap();

session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$settings = petershop_admin_settings_record();
$defaultOwnerEmail = strtolower(trim((string) ($settings['email'] ?? 'admin@petershop.com')));
$ownerNames = [$defaultOwnerEmail => (string) ($settings['name'] ?? 'Peter Admin')];
foreach (($settings['sellers'] ?? []) as $sellerAccount) {
    $ownerEmail = strtolower((string) ($sellerAccount['email'] ?? ''));
    $ownerName = trim((string) ($sellerAccount['name'] ?? ''));
    if ($ownerEmail !== '' && $ownerName !== '') $ownerNames[$ownerEmail] = $ownerName;
}
$publicAccounts = static function (array $accounts) use ($defaultOwnerEmail, $ownerNames): array {
    return array_map(static function (array $account) use ($defaultOwnerEmail, $ownerNames): array {
        $ownerEmail = strtolower((string) ($account['owner_email'] ?? $defaultOwnerEmail));
        if (trim((string) ($account['seller'] ?? '')) === '' || strcasecmp((string) ($account['seller'] ?? ''), 'Peter Admin') === 0) {
            $account['seller'] = $ownerNames[$ownerEmail] ?? ($account['seller'] ?? 'Peter Admin');
        }
        unset($account['game_email'], $account['game_password']);
        unset($account['owner_email']);
        return $account;
    }, $accounts);
};
$isSeller = ($_SESSION['auth_user']['area'] ?? '') === 'adminseller';
$sellerEmail = strtolower((string) ($_SESSION['auth_user']['email'] ?? ''));
$currentEmail = strtolower(trim((string) ($_SESSION['auth_user']['email'] ?? '')));
$mineOnly = ($_GET['mine'] ?? '') === '1';
$accountBelongsToSeller = static function (array $account) use ($isSeller, $sellerEmail): bool {
    return !$isSeller || strtolower((string) ($account['owner_email'] ?? '')) === $sellerEmail;
};
$accountBelongsToCurrentUser = static function (array $account) use ($currentEmail, $defaultOwnerEmail): bool {
    $ownerEmail = strtolower(trim((string) ($account['owner_email'] ?? $defaultOwnerEmail)));
    return $currentEmail !== '' && $ownerEmail === $currentEmail;
};

$loadAccounts = static function (): array {
    return petershop_listings_array();
};
$saveAccounts = static function (array $accounts) use ($defaultOwnerEmail): bool {
    $pdo = petershop_db_connect();
    foreach ($accounts as $account) {
        $pdo->prepare('INSERT INTO listings (id, product_id, title, price, level, tier, tag, meta, description, game_version, server, characters, evo_guns, booyah_pass, elite_pass, seller_name, rating, reviews, likes, status, created_at, game_email, game_password, image, category, featured, owner_email, outfits, emotes, arrival_animation, look_changer, max_evo_guns) VALUES (:id, :product_id, :title, :price, :level, :tier, :tag, :meta, :description, :game_version, :server, :characters, :evo_guns, :booyah_pass, :elite_pass, :seller_name, :rating, :reviews, :likes, :status, :created_at, :game_email, :game_password, :image, :category, :featured, :owner_email, :outfits, :emotes, :arrival_animation, :look_changer, :max_evo_guns) ON DUPLICATE KEY UPDATE product_id = VALUES(product_id), title = VALUES(title), price = VALUES(price), level = VALUES(level), tier = VALUES(tier), tag = VALUES(tag), meta = VALUES(meta), description = VALUES(description), game_version = VALUES(game_version), server = VALUES(server), characters = VALUES(characters), evo_guns = VALUES(evo_guns), booyah_pass = VALUES(booyah_pass), elite_pass = VALUES(elite_pass), seller_name = VALUES(seller_name), rating = VALUES(rating), reviews = VALUES(reviews), likes = VALUES(likes), status = VALUES(status), game_email = VALUES(game_email), game_password = VALUES(game_password), image = VALUES(image), category = VALUES(category), featured = VALUES(featured), owner_email = VALUES(owner_email), outfits = VALUES(outfits), emotes = VALUES(emotes), arrival_animation = VALUES(arrival_animation), look_changer = VALUES(look_changer), max_evo_guns = VALUES(max_evo_guns)')->execute([
            ':id' => (int) ($account['id'] ?? 0),
            ':product_id' => (string) ($account['product_id'] ?? ''),
            ':title' => (string) ($account['title'] ?? ''),
            ':price' => (string) ($account['price'] ?? '0'),
            ':level' => (int) ($account['level'] ?? 0),
            ':tier' => (string) ($account['tier'] ?? 'Bronze'),
            ':tag' => (string) ($account['tag'] ?? ''),
            ':meta' => (string) ($account['meta'] ?? ''),
            ':description' => (string) ($account['description'] ?? ''),
            ':game_version' => (string) ($account['gameVersion'] ?? 'Prime 1'),
            ':server' => (string) ($account['server'] ?? 'Indonesia'),
            ':characters' => (int) ($account['characters'] ?? 0),
            ':evo_guns' => (int) ($account['evoGuns'] ?? 0),
            ':booyah_pass' => (string) ($account['booyahPass'] ?? 'No'),
            ':elite_pass' => (string) ($account['elitePass'] ?? 'No'),
            ':seller_name' => (string) ($account['seller'] ?? 'Peter Admin'),
            ':rating' => (string) ($account['rating'] ?? '5.0'),
            ':reviews' => (int) ($account['reviews'] ?? 0),
            ':likes' => (int) ($account['likes'] ?? 0),
            ':status' => (string) ($account['status'] ?? 'active'),
            ':created_at' => (string) ($account['created_at'] ?? date('Y-m-d H:i:s')),
            ':game_email' => isset($account['game_email']) ? (string) $account['game_email'] : null,
            ':game_password' => isset($account['game_password']) ? (string) $account['game_password'] : null,
            ':image' => (string) ($account['image'] ?? ''),
            ':category' => (string) ($account['category'] ?? 'mythic'),
            ':featured' => !empty($account['featured']) ? 1 : 0,
            ':owner_email' => strtolower(trim((string) ($account['owner_email'] ?? $defaultOwnerEmail))),
            ':outfits' => (string) ($account['outfits'] ?? ''),
            ':emotes' => (string) ($account['emotes'] ?? ''),
            ':arrival_animation' => (string) ($account['arrivalAnimation'] ?? ''),
            ':look_changer' => (string) ($account['lookChanger'] ?? ''),
            ':max_evo_guns' => (string) ($account['maxEvoGuns'] ?? ''),
        ]);
    }
    petershop_write_json_cache();
    return true;
};

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $payload = file_get_contents('php://input');
    $input = $payload !== '' ? json_decode($payload, true) : [];
    if (!is_array($input) || $payload === '') {
        $input = $_POST;
    }

    $accounts = $loadAccounts();
    $action = trim((string) ($input['action'] ?? ''));
    if ($action !== '') {
        $targetId = (int) ($input['id'] ?? 0);
        if ($action === 'images') {
            $target = null;
            foreach ($accounts as $account) {
                if ((int) ($account['id'] ?? 0) === $targetId && $accountBelongsToSeller($account)) {
                    $target = $account;
                    break;
                }
            }
            if ($target === null) {
                http_response_code(404);
                echo json_encode(['ok' => false, 'message' => 'Listing not found in your inventory.']);
                exit;
            }
            $files = $_FILES['images'] ?? null;
            if (!$files || !isset($files['name']) || !is_array($files['name'])) {
                http_response_code(400);
                echo json_encode(['ok' => false, 'message' => 'Select one or more listing images.']);
                exit;
            }
            $uploadDirectory = dirname(__DIR__) . '/uploads/listings';
            if (!is_dir($uploadDirectory) && !mkdir($uploadDirectory, 0755, true) && !is_dir($uploadDirectory)) {
                http_response_code(500);
                echo json_encode(['ok' => false, 'message' => 'Could not prepare image storage.']);
                exit;
            }
            $pdo = petershop_db_connect();
            $countQuery = $pdo->prepare('SELECT COUNT(*) FROM listing_images WHERE listing_id = :listing_id');
            $countQuery->execute([':listing_id' => $targetId]);
            $imageCount = (int) $countQuery->fetchColumn();
            if ($imageCount === 0 && !empty($target['image'])) {
                $pdo->prepare('INSERT INTO listing_images (listing_id, image_path, position) VALUES (:listing_id, :image_path, 0)')->execute([
                    ':listing_id' => $targetId,
                    ':image_path' => (string) $target['image'],
                ]);
                $imageCount = 1;
            }
            if ($imageCount + count($files['name']) > 50) {
                http_response_code(400);
                echo json_encode(['ok' => false, 'message' => 'A listing can have no more than 50 images.']);
                exit;
            }
            $extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
            $savedPaths = [];
            foreach ($files['name'] as $index => $_name) {
                $error = (int) ($files['error'][$index] ?? UPLOAD_ERR_NO_FILE);
                $temporaryPath = (string) ($files['tmp_name'][$index] ?? '');
                $size = (int) ($files['size'][$index] ?? 0);
                if ($error !== UPLOAD_ERR_OK || $size < 1 || $size > 20 * 1024 * 1024) {
                    http_response_code(400);
                    echo json_encode(['ok' => false, 'message' => 'Each image must be valid and under 20 MB.']);
                    exit;
                }
                $mime = (new finfo(FILEINFO_MIME_TYPE))->file($temporaryPath);
                if (!isset($extensions[$mime]) || @getimagesize($temporaryPath) === false) {
                    http_response_code(400);
                    echo json_encode(['ok' => false, 'message' => 'Upload JPG, PNG, or WEBP images only.']);
                    exit;
                }
                $filename = bin2hex(random_bytes(16)) . '.' . $extensions[$mime];
                if (!move_uploaded_file($temporaryPath, $uploadDirectory . '/' . $filename)) {
                    http_response_code(500);
                    echo json_encode(['ok' => false, 'message' => 'Could not store one of the listing images.']);
                    exit;
                }
                $savedPaths[] = 'uploads/listings/' . $filename;
            }
            $positionQuery = $pdo->prepare('SELECT COALESCE(MAX(position), -1) + 1 FROM listing_images WHERE listing_id = :listing_id');
            $positionQuery->execute([':listing_id' => $targetId]);
            $position = (int) $positionQuery->fetchColumn();
            $insertImage = $pdo->prepare('INSERT INTO listing_images (listing_id, image_path, position) VALUES (:listing_id, :image_path, :position)');
            foreach ($savedPaths as $savedPath) {
                $insertImage->execute([':listing_id' => $targetId, ':image_path' => $savedPath, ':position' => $position++]);
            }
            if (empty($target['image']) || str_starts_with((string) $target['image'], 'https://images.unsplash.com/')) {
                $pdo->prepare('UPDATE listings SET image = :image WHERE id = :id')->execute([':image' => $savedPaths[0], ':id' => $targetId]);
            }
            $updated = array_values(array_filter(petershop_listings_array(), static fn (array $listing): bool => (int) $listing['id'] === $targetId));
            echo json_encode(['ok' => true, 'account' => $publicAccounts($updated)[0] ?? null], JSON_UNESCAPED_SLASHES);
            exit;
        }
        foreach ($accounts as $index => $account) {
            if ((int) ($account['id'] ?? 0) !== $targetId) {
                continue;
            }
            if ($isSeller && !$accountBelongsToSeller($account) && in_array($action, ['status', 'delete'], true)) {
                http_response_code(403);
                echo json_encode(['ok' => false, 'message' => 'You can only manage your own listings.']);
                exit;
            }

            if ($action === 'like' || $action === 'unlike') {
                $visitorId = trim((string) ($input['visitor_id'] ?? ''));
                if ($visitorId === '' || strlen($visitorId) > 128) {
                    http_response_code(400);
                    echo json_encode(['ok' => false, 'message' => 'A valid visitor identifier is required.']);
                    exit;
                }
                $ownerEmail = strtolower(trim((string) ($account['owner_email'] ?? $defaultOwnerEmail)));
                $pdo = petershop_db_connect();
                if ($action === 'like') {
                    $pdo->prepare('INSERT IGNORE INTO seller_profile_likes (owner_email, visitor_id) VALUES (:owner_email, :visitor_id)')->execute([':owner_email' => $ownerEmail, ':visitor_id' => hash('sha256', $visitorId)]);
                } else {
                    $pdo->prepare('DELETE FROM seller_profile_likes WHERE owner_email = :owner_email AND visitor_id = :visitor_id')->execute([':owner_email' => $ownerEmail, ':visitor_id' => hash('sha256', $visitorId)]);
                }
                petershop_sync_seller_profile($pdo, $ownerEmail);
                $accounts = $loadAccounts();
                $updatedAccount = array_values(array_filter($accounts, static fn (array $listing): bool => (int) $listing['id'] === $targetId));
                echo json_encode(['ok' => true, 'account' => $publicAccounts($updatedAccount)[0] ?? null], JSON_UNESCAPED_SLASHES);
                exit;
            } elseif ($action === 'status') {
                $status = trim((string) ($input['status'] ?? ''));
                if (!in_array($status, ['active', 'sold'], true)) {
                    http_response_code(400);
                    echo json_encode(['ok' => false, 'message' => 'Invalid listing status.']);
                    exit;
                }
                petershop_db_connect()->prepare('UPDATE listings SET status = :status WHERE id = :id')->execute([':status' => $status, ':id' => $targetId]);
            } elseif ($action === 'delete') {
                petershop_db_connect()->prepare('DELETE FROM listings WHERE id = :id')->execute([':id' => $targetId]);
                echo json_encode(['ok' => true, 'deleted' => $targetId]);
                exit;
            } else {
                http_response_code(400);
                echo json_encode(['ok' => false, 'message' => 'Unknown inventory action.']);
                exit;
            }

            $updatedAccount = array_values(array_filter($loadAccounts(), static fn (array $listing): bool => (int) $listing['id'] === $targetId));
            echo json_encode(['ok' => true, 'account' => $publicAccounts($updatedAccount)[0] ?? null], JSON_UNESCAPED_SLASHES);
            exit;
        }

        http_response_code(404);
        echo json_encode(['ok' => false, 'message' => 'Listing not found.']);
        exit;
    }

    if (empty($_SESSION['auth_user']['email']) || empty($_SESSION['auth_user']['name'])) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'message' => 'Sign in before publishing a listing.']);
        exit;
    }

    $nextId = 1;
    $nextProductNumber = 1;
    foreach ($accounts as $account) {
        $nextId = max($nextId, (int) ($account['id'] ?? 0) + 1);
        $existingProductId = trim((string) ($account['product_id'] ?? ''));
        if (preg_match('/^FF(\d+)$/i', $existingProductId, $matches)) {
            $nextProductNumber = max($nextProductNumber, (int) $matches[1] + 1);
        }
    }

    $title = trim((string) ($input['title'] ?? ''));
    $price = (float) ($input['price'] ?? 0);
    $level = (int) ($input['level'] ?? 0);
    $tier = trim((string) ($input['tier'] ?? 'Bronze'));
    $gameVersion = trim((string) ($input['gameVersion'] ?? 'Prime 1'));
    $server = trim((string) ($input['server'] ?? 'Indonesia'));
    $category = trim((string) ($input['category'] ?? 'all'));
    $tag = trim((string) ($input['tag'] ?? 'All 367 weapons'));
    $meta = trim((string) ($input['meta'] ?? ''));
    $description = trim((string) ($input['description'] ?? ''));
    $outfits = trim((string) ($input['outfits'] ?? ''));
    $emotes = trim((string) ($input['emotes'] ?? ''));
    $arrivalAnimation = trim((string) ($input['arrivalAnimation'] ?? ''));
    $lookChanger = trim((string) ($input['lookChanger'] ?? ''));
    $characters = (int) ($input['characters'] ?? 0);
    $evoGuns = (int) ($input['evoGuns'] ?? 0);
    $maxEvoGuns = trim((string) ($input['maxEvoGuns'] ?? ''));
    $booyahPass = trim((string) ($input['booyahPass'] ?? 'No'));
    $elitePass = trim((string) ($input['elitePass'] ?? 'No'));
    $rating = max(0, min(5, (float) ($input['rating'] ?? 5)));
    $gameEmail = trim((string) ($input['game_email'] ?? ''));
    $gamePassword = trim((string) ($input['game_password'] ?? ''));

    if ($title === '' || $price <= 0) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'message' => 'Title and price are required.'], JSON_UNESCAPED_SLASHES);
        exit;
    }
    if (($gameEmail === '') !== ($gamePassword === '') || ($gameEmail !== '' && !filter_var($gameEmail, FILTER_VALIDATE_EMAIL))) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'message' => 'Provide both a valid game account email and password, or leave both empty.']);
        exit;
    }

    $productId = 'FF' . str_pad((string) $nextProductNumber, 2, '0', STR_PAD_LEFT);
    $newAccount = [
        'id' => $nextId,
        'product_id' => $productId,
        'title' => $title,
        'price' => $price,
        'level' => $level,
        'tier' => $tier,
        'tag' => $tag,
        'meta' => $meta !== '' ? $meta : 'New listing',
        'description' => $description !== '' ? $description : "$title / $tier / Level $level / $server / $gameVersion",
        'gameVersion' => $gameVersion,
        'server' => $server,
        'characters' => $characters,
        'outfits' => $outfits,
        'emotes' => $emotes,
        'arrivalAnimation' => $arrivalAnimation,
        'lookChanger' => $lookChanger,
        'evoGuns' => $evoGuns,
        'maxEvoGuns' => $maxEvoGuns,
        'booyahPass' => $booyahPass,
        'elitePass' => $elitePass,
        'seller' => trim((string) $_SESSION['auth_user']['name']),
        'rating' => number_format($rating, 1, '.', ''),
        'reviews' => 0,
        'likes' => 0,
        'status' => 'active',
        'created_at' => date(DATE_ATOM),
        'game_email' => $gameEmail,
        'game_password' => $gamePassword,
        'image' => trim((string) ($input['image'] ?? 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=900&q=85')),
        'category' => $category === 'all' ? 'mythic' : $category,
        'featured' => false,
        'owner_email' => strtolower((string) $_SESSION['auth_user']['email']),
    ];

    $uploadFiles = $_FILES['images'] ?? $_FILES['image'] ?? null;
    if ($uploadFiles && isset($uploadFiles['name'])) {
        if (!is_array($uploadFiles['name'])) {
            foreach (['name', 'type', 'tmp_name', 'error', 'size'] as $key) $uploadFiles[$key] = [$uploadFiles[$key] ?? null];
        }
        $uploadDirectory = dirname(__DIR__) . '/uploads/listings';
        if (!is_dir($uploadDirectory) && !mkdir($uploadDirectory, 0755, true) && !is_dir($uploadDirectory)) {
            http_response_code(500);
            echo json_encode(['ok' => false, 'message' => 'Could not prepare image storage.']);
            exit;
        }
        $extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
        $newImagePaths = [];
        foreach ($uploadFiles['name'] as $fileIndex => $_fileName) {
            $uploadError = (int) ($uploadFiles['error'][$fileIndex] ?? UPLOAD_ERR_NO_FILE);
            if ($uploadError === UPLOAD_ERR_NO_FILE) continue;
            $temporaryPath = (string) ($uploadFiles['tmp_name'][$fileIndex] ?? '');
            $fileSize = (int) ($uploadFiles['size'][$fileIndex] ?? 0);
            $mime = $uploadError === UPLOAD_ERR_OK && $temporaryPath !== '' ? (new finfo(FILEINFO_MIME_TYPE))->file($temporaryPath) : '';
            if ($uploadError !== UPLOAD_ERR_OK || $fileSize < 1 || $fileSize > 20 * 1024 * 1024 || !isset($extensions[$mime]) || @getimagesize($temporaryPath) === false) {
                http_response_code(400);
                echo json_encode(['ok' => false, 'message' => 'Upload valid JPG, PNG, or WEBP images under 20 MB each.']);
                exit;
            }
            $filename = bin2hex(random_bytes(16)) . '.' . $extensions[$mime];
            if (!move_uploaded_file($temporaryPath, $uploadDirectory . '/' . $filename)) {
                http_response_code(500);
                echo json_encode(['ok' => false, 'message' => 'Could not store one of the listing images.']);
                exit;
            }
            $newImagePaths[] = 'uploads/listings/' . $filename;
        }
        if ($newImagePaths) $newAccount['image'] = $newImagePaths[0];
    } else {
        $newImagePaths = [];
    }

    $accounts[] = $newAccount;
    if (!$saveAccounts($accounts)) {
        foreach ($newImagePaths as $imagePath) @unlink(dirname(__DIR__) . '/' . $imagePath);
        http_response_code(500);
        echo json_encode(['ok' => false, 'message' => 'Could not save inventory.']);
        exit;
    }

    if ($newImagePaths) {
        $insertImage = petershop_db_connect()->prepare('INSERT INTO listing_images (listing_id, image_path, position) VALUES (:listing_id, :image_path, :position)');
        foreach ($newImagePaths as $position => $imagePath) {
            $insertImage->execute([':listing_id' => (int) $newAccount['id'], ':image_path' => $imagePath, ':position' => $position]);
        }
    }

    $savedAccount = array_values(array_filter($loadAccounts(), static fn (array $account): bool => (int) $account['id'] === (int) $newAccount['id']));
    echo json_encode(['ok' => true, 'account' => $publicAccounts($savedAccount)[0] ?? $publicAccounts([$newAccount])[0]], JSON_UNESCAPED_SLASHES);
    exit;
}

$accounts = $loadAccounts();
if ($isSeller) {
    $accounts = array_values(array_filter($accounts, $accountBelongsToSeller));
} elseif ($mineOnly) {
    $accounts = array_values(array_filter($accounts, $accountBelongsToCurrentUser));
}
echo json_encode(['ok' => true, 'accounts' => $publicAccounts($accounts)], JSON_UNESCAPED_SLASHES);
