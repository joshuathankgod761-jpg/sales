<?php

require_once __DIR__ . '/db.php';
petershop_db_bootstrap();

function peter_payment_defaults(): array
{
    return [
        'bank' => ['bank' => '', 'account_name' => '', 'iban' => '', 'reference_prefix' => ''],
        'crypto' => ['usdtTron' => '', 'usdtEthereum' => '', 'bitcoin' => '', 'litecoin' => '', 'ethereum' => '', 'usdc' => '', 'trx' => '', 'binance' => ''],
    ];
}

function peter_payment_default_owner_email(): string
{
    $settings = petershop_admin_settings_record();
    $email = strtolower(trim((string) ($settings['email'] ?? '')));
    return $email !== '' ? $email : 'admin@petershop.com';
}

function peter_payment_store_load(): array
{
    return petershop_payment_store_array();
}

function peter_payment_store_save(array $store): bool
{
    $pdo = petershop_db_connect();
    foreach (($store['owners'] ?? []) as $email => $settings) {
        $normalized = array_replace_recursive(peter_payment_defaults(), is_array($settings) ? $settings : []);
        $statement = $pdo->prepare('INSERT INTO payment_settings (owner_email, bank_json, crypto_json) VALUES (:owner_email, :bank_json, :crypto_json) ON DUPLICATE KEY UPDATE bank_json = VALUES(bank_json), crypto_json = VALUES(crypto_json)');
        $statement->execute([
            ':owner_email' => strtolower(trim((string) $email)),
            ':bank_json' => json_encode($normalized['bank'] ?? [], JSON_UNESCAPED_SLASHES),
            ':crypto_json' => json_encode($normalized['crypto'] ?? [], JSON_UNESCAPED_SLASHES),
        ]);
    }
    petershop_write_json_cache();
    return true;
}

function peter_payment_for_owner(array $store, string $ownerEmail): array
{
    $ownerEmail = strtolower(trim($ownerEmail));
    $settings = $store['owners'][$ownerEmail] ?? null;
    return array_replace_recursive(peter_payment_defaults(), is_array($settings) ? $settings : []);
}

function peter_payment_account_owner(string $productIdentifier): ?string
{
    $accounts = petershop_listings_array();
    foreach ($accounts as $account) {
        $idMatches = ctype_digit($productIdentifier) && (string) ($account['id'] ?? '') === $productIdentifier;
        $productMatches = strcasecmp((string) ($account['product_id'] ?? ''), $productIdentifier) === 0;
        if (!$idMatches && !$productMatches) continue;
        return strtolower(trim((string) ($account['owner_email'] ?? peter_payment_default_owner_email())));
    }
    return null;
}