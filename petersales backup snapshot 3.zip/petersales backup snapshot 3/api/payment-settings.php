<?php
declare(strict_types=1);

session_start();
require_once __DIR__ . '/payment-settings-store.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $store = peter_payment_store_load();
    $productIdentifier = trim((string) ($_GET['product_id'] ?? ''));
    if ($productIdentifier !== '') {
        $ownerEmail = peter_payment_account_owner($productIdentifier);
        if ($ownerEmail === null) {
            http_response_code(404);
            echo json_encode(['ok' => false, 'message' => 'Account listing not found.']);
            exit;
        }
    } else {
        $ownerEmail = strtolower(trim((string) ($_SESSION['auth_user']['email'] ?? '')));
        if ($ownerEmail === '') {
            echo json_encode(['ok' => true, 'settings' => peter_payment_defaults()], JSON_UNESCAPED_SLASHES);
            exit;
        }
    }
    echo json_encode(['ok' => true, 'settings' => peter_payment_for_owner($store, $ownerEmail)], JSON_UNESCAPED_SLASHES);
    exit;
}

if (empty($_SESSION['auth_user'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'message' => 'Authentication required.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'message' => 'Method not allowed.']);
    exit;
}

$input = $_POST;
if (!$input) {
    $input = json_decode((string) file_get_contents('php://input'), true) ?: [];
}

$ownerEmail = strtolower(trim((string) ($_SESSION['auth_user']['email'] ?? '')));
if ($ownerEmail === '') {
    http_response_code(403);
    echo json_encode(['ok' => false, 'message' => 'Your account does not have a payment-settings owner.']);
    exit;
}
$store = peter_payment_store_load();
$settings = peter_payment_for_owner($store, $ownerEmail);
$section = (string) ($input['section'] ?? '');
$action = (string) ($input['action'] ?? 'save');

if ($action === 'delete') {
    if ($section !== 'bank' && $section !== 'crypto') {
        http_response_code(400);
        echo json_encode(['ok' => false, 'message' => 'Invalid payment section.']);
        exit;
    }
    foreach (array_keys($settings[$section]) as $key) $settings[$section][$key] = '';

    $store['owners'][$ownerEmail] = $settings;
    if (!peter_payment_store_save($store)) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'message' => 'Could not delete payment details.']);
        exit;
    }

    echo json_encode(['ok' => true, 'settings' => $settings], JSON_UNESCAPED_SLASHES);
    exit;
}

if ($section !== 'bank' && $section !== 'crypto') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'Invalid payment section.']);
    exit;
}

$allowedKeys = $section === 'bank'
    ? ['bank' => 'bank', 'account_name' => 'account_name', 'iban' => 'iban', 'reference_prefix' => 'reference_prefix']
    : ['usdtTron' => 'usdtTron', 'usdtEthereum' => 'usdtEthereum', 'bitcoin' => 'bitcoin', 'litecoin' => 'litecoin', 'ethereum' => 'ethereum', 'usdc' => 'usdc', 'trx' => 'trx', 'binance' => 'binance'];

foreach ($allowedKeys as $outputKey => $inputKey) {
    $rawValue = trim((string) ($input[$section . '_' . $inputKey] ?? ''));
    if ($section === 'bank') {
        $settings['bank'][$outputKey] = $rawValue;
    } else {
        $settings['crypto'][$outputKey] = $rawValue;
    }
}

if (in_array('', $settings[$section], true)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'Complete every field before saving this payment method.']);
    exit;
}

$store['owners'][$ownerEmail] = $settings;
if (!peter_payment_store_save($store)) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'Could not save payment settings.']);
    exit;
}

echo json_encode(['ok' => true, 'settings' => $settings], JSON_UNESCAPED_SLASHES);
