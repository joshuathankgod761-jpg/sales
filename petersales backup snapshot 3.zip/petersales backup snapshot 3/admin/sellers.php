<?php
$requiredArea = 'admin';
require_once __DIR__ . '/../auth.php';
$pageTitle = 'Sellers | Peter Shop Admin';
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="stylesheet" href="admin.css?v=<?= filemtime(__DIR__ . '/admin.css') ?>">
  <style>
    .sellers-content { padding-top: 30px; }
    .sellers-panel { max-width: 1100px; }
    .sellers-panel .panel-heading { align-items: center; }
    .seller-count { display: inline-grid; min-width: 24px; min-height: 24px; margin-left: 7px; padding: 0 7px; place-items: center; border-radius: 12px; background: var(--panel-light); color: var(--muted); font-size: 11px; vertical-align: middle; }
    .seller-table-wrap { margin-top: 22px; overflow-x: auto; }
    .seller-table { width: 100%; min-width: 650px; border-collapse: collapse; }
    .seller-table th, .seller-table td { padding: 14px 12px; border-bottom: 1px solid var(--line); text-align: left; }
    .seller-table th { color: var(--muted); font-size: 9px; letter-spacing: 1.2px; }
    .seller-profile { display: flex; align-items: center; gap: 10px; }
    .seller-avatar { display: grid; width: 34px; height: 34px; place-items: center; border-radius: 50%; background: var(--acid); color: var(--bg); font-weight: 800; }
    .seller-profile strong, .seller-profile small { display: block; }
    .seller-profile small { margin-top: 3px; color: var(--muted); }
    .seller-status { display: inline-flex; padding: 5px 8px; border: 1px solid rgba(216,255,62,.28); border-radius: 5px; background: rgba(216,255,62,.08); color: var(--acid); font-size: 10px; font-weight: 700; text-transform: uppercase; }
    .seller-status.banned { border-color: rgba(255,108,72,.3); background: rgba(255,108,72,.1); color: #ff9b83; }
    .seller-status.verified { border-color: rgba(142,216,255,.35); background: rgba(142,216,255,.1); color: var(--blue); }
    .ban-seller { padding: 8px 11px; border: 1px solid rgba(255,108,72,.4); border-radius: 6px; background: transparent; color: #ff9b83; font-size: 11px; font-weight: 700; }
    .ban-seller:hover { background: rgba(255,108,72,.12); }
    .ban-seller:disabled { cursor: not-allowed; opacity: .45; }
    .verify-seller { margin-right: 6px; padding: 8px 11px; border: 1px solid rgba(142,216,255,.4); border-radius: 6px; background: transparent; color: var(--blue); font-size: 11px; font-weight: 700; }
    .verify-seller:hover { background: rgba(142,216,255,.12); }
    .verify-seller:disabled { cursor: not-allowed; opacity: .45; }
    .seller-empty { padding: 32px 12px; color: var(--muted); text-align: center; }
  </style>
</head>
<body>
  <div class="admin-shell">
    <?php include __DIR__ . '/nav.php'; ?>
    <main class="admin-main">
      <header class="admin-topbar"><button class="mobile-menu" type="button" aria-label="Open menu">☰</button><div><p class="eyebrow">TEAM ACCESS</p><h1>Sellers</h1></div><div class="top-actions"><a class="outline-button" href="settings.php">+ Add seller</a></div></header>
      <section class="admin-content sellers-content">
        <section class="panel sellers-panel"><div class="panel-heading"><div><p class="eyebrow">SELLER DIRECTORY</p><h2>All sellers <span class="seller-count" id="seller-count">0</span></h2><span class="panel-subtitle">Review seller profiles and manage access.</span></div></div><div class="seller-table-wrap"><table class="seller-table"><thead><tr><th>SELLER</th><th>ROLE</th><th>EMAIL</th><th>STATUS</th><th>ACTION</th></tr></thead><tbody id="seller-rows"><tr><td colspan="5" class="seller-empty">Loading sellers...</td></tr></tbody></table></div></section>
      </section>
    </main>
  </div>
  <script>
    const sellerRows = document.getElementById('seller-rows');
    const sellerCount = document.getElementById('seller-count');
    const escapeHtml = value => { const node = document.createElement('span'); node.textContent = String(value ?? ''); return node.innerHTML; };
    let sellers = [];
    const renderSellers = () => {
      sellerCount.textContent = sellers.length;
      sellerRows.innerHTML = sellers.length ? sellers.map(seller => {
        const banned = seller.status === 'banned';
        const name = escapeHtml(seller.name || 'Unnamed seller');
        const initial = escapeHtml((seller.name || '?').trim().charAt(0).toUpperCase());
        const verified = seller.verified === true && !banned;
        return `<tr><td><div class="seller-profile"><span class="seller-avatar">${initial}</span><span><strong>${name}</strong><small>Added ${seller.created_at ? new Date(seller.created_at).toLocaleDateString() : 'recently'}</small></span></div></td><td>${escapeHtml(seller.role || 'Seller')}</td><td>${escapeHtml(seller.email || '')}</td><td><span class="seller-status ${banned ? 'banned' : verified ? 'verified' : ''}">${banned ? 'Banned' : verified ? 'Verified' : 'Active'}</span></td><td><button class="verify-seller" type="button" data-seller-id="${escapeHtml(seller.id)}" data-verified="${verified ? 'true' : 'false'}" ${banned ? 'disabled' : ''}>${verified ? 'Unverify seller' : 'Verify seller'}</button><button class="ban-seller" type="button" data-seller-id="${escapeHtml(seller.id)}" data-banned="${banned ? 'true' : 'false'}">${banned ? 'Unban seller' : 'Ban seller'}</button></td></tr>`;
      }).join('') : '<tr><td colspan="5" class="seller-empty">No sellers have been added yet. Use Add seller to create the first profile.</td></tr>';
    };
    const loadSellers = () => fetch('../api/admin-settings.php', { cache: 'no-store' }).then(response => response.json()).then(result => {
      if (!result.ok) throw new Error(result.message || 'Could not load sellers.');
      sellers = Array.isArray(result.settings?.sellers) ? result.settings.sellers : [];
      renderSellers();
    }).catch(() => { sellerRows.innerHTML = '<tr><td colspan="5" class="seller-empty">Could not load sellers.</td></tr>'; });
    loadSellers();
    sellerRows.addEventListener('click', async event => {
      const verifyButton = event.target.closest('.verify-seller');
      if (verifyButton && !verifyButton.disabled && window.confirm(`${verifyButton.dataset.verified === 'true' ? 'Unverify' : 'Verify'} this seller?`)) {
        verifyButton.disabled = true;
        try {
          const verified = verifyButton.dataset.verified === 'true';
          const response = await fetch('../api/admin-settings.php', { method: 'POST', body: new URLSearchParams({ action: verified ? 'unverify_seller' : 'verify_seller', seller_id: verifyButton.dataset.sellerId }) });
          const result = await response.json();
          if (!response.ok || !result.ok) throw new Error(result.message || `Could not ${verified ? 'unverify' : 'verify'} seller.`);
          sellers = sellers.map(seller => seller.id === verifyButton.dataset.sellerId ? { ...seller, verified: !verified } : seller);
          renderSellers();
        } catch (error) { verifyButton.disabled = false; window.alert(error.message || 'Could not verify seller.'); }
        return;
      }
      const button = event.target.closest('.ban-seller');
      if (!button || button.disabled || !window.confirm(`${button.dataset.banned === 'true' ? 'Unban' : 'Ban'} this seller?`)) return;
      button.disabled = true;
      try {
        const banned = button.dataset.banned === 'true';
        const response = await fetch('../api/admin-settings.php', { method: 'POST', body: new URLSearchParams({ action: banned ? 'unban_seller' : 'ban_seller', seller_id: button.dataset.sellerId }) });
        const result = await response.json();
        if (!response.ok || !result.ok) throw new Error(result.message || `Could not ${banned ? 'unban' : 'ban'} seller.`);
        sellers = sellers.map(seller => seller.id === button.dataset.sellerId ? { ...seller, status: banned ? 'active' : 'banned' } : seller);
        renderSellers();
      } catch (error) { button.disabled = false; window.alert(error.message || 'Could not ban seller.'); }
    });
  </script>
</body>
</html>
