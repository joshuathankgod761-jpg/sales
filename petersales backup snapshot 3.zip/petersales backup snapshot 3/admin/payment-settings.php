﻿<?php
$requiredArea = null;
require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../api/payment-settings-store.php';
$isSellerWorkspace = ($_SESSION['auth_user']['area'] ?? '') === 'adminseller';
$paymentOwnerEmail = strtolower((string) ($_SESSION['auth_user']['email'] ?? ''));
$pageTitle = 'Payment account details | Peter Shop Admin';
$navFile = $isSellerWorkspace ? __DIR__ . '/../adminseller/nav.php' : __DIR__ . '/nav.php';
$settings = peter_payment_for_owner(peter_payment_store_load(), $paymentOwnerEmail);
$bankHasDetails = count(array_filter($settings['bank'], static fn ($value) => trim((string) $value) !== '')) > 0;
$cryptoHasDetails = count(array_filter($settings['crypto'], static fn ($value) => trim((string) $value) !== '')) > 0;
$bankLabels = [
    'bank' => 'Bank',
    'account_name' => 'Account name',
    'iban' => 'IBAN / account number',
    'reference_prefix' => 'Reference prefix',
];
$cryptoLabels = [
    'usdtTron' => 'USDT · TRC-20',
    'usdtEthereum' => 'USDT · ERC-20',
    'bitcoin' => 'Bitcoin',
    'litecoin' => 'Litecoin',
    'ethereum' => 'Ethereum · ERC-20',
    'usdc' => 'USDC · ERC-20',
    'trx' => 'TRX · Tron',
    'binance' => 'BNB · BEP-20',
];
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?></title>
    <link rel="stylesheet" href="admin.css?v=<?= filemtime(__DIR__ . '/admin.css') ?>">
    <style>
        body { overflow-x: hidden; }
        .admin-sidebar { position: sticky; top: 0; height: 100vh; min-height: 0; overflow-y: auto; }
        .admin-topbar { position: sticky; top: 0; z-index: 20; }
        .payment-settings-content { padding-top: 30px; }
        .payment-settings-layout { display: grid; gap: 20px; max-width: 1050px; }
        .payment-panel { padding: 24px; }
        .payment-panel h2 { margin: 0 0 6px; }
        .payment-copy { margin: 0; color: var(--muted); line-height: 1.5; }
        .payment-method-list { display: grid; gap: 18px; margin-top: 22px; }
        .payment-method-card {
            padding: 20px;
            border: 1px solid var(--line);
            border-radius: 14px;
            background: rgba(255,255,255,.02);
        }
        .payment-method-head {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 18px;
            margin-bottom: 16px;
        }
        .payment-method-copy h3 {
            margin: 5px 0 0;
            font-size: 22px;
        }
        .toggle-label {
            display: inline-flex;
            align-items: center;
            gap: 12px;
            cursor: pointer;
            color: var(--ink);
            font-weight: 600;
            user-select: none;
        }
        .toggle-label input {
            position: absolute;
            opacity: 0;
            pointer-events: none;
        }
        .toggle-track {
            position: relative;
            display: inline-flex;
            width: 62px;
            height: 34px;
            padding: 4px;
            border-radius: 999px;
            background: rgba(255,255,255,.12);
            box-shadow: inset 0 0 0 1px rgba(255,255,255,.08);
            transition: background .2s ease, box-shadow .2s ease;
        }
        .toggle-track::before {
            content: '';
            position: absolute;
            width: 26px;
            height: 26px;
            top: 4px;
            left: 4px;
            border-radius: 50%;
            background: #fff;
            box-shadow: 0 3px 10px rgba(0,0,0,.28);
            transition: transform .22s ease;
        }
        .toggle-label input:checked + .toggle-track {
            background: linear-gradient(135deg, var(--acid), #98ff98);
            box-shadow: inset 0 0 0 1px rgba(255,255,255,.12), 0 0 0 4px rgba(216,255,62,.12);
        }
        .toggle-label input:checked + .toggle-track::before {
            transform: translateX(28px);
        }
        .toggle-text {
            min-width: 220px;
            text-align: right;
            color: var(--muted);
            font-size: 12px;
        }
        .toggle-label input:checked ~ .toggle-text {
            color: var(--ink);
        }
        .payment-method-body {
            display: grid;
            gap: 14px;
        }
        .payment-method-body [hidden] {
          display: none !important;
        }
        .empty-payment,
        .current-payment {
            border: 1px dashed var(--line);
            border-radius: 10px;
            background: rgba(255,255,255,.02);
            padding: 16px;
        }
        .empty-payment {
            color: var(--muted);
            font-size: 12px;
        }
        .current-payment {
            display: grid;
            gap: 12px;
        }
        .current-payment-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
        }
        .current-payment-top strong {
            display: block;
            font-size: 13px;
            color: var(--ink);
        }
        .current-payment-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }
        .primary-button,
        .outline-button,
        .danger-button,
        .dialog-close {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 38px;
            padding: 10px 14px;
            border-radius: 8px;
            border: 1px solid transparent;
            font-size: 12px;
            font-weight: 700;
            transition: transform .15s ease, opacity .15s ease;
        }
        .primary-button {
            background: var(--acid);
            color: var(--bg);
        }
        .outline-button {
            background: transparent;
            border-color: var(--line);
            color: var(--ink);
        }
        .danger-button {
            background: rgba(255,138,96,.12);
            border-color: rgba(255,138,96,.28);
            color: #ffb19a;
        }
        .primary-button:hover,
        .outline-button:hover,
        .danger-button:hover,
        .dialog-close:hover {
            transform: translateY(-1px);
        }
        .payment-form {
            display: grid;
            gap: 16px;
            margin-top: 8px;
        }
        .payment-fields {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 14px;
        }
        .payment-fields label {
            display: grid;
            gap: 7px;
            color: var(--muted);
            font-size: 12px;
            font-weight: 600;
        }
        .payment-fields input {
            width: 100%;
            min-height: 42px;
            box-sizing: border-box;
            padding: 10px 12px;
            border: 1px solid var(--line);
            border-radius: 7px;
            background: var(--panel-light);
            color: var(--ink);
        }
        .payment-fields input:focus {
            outline: 2px solid rgba(216,255,62,.2);
            border-color: var(--acid);
        }
        .payment-status {
            min-height: 18px;
            margin: 0;
            color: var(--acid);
            font-size: 12px;
        }
        .payment-status.error {
            color: #ff9b83;
        }
        .detail-modal-backdrop {
            position: fixed;
            inset: 0;
            z-index: 50;
            display: grid;
            place-items: center;
            padding: 20px;
            background: rgba(2,4,6,.72);
        }
        .detail-modal-backdrop[hidden] {
            display: none;
        }
        .detail-modal {
            width: min(560px, 100%);
            background: #11171a;
            border: 1px solid var(--line);
            border-radius: 18px;
            box-shadow: 0 20px 50px rgba(0,0,0,.34);
            overflow: hidden;
        }
        .detail-modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            padding: 18px 20px 12px;
            border-bottom: 1px solid var(--line);
        }
        .detail-modal-header h3 {
            margin: 0;
            font-size: 22px;
        }
        .dialog-close {
            width: 38px;
            min-width: 38px;
            min-height: 38px;
            padding: 0;
            border-color: var(--line);
            background: transparent;
            color: var(--ink);
        }
        .detail-modal-body { padding: 16px 20px 20px; }
        .detail-table {
            width: 100%;
            border-collapse: collapse;
            color: var(--ink);
            font-size: 12px;
        }
        .detail-table th,
        .detail-table td {
            padding: 10px 12px;
            border-bottom: 1px solid var(--line);
            text-align: left;
            vertical-align: top;
        }
        .detail-table th {
            width: 40%;
            color: var(--muted);
            font-weight: 700;
        }
        .detail-table td {
            color: var(--ink);
            word-break: break-word;
        }
        @media (max-width: 620px) {
            .payment-fields { grid-template-columns: 1fr; }
            .payment-panel { padding: 18px; }
            .payment-method-head,
            .current-payment-top,
            .current-payment-actions { flex-direction: column; align-items: flex-start; }
            .toggle-text { min-width: auto; text-align: left; }
        }
    </style>
</head>
<body>
    <div class="admin-shell">
        <?php include $navFile; ?>
        <main class="admin-main">
            <header class="admin-topbar">
                <button class="mobile-menu" type="button" aria-label="Open menu">☰</button>
                <div>
                    <p class="eyebrow">PAYMENT MANAGEMENT</p>
                    <h1>Payment account details</h1>
                </div>
                <div class="top-actions">
                    <a class="outline-button" href="<?= $isSellerWorkspace ? 'admin.php#dashboard' : 'admin.php#dashboard' ?>">← Dashboard</a>
                </div>
            </header>
            <section class="admin-content payment-settings-content">
                <section class="panel payment-panel">
                    <p class="eyebrow">YOUR CHECKOUT ACCOUNTS</p>
                    <h2>Payment methods</h2>
                    <p class="payment-copy">Customers will see only payment methods you complete below for your listings.</p>

                    <div class="payment-method-list">
                        <article class="payment-method-card" data-method="bank">
                            <div class="payment-method-head">
                                <div class="payment-method-copy">
                                    <p class="eyebrow">BANK TRANSFER</p>
                                    <h3>Bank transfer</h3>
                                </div>
                                <label class="toggle-label">
                                    <input class="payment-toggle-input" data-section="bank" type="checkbox" <?= $bankHasDetails ? 'checked' : '' ?>>
                                    <span class="toggle-track" aria-hidden="true"></span>
                                    <span class="toggle-text"><?= $bankHasDetails ? 'I have bank transfer account' : 'I don’t have bank transfer account' ?></span>
                                </label>
                            </div>
                            <div class="payment-method-body">
                                <div class="empty-payment" data-section="bank" <?= $bankHasDetails ? 'hidden' : '' ?>>No bank transfer account saved yet.</div>
                                <div class="current-payment" data-section="bank" <?= $bankHasDetails ? '' : 'hidden' ?>>
                                    <div class="current-payment-top">
                                        <strong>Current payment details</strong>
                                        <button class="danger-button delete-current-payment" data-section="bank" type="button">Delete current payment</button>
                                    </div>
                                    <div class="current-payment-actions">
                                        <button class="primary-button view-payment-details" data-section="bank" type="button">View payment details</button>
                                    </div>
                                </div>
                                <form class="payment-form" data-section="bank" <?= $bankHasDetails ? 'hidden' : '' ?>>
                                    <div class="payment-fields">
                                        <label>Bank<input name="bank_bank" value="<?= htmlspecialchars((string) ($settings['bank']['bank'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" required></label>
                                        <label>Account name<input name="bank_account_name" value="<?= htmlspecialchars((string) ($settings['bank']['account_name'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" required></label>
                                        <label>IBAN / account number<input name="bank_iban" value="<?= htmlspecialchars((string) ($settings['bank']['iban'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" required></label>
                                        <label>Reference prefix<input name="bank_reference_prefix" value="<?= htmlspecialchars((string) ($settings['bank']['reference_prefix'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" required></label>
                                    </div>
                                    <p class="payment-status" data-section="bank" role="status"></p>
                                    <button class="primary-button" type="submit">Save bank transfer</button>
                                </form>
                            </div>
                        </article>

                        <article class="payment-method-card" data-method="crypto">
                            <div class="payment-method-head">
                                <div class="payment-method-copy">
                                    <p class="eyebrow">CRYPTO</p>
                                    <h3>Crypto</h3>
                                </div>
                                <label class="toggle-label">
                                    <input class="payment-toggle-input" data-section="crypto" type="checkbox" <?= $cryptoHasDetails ? 'checked' : '' ?>>
                                    <span class="toggle-track" aria-hidden="true"></span>
                                    <span class="toggle-text"><?= $cryptoHasDetails ? 'I have crypto account' : 'I don’t have crypto account' ?></span>
                                </label>
                            </div>
                            <div class="payment-method-body">
                                <div class="empty-payment" data-section="crypto" <?= $cryptoHasDetails ? 'hidden' : '' ?>>No crypto account saved yet.</div>
                                <div class="current-payment" data-section="crypto" <?= $cryptoHasDetails ? '' : 'hidden' ?>>
                                    <div class="current-payment-top">
                                        <strong>Current payment details</strong>
                                        <button class="danger-button delete-current-payment" data-section="crypto" type="button">Delete current payment</button>
                                    </div>
                                    <div class="current-payment-actions">
                                        <button class="primary-button view-payment-details" data-section="crypto" type="button">View payment details</button>
                                    </div>
                                </div>
                                <form class="payment-form" data-section="crypto" <?= $cryptoHasDetails ? 'hidden' : '' ?>>
                                    <div class="payment-fields">
                                        <label>USDT · TRC-20<input name="crypto_usdtTron" value="<?= htmlspecialchars((string) ($settings['crypto']['usdtTron'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" required></label>
                                        <label>USDT · ERC-20<input name="crypto_usdtEthereum" value="<?= htmlspecialchars((string) ($settings['crypto']['usdtEthereum'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" required></label>
                                        <label>Bitcoin<input name="crypto_bitcoin" value="<?= htmlspecialchars((string) ($settings['crypto']['bitcoin'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" required></label>
                                        <label>Litecoin<input name="crypto_litecoin" value="<?= htmlspecialchars((string) ($settings['crypto']['litecoin'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" required></label>
                                        <label>Ethereum · ERC-20<input name="crypto_ethereum" value="<?= htmlspecialchars((string) ($settings['crypto']['ethereum'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" required></label>
                                        <label>USDC · ERC-20<input name="crypto_usdc" value="<?= htmlspecialchars((string) ($settings['crypto']['usdc'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" required></label>
                                        <label>TRX · Tron<input name="crypto_trx" value="<?= htmlspecialchars((string) ($settings['crypto']['trx'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" required></label>
                                        <label>BNB · BEP-20<input name="crypto_binance" value="<?= htmlspecialchars((string) ($settings['crypto']['binance'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" required></label>
                                    </div>
                                    <p class="payment-status" data-section="crypto" role="status"></p>
                                    <button class="primary-button" type="submit">Save crypto accounts</button>
                                </form>
                            </div>
                        </article>
                    </div>
                </section>
            </section>
        </main>
    </div>

    <div class="detail-modal-backdrop" id="detail-modal-backdrop" hidden>
        <div class="detail-modal" role="dialog" aria-modal="true" aria-labelledby="detail-modal-title">
            <div class="detail-modal-header">
                <h3 id="detail-modal-title">Payment details</h3>
                <button class="dialog-close" type="button" aria-label="Close payment details">×</button>
            </div>
            <div class="detail-modal-body">
                <table class="detail-table" id="detail-table-body">
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
      const paymentSettings = <?= json_encode($settings, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>;
      const methodMeta = {
        bank: {
          labels: {
            bank: 'Bank',
            account_name: 'Account name',
            iban: 'IBAN / account number',
            reference_prefix: 'Reference prefix',
          },
          onText: 'I have bank transfer account',
          offText: 'I don’t have bank transfer account',
          emptyState: 'No bank transfer account saved yet.'
        },
        crypto: {
          labels: {
            usdtTron: 'USDT · TRC-20',
            usdtEthereum: 'USDT · ERC-20',
            bitcoin: 'Bitcoin',
            litecoin: 'Litecoin',
            ethereum: 'Ethereum · ERC-20',
            usdc: 'USDC · ERC-20',
            trx: 'TRX · Tron',
            binance: 'BNB · BEP-20'
          },
          onText: 'I have crypto account',
          offText: 'I don’t have crypto account',
          emptyState: 'No crypto account saved yet.'
        }
      };

      const hasAnyValues = (values = {}) => Object.values(values).some((value) => String(value ?? '').trim() !== '');
      const getToggle = (section) => document.querySelector(`.payment-toggle-input[data-section="${section}"]`);
      const getForm = (section) => document.querySelector(`.payment-form[data-section="${section}"]`);
      const getEmptyState = (section) => document.querySelector(`.empty-payment[data-section="${section}"]`);
      const getCurrentPayment = (section) => document.querySelector(`.current-payment[data-section="${section}"]`);
      const getStatus = (section) => document.querySelector(`.payment-status[data-section="${section}"]`);

      const syncSectionState = (section, hasDetails, shouldShowForm = false) => {
        const toggle = getToggle(section);
        const form = getForm(section);
        const emptyState = getEmptyState(section);
        const currentPayment = getCurrentPayment(section);
        const status = getStatus(section);

        if (!toggle) return;
        toggle.checked = hasDetails || shouldShowForm;
        toggle.disabled = hasDetails;
        const textEl = toggle.parentElement.querySelector('.toggle-text');
        if (textEl) textEl.textContent = toggle.checked ? methodMeta[section].onText : methodMeta[section].offText;

        if (hasDetails) {
          form.hidden = true;
          currentPayment.hidden = false;
          emptyState.hidden = true;
        } else {
          form.hidden = !shouldShowForm;
          currentPayment.hidden = true;
          emptyState.hidden = !(!shouldShowForm);
        }

        if (status) {
          status.textContent = '';
          status.classList.remove('error');
        }
      };

      const openDetails = (section) => {
        const detailModal = document.getElementById('detail-modal-backdrop');
        const tableBody = document.getElementById('detail-table-body');
        const rows = Object.entries(methodMeta[section].labels).map(([key, label]) => {
          const value = paymentSettings[section][key] ?? '';
          return [label, String(value).trim()];
        }).filter(([, value]) => value !== '');

        if (!rows.length) {
          detailModal.hidden = false;
          tableBody.innerHTML = '<tr><td colspan="2">No payment details saved yet.</td></tr>';
          return;
        }

        tableBody.innerHTML = rows.map(([label, value]) => `
          <tr>
            <th>${label}</th>
            <td>${value}</td>
          </tr>
        `).join('');
        detailModal.hidden = false;
      };

      const closeDetails = () => {
        document.getElementById('detail-modal-backdrop').hidden = true;
      };

      const readJsonResponse = async (response) => {
        const text = await response.text();
        if (!text || !text.trim()) {
          throw new Error('Empty response from the server.');
        }
        try {
          return JSON.parse(text);
        } catch (error) {
          const preview = text.replace(/\s+/g, ' ').trim().slice(0, 180);
          throw new Error(preview || 'The server returned an invalid response.');
        }
      };

      const saveSection = async (event) => {
        event.preventDefault();
        const form = event.currentTarget;
        const section = form.dataset.section;
        const status = getStatus(section);
        if (!status) return;
        status.classList.remove('error');
        status.textContent = 'Saving...';

        const payload = new URLSearchParams();
        payload.set('action', 'save');
        payload.set('section', section);
        const formData = new FormData(form);
        for (const [key, value] of formData.entries()) {
            payload.set(key, String(value));
        }

        try {
          const response = await fetch('../api/payment-settings.php', {
            method: 'POST',
            body: payload,
            credentials: 'same-origin',
            cache: 'no-store'
          });
          const result = await readJsonResponse(response);
          if (!response.ok || !result.ok) {
            if (response.status === 401) {
              throw new Error('Your session has expired. Please sign in again.');
            }
            throw new Error(result.message || 'Could not save payment details.');
          }

          paymentSettings[section] = result.settings[section] || {};
          status.textContent = section === 'bank' ? 'Bank transfer saved.' : 'Crypto account saved.';
          syncSectionState(section, hasAnyValues(paymentSettings[section]), false);
        } catch (error) {
          status.textContent = error.message;
          status.classList.add('error');
        }
      };

      const deleteSection = async (section) => {
        const status = getStatus(section);
        if (status) {
          status.classList.remove('error');
          status.textContent = 'Deleting...';
        }

        try {
          const payload = new URLSearchParams({ action: 'delete', section });
          const response = await fetch('../api/payment-settings.php', {
            method: 'POST',
            body: payload,
            credentials: 'same-origin',
            cache: 'no-store'
          });
          const result = await readJsonResponse(response);
          if (!response.ok || !result.ok) {
            if (response.status === 401) {
              throw new Error('Your session has expired. Please sign in again.');
            }
            throw new Error(result.message || 'Could not delete payment details.');
          }

          paymentSettings[section] = result.settings[section] || {};
          const form = getForm(section);
          form?.querySelectorAll('input').forEach((input) => { input.value = ''; });
          syncSectionState(section, false, true);

          if (status) {
            status.textContent = section === 'bank' ? 'Current bank payment was deleted.' : 'Current crypto payment was deleted.';
          }
        } catch (error) {
          if (status) {
            status.textContent = error.message;
            status.classList.add('error');
          }
        }
      };

      document.querySelectorAll('.payment-form').forEach((form) => {
        form.addEventListener('submit', saveSection);
      });

      document.querySelectorAll('.payment-toggle-input').forEach((toggle) => {
        toggle.addEventListener('change', () => {
          const section = toggle.dataset.section;
          const hasDetails = hasAnyValues(paymentSettings[section]);

          if (hasDetails) {
            syncSectionState(section, true, false);
            return;
          }

          syncSectionState(section, false, toggle.checked);
          if (toggle.checked) {
            const form = getForm(section);
            if (form) form.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
          }
        });
      });

      document.querySelectorAll('.delete-current-payment').forEach((button) => {
        button.addEventListener('click', () => deleteSection(button.dataset.section));
      });

      document.querySelectorAll('.view-payment-details').forEach((button) => {
        button.addEventListener('click', () => openDetails(button.dataset.section));
      });

      document.querySelector('.dialog-close').addEventListener('click', closeDetails);
      document.getElementById('detail-modal-backdrop').addEventListener('click', (event) => {
        if (event.target.id === 'detail-modal-backdrop') closeDetails();
      });

      Object.entries(paymentSettings).forEach(([section, values]) => {
        syncSectionState(section, hasAnyValues(values), false);
      });
    </script>
</body>
</html>
