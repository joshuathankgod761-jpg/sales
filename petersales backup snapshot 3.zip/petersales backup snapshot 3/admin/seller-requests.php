<?php
$requiredArea = 'admin';
require_once __DIR__ . '/../auth.php';
$pageTitle = 'Seller requests | Peter Shop Admin';
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@500;600;700&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="admin.css?v=<?= filemtime(__DIR__ . '/admin.css') ?>">
  <style>
    .requests-content { padding-top:30px; }
    .requests-panel { margin:0; }
    .requests-toolbar { display:flex; align-items:center; justify-content:space-between; gap:14px; margin:20px 0 14px; }
    .requests-filters { display:flex; gap:9px; align-items:center; }
    .requests-search,.requests-status-filter { min-height:38px; padding:8px 11px; border:1px solid var(--line); border-radius:6px; background:var(--panel-light); color:var(--ink); }
    .requests-search { width:min(280px,45vw); }
    .requests-table-wrap { overflow-x:auto; }
    .requests-table { width:100%; min-width:780px; border-collapse:collapse; }
    .requests-table th,.requests-table td { padding:13px 12px; border-bottom:1px solid var(--line); text-align:left; vertical-align:top; }
    .requests-table th { color:var(--muted); font-size:9px; letter-spacing:1.1px; }
    .request-name { color:var(--ink); font-weight:700; }
    .request-email,.request-date { display:block; margin-top:4px; color:var(--muted); font-size:11px; }
    .request-message { max-width:350px; white-space:pre-wrap; overflow-wrap:anywhere; color:#d6dddd; font-size:12px; }
    .request-status { display:inline-flex; padding:5px 8px; border:1px solid var(--line); border-radius:5px; color:var(--muted); font-size:10px; font-weight:700; text-transform:uppercase; }
    .request-status.pending { border-color:rgba(255,183,77,.32); background:rgba(255,183,77,.08); color:#ffc47a; }
    .request-status.approved { border-color:rgba(216,255,62,.28); background:rgba(216,255,62,.08); color:var(--acid); }
    .request-status.rejected { border-color:rgba(255,108,72,.3); background:rgba(255,108,72,.08); color:#ff9b83; }
    .request-actions { display:flex; flex-wrap:wrap; gap:6px; }
    .request-action { padding:7px 9px; border:1px solid var(--line); border-radius:5px; background:transparent; color:var(--ink); font-size:10px; font-weight:700; cursor:pointer; }
    .request-action.approve { border-color:rgba(216,255,62,.3); color:var(--acid); }
    .request-action.reject { border-color:rgba(255,108,72,.3); color:#ff9b83; }
    .request-action:disabled { opacity:.5; cursor:wait; }
    .requests-empty { padding:34px 12px !important; color:var(--muted); text-align:center !important; }
    .review-note { margin:0 0 18px; color:var(--muted); font-size:12px; line-height:1.5; }
    .review-note a { color:var(--blue); font-weight:700; }
    .requests-summary { color:var(--muted); font-size:11px; }
    @media(max-width:650px) { .requests-toolbar { align-items:stretch; flex-direction:column; }.requests-filters { display:grid; grid-template-columns:1fr; }.requests-search { width:100%; } }
  </style>
</head>
<body>
  <div class="admin-shell">
    <?php include __DIR__ . '/nav.php'; ?>
    <main class="admin-main">
      <header class="admin-topbar"><button class="mobile-menu" type="button" aria-label="Open menu">☰</button><div><p class="eyebrow">TEAM ACCESS</p><h1>Seller requests</h1></div><div class="top-actions"><a class="outline-button" href="settings.php">+ Add seller</a></div></header>
      <section class="admin-content requests-content">
        <section class="panel requests-panel">
          <div class="panel-heading"><div><p class="eyebrow">INCOMING APPLICATIONS</p><h2>Review seller requests <span class="seller-count" id="request-count">0</span></h2><span class="panel-subtitle">Approve or reject requests and retain a review history.</span></div></div>
          <div class="requests-toolbar"><p class="review-note" id="review-feedback">Approval creates a seller login and emails a random temporary password using configured Gmail SMTP.</p><div class="requests-filters"><input class="requests-search" id="request-search" type="search" placeholder="Search name, email, or message" aria-label="Search seller requests"><select class="requests-status-filter" id="request-status-filter" aria-label="Filter by review status"><option value="all">All statuses</option><option value="pending">Pending</option><option value="approved">Approved</option><option value="rejected">Rejected</option></select></div></div>
          <div class="requests-table-wrap"><table class="requests-table"><thead><tr><th>APPLICANT</th><th>MESSAGE</th><th>SUBMITTED</th><th>STATUS</th><th>ACTION</th></tr></thead><tbody id="seller-request-rows"><tr><td colspan="5" class="requests-empty">Loading seller requests...</td></tr></tbody></table></div>
          <div class="table-footer"><span class="requests-summary" id="requests-summary">Loading requests</span></div>
        </section>
      </section>
    </main>
  </div>
  <script>
    const requestRows = document.getElementById('seller-request-rows');
    const requestCount = document.getElementById('request-count');
    const requestSearch = document.getElementById('request-search');
    const statusFilter = document.getElementById('request-status-filter');
    const reviewFeedback = document.getElementById('review-feedback');
    const escapeHtml = value => { const node = document.createElement('span'); node.textContent = String(value ?? ''); return node.innerHTML; };
    let requests = [];

    const renderRequests = () => {
      const term = requestSearch.value.trim().toLowerCase();
      const status = statusFilter.value;
      const visible = requests.map((request, index) => ({ ...request, _index: index })).filter(request =>
        (status === 'all' || (request.status || 'pending') === status) &&
        (!term || `${request.name} ${request.email} ${request.message}`.toLowerCase().includes(term))
      );
      const pendingCount = requests.filter(request => (request.status || 'pending') === 'pending').length;
      requestCount.textContent = pendingCount;
      const navBadge = document.getElementById('nav-seller-request-count');
      if (navBadge) navBadge.textContent = pendingCount;
      document.getElementById('requests-summary').textContent = `Showing ${visible.length} of ${requests.length} requests`;
      requestRows.innerHTML = visible.length ? visible.map(request => {
        const currentStatus = request.status || 'pending';
        const submitted = request.created_at ? new Date(request.created_at).toLocaleString() : 'Date unavailable';
        const reviewer = request.reviewed_by ? `<small class="request-date">Reviewed by ${escapeHtml(request.reviewed_by)}</small>` : '';
        const actions = currentStatus === 'pending'
          ? `<button class="request-action approve" data-index="${request._index}" data-status="approved" type="button">Approve &amp; email login</button><button class="request-action reject" data-index="${request._index}" data-status="rejected" type="button">Reject</button>`
          : currentStatus === 'rejected'
            ? `<button class="request-action" data-index="${request._index}" data-status="pending" type="button">Reopen</button>`
            : request.seller_id
              ? `<span class="request-date">Seller login created${request.email_status === 'sent' ? ' · credentials emailed' : ''}</span>`
              : `<button class="request-action approve" data-index="${request._index}" data-status="approved" type="button">Create login &amp; email</button>`;
        return `<tr><td><span class="request-name">${escapeHtml(request.name || 'Unnamed applicant')}</span><span class="request-email">${escapeHtml(request.email || '')}</span></td><td><div class="request-message">${escapeHtml(request.message || 'No message provided.')}</div></td><td>${escapeHtml(submitted)}</td><td><span class="request-status ${escapeHtml(currentStatus)}">${escapeHtml(currentStatus)}</span>${reviewer}</td><td><div class="request-actions">${actions}</div></td></tr>`;
      }).join('') : '<tr><td colspan="5" class="requests-empty">No seller requests match this filter.</td></tr>';
    };

    const loadRequests = async () => {
      try {
        const response = await fetch('../api/seller-requests.php', { cache: 'no-store', credentials: 'same-origin' });
        const result = await response.json();
        if (!response.ok || !result.ok) throw new Error(result.message || 'Could not load seller requests.');
        requests = Array.isArray(result.requests) ? result.requests : [];
        renderRequests();
      } catch (error) {
        requestRows.innerHTML = `<tr><td colspan="5" class="requests-empty">${escapeHtml(error.message || 'Could not load seller requests.')}</td></tr>`;
      }
    };

    requestRows.addEventListener('click', async event => {
      const button = event.target.closest('[data-index][data-status]');
      if (!button) return;
      const nextStatus = button.dataset.status;
      if (nextStatus !== 'pending' && !window.confirm(`${nextStatus === 'approved' ? 'Approve' : 'Reject'} this seller request?`)) return;
      button.disabled = true;
      try {
        const response = await fetch('../api/seller-requests.php', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({ index: button.dataset.index, status: nextStatus })
        });
        const result = await response.json();
        if (!response.ok || !result.ok) throw new Error(result.message || 'Could not update request.');
        requests[Number(result.index)] = result.request;
        reviewFeedback.textContent = result.message || 'Seller request updated.';
        renderRequests();
      } catch (error) {
        reviewFeedback.textContent = error.message || 'Could not update request.';
        window.alert(error.message || 'Could not update request.');
        button.disabled = false;
      }
    });

    requestSearch.addEventListener('input', renderRequests);
    statusFilter.addEventListener('change', renderRequests);
    loadRequests();
  </script>
</body>
</html>