<?php
$pageTitle = 'Peter Shop | Account details';
?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Peter Shop verified Free Fire account details.">
  <title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@500;600;700&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles.css?v=<?= filemtime(__DIR__ . '/styles.css') ?>">
  <script crossorigin src="https://unpkg.com/react@18/umd/react.development.js"></script>
  <script crossorigin src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
  <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
</head>
<body class="product-document">
  <div class="site-shell">
    <?php include __DIR__ . '/header.php'; ?>
    <div id="root"><main class="offline-product-fallback"><p class="eyebrow">PETER SHOP</p><h1>Free Fire account details</h1><p>This page is available offline, but the live account data and gallery images need an internet connection to load.</p><a href="index.php">Back to accounts</a></main></div>
    <?php include __DIR__ . '/footer.php'; ?>
  </div>
  <script type="text/babel" data-presets="react" src="app.jsx?v=<?= filemtime(__DIR__ . '/app.jsx') ?>"></script>
</body>
</html>
