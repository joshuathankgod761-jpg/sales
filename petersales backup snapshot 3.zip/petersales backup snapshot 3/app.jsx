const { useEffect, useMemo, useState } = React;
const API_URL = 'api/accounts.php';
const DEFAULT_NGN_RATE = 1500;
const getNgnRate = () => Number(window.peterShopExchangeRate) || DEFAULT_NGN_RATE;
const formatCurrency = (amount, currency) => currency === 'NGN' ? `₦${(Number(amount) * getNgnRate()).toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : `$${Number(amount).toFixed(2)}`;
const getVisitorId = () => {
  let visitorId = localStorage.getItem('peter-shop-visitor-id');
  if (!visitorId) {
    visitorId = window.crypto?.randomUUID?.() || `${Date.now().toString(16)}-${Math.random().toString(16).slice(2)}`;
    localStorage.setItem('peter-shop-visitor-id', visitorId);
  }
  return visitorId;
};
const isSellerLiked = sellerKey => {
  try { return JSON.parse(localStorage.getItem('peter-shop-liked-sellers') || '[]').includes(String(sellerKey || '')); }
  catch (error) { return false; }
};
function LikeIcon() {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z" /></svg>;
}

function Brand() {
  return <a className="brand" href="#top" aria-label="Peter Shop home"><span className="brand-mark">P</span><span>PETER <span>SHOP</span></span></a>;
}

function Header({ favorites, onFavorites }) {
  return <header className="topbar"><Brand /><div className="header-actions"><button className="icon-button" onClick={onFavorites} aria-label="View favorites">♡<span className="action-count">{favorites.size}</span></button><button className="menu-button" aria-label="Open navigation">☰</button></div></header>;
}

function Hero() {
  return <section className="catalog-hero"><h1>Free Fire Accounts</h1><p>Buy verified Free Fire accounts with rare bundles, stacked inventories, and instant delivery.</p><div className="hero-benefits"><span>◷ Instant delivery</span><span>▣ SSL secure</span><span>♡ Buyer protection</span><span>◌ 24/7 support</span><span>↻ Easy transfer</span></div></section>;
}

function TrustStrip() {
  const benefits = [['✦', 'Verified accounts', 'Checked before every drop'], ['↯', 'Instant delivery', 'Credentials in your inbox'], ['◎', 'Buyer protection', '7-day account guarantee'], ['◌', 'Always online', 'Real people, real support']];
  return <section className="trust-strip" aria-label="Store benefits">{benefits.map(([icon, title, text]) => <div key={title}><span className="strip-icon">{icon}</span><div><strong>{title}</strong><small>{text}</small></div></div>)}</section>;
}

function AccountCard({ account, isFavorite, onFavorite, onLike, onDetails, onBuy, currency }) {
  const imageCount = account.images?.length || 1;
  const weaponCategory = account.category ? account.category.charAt(0).toUpperCase() + account.category.slice(1) : 'All';
  const detailItems = [
    ['▦ Prime', account.gameVersion],
    ['◉ Server', account.server],
    ['♧ Outfits', account.outfits || 'Not specified'],
    ['♧ Emotes', account.emotes || 'Not specified'],
    ['✦ Arrival animation', account.arrivalAnimation || 'Not specified'],
    ['◌ Look changer', account.lookChanger || 'Not specified'],
    ['♧ Characters', account.characters],
    ['◍ Weapon category', weaponCategory],
    ['⚙ Weapon type tag', account.tag || 'All 367 weapons'],
    ['✦ EVO guns', account.evoGuns ?? 1],
    ['✦ Max EVO guns', account.maxEvoGuns || 'Not specified'],
    ['◌ Inventory summary', account.meta || 'No inventory summary'],
    ['◍ Booyah Pass', account.booyahPass ?? 'No'],
    ['◌ Elite Pass', account.elitePass ?? 'No']
  ];

  const sold = account.status === 'sold';
  return <article className={`account-card ${sold ? 'listing-sold' : ''}`}><div className="card-heading"><h3 className="card-title">{account.tier} · Level {account.level}</h3><button className={`card-favorite ${isFavorite ? 'saved' : ''}`} onClick={() => onFavorite(account.id)} aria-label={`${isFavorite ? 'Remove from' : 'Add to'} favorites`}>{isFavorite ? '♥' : '♡'}</button></div><div className="card-media" onClick={() => onDetails(account)} role="button" tabIndex="0" onKeyDown={event => event.key === 'Enter' && onDetails(account)}><img src={account.image} alt={`${account.title} account showcase`} loading="lazy" />{sold && <span className="sold-overlay">SOLD</span>}<span className="card-badge">⚡</span><span className="image-count" aria-label={`${imageCount} images`}><span>▧</span>{imageCount}</span></div><button className="card-description" onClick={() => onDetails(account)}>{account.description}</button><div className="listing-chips">{detailItems.map(([label, value]) => <span key={`${account.id}-${label}`}>{label}&nbsp;|&nbsp;{value}</span>)}</div><div className="seller-row"><span className="seller-avatar">{String(account.seller || 'V').slice(0, 1).toUpperCase()}</span><strong>{account.seller}</strong><b>★</b><span>{account.rating || '4.9'} {Number(account.reviews || 0).toLocaleString()} reviews</span></div><div className="card-cta"><button className={`product-like-button ${isSellerLiked(account.sellerKey) ? 'is-liked' : ''}`} type="button" data-account-id={account.id} data-seller-key={account.sellerKey || ''} onClick={event => window.peterShopLike?.(account.id, event.currentTarget)} aria-label={`Like ${account.seller || 'seller'}`}><LikeIcon /><span>Like</span><span className="like-count">{Number(account.likes || 0).toLocaleString()}</span></button><strong className="card-price">{formatCurrency(account.price, window.peterShopCurrency || 'USD')}</strong><button className="buy-button" disabled={sold} onClick={() => !sold && onBuy(account)}>{sold ? 'Sold' : 'Buy now'}</button></div></article>;
}

function Catalog({ accounts, favorites, onFavorite, onDetails, onBuy, currency }) {
  const [filter, setFilter] = useState('all');
  const [priceOpen, setPriceOpen] = useState(false);
  const [gameVersionOpen, setGameVersionOpen] = useState(false);
  const [gameVersion, setGameVersion] = useState('all');
  const [serverOpen, setServerOpen] = useState(false);
  const [server, setServer] = useState('all');
  const [serverSearch, setServerSearch] = useState('');
  const [tierOpen, setTierOpen] = useState(false);
  const [tier, setTier] = useState('all');
  const [tierSearch, setTierSearch] = useState('');
  const [moreOpen, setMoreOpen] = useState(false);
  const [sortOpen, setSortOpen] = useState(false);
  const [priceRange, setPriceRange] = useState({ min: 0, max: 9999 });
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState('featured');

  useEffect(() => {
    const toolbar = document.querySelector('.catalog-toolbar');
    if (!toolbar) return;
    let wrapper = toolbar.querySelector('.sort-wrap');
    if (!wrapper) {
      wrapper = document.createElement('div');
      wrapper.className = 'sort-wrap';
      wrapper.innerHTML = '<button class="sort-button" type="button"><span></span><span class="filter-chevron">⌄</span></button><div class="sort-panel"></div>';
      toolbar.appendChild(wrapper);
      const button = wrapper.querySelector('.sort-button');
      const panel = wrapper.querySelector('.sort-panel');
      button.addEventListener('click', () => {
        panel.classList.toggle('visible');
        button.classList.toggle('active');
      });
      sortOptions.forEach(([value, option]) => {
        const item = document.createElement('button');
        item.type = 'button';
        item.textContent = option;
        item.addEventListener('click', () => {
          setSort(value);
          panel.classList.remove('visible');
          button.classList.remove('active');
        });
        panel.appendChild(item);
      });
    }
    wrapper.querySelector('.sort-button span').textContent = selectedSort;
    wrapper.querySelectorAll('.sort-panel button').forEach((item, index) => item.classList.toggle('selected', sortOptions[index][0] === sort));
  }, [sort]);

  useEffect(() => {
    const panel = document.querySelector('.game-version-panel');
    if (!panel) return;
    const options = Array.from({ length: 8 }, (_, index) => `Prime ${index + 1}`);
    panel.replaceChildren(...options.map(option => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = gameVersion === option ? 'selected' : '';
      button.innerHTML = `<span>${option}</span><i></i>`;
      button.addEventListener('click', () => {
        setGameVersion(option);
        setGameVersionOpen(false);
      });
      return button;
    }));
  }, [gameVersion, gameVersionOpen]);

  const handleFilterClick = (key) => {
    if (key === 'all') {
      setPriceOpen(current => !current);
      setGameVersionOpen(false);
      return;
    }

    if (key === 'mythic') {
      setGameVersionOpen(current => !current);
      setPriceOpen(false);
      setServerOpen(false);
      setTierOpen(false);
      setTierOpen(false);
      return;
    }

    if (key === 'diamond') {
      setServerOpen(current => !current);
      setPriceOpen(false);
      setGameVersionOpen(false);
      setTierOpen(false);
      return;
    }

    if (key === 'starter') {
      setTierOpen(current => !current);
      setPriceOpen(false);
      setGameVersionOpen(false);
      setServerOpen(false);
      setMoreOpen(false);
      return;
    }

    if (key === 'more') {
      setMoreOpen(current => !current);
      setPriceOpen(false);
      setGameVersionOpen(false);
      setServerOpen(false);
      setTierOpen(false);
      return;
    }

    setFilter(key);
    setPriceOpen(false);
    setGameVersionOpen(false);
    setServerOpen(false);
    setTierOpen(false);
    setMoreOpen(false);
  };

  const results = useMemo(() => accounts.filter(account => {
    const matchesFilter = filter === 'all' || account.category === filter || (filter === 'starter' && account.price < 30);
    const matchesGameVersion = gameVersion === 'all' || account.gameVersion === gameVersion;
    const matchesServer = server === 'all' || account.server === server;
    const matchesTier = tier === 'all' || account.tier === tier;
    const matchesPrice = account.price >= priceRange.min && account.price <= priceRange.max;
    const term = search.toLowerCase().trim();
    const matchesSearch = !term || `${account.title} ${account.tier} ${account.level} ${account.meta}`.toLowerCase().includes(term);
    return matchesFilter && matchesGameVersion && matchesServer && matchesTier && matchesPrice && matchesSearch;
  }).sort((a, b) => sort === 'low' ? a.price - b.price : sort === 'high' ? b.price - a.price : sort === 'oldest' ? a.id - b.id : sort === 'newest' ? b.id - a.id : Number(b.featured) - Number(a.featured)), [accounts, filter, gameVersion, server, tier, priceRange, search, sort]);
  const filters = [
    { key: 'all', label: 'Price', icon: '$' },
    { key: 'mythic', label: 'Prime', icon: '◌' },
    { key: 'diamond', label: 'Server', icon: '◍' },
    { key: 'starter', label: 'Tier', icon: '✦' },
    { key: 'more', label: 'More', icon: '⋯' }
  ];
  const servers = ['India', 'Brazil', 'Indonesia', 'Thailand', 'LATAM', 'Vietnam', 'Malaysia', 'Russia', 'Pakistan', 'Middle East', 'Bangladesh', 'Europe'];
  const visibleServers = servers.filter(option => option.toLowerCase().includes(serverSearch.toLowerCase().trim()));
  const tiers = ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Heroic', 'Master', 'Grand Master'];
  const visibleTiers = tiers.filter(option => option.toLowerCase().includes(tierSearch.toLowerCase().trim()));
  const primeOptions = Array.from({ length: 8 }, (_, index) => `Prime ${index + 1}`);


  const moreOptions = ['Account Level', 'Characters', 'Evo Guns', 'Armory', 'Booyah Pass', 'Elite Pass'];
  useEffect(() => {
    const grid = document.querySelector('.account-grid');
    const pagination = document.querySelector('.pagination');
    if (!grid || !pagination) return undefined;
    const cards = [...grid.querySelectorAll('.account-card')];
    const pageSize = 24;
    const pageCount = Math.max(1, Math.ceil(cards.length / pageSize));
    let currentPage = 1;
    const renderPagination = (animate = false) => {
      const updateCards = () => cards.forEach((card, index) => {
        card.style.display = index >= (currentPage - 1) * pageSize && index < currentPage * pageSize ? '' : 'none';
      });
      if (animate) {
        grid.classList.remove('page-enter');
        grid.classList.add('page-exit');
        window.setTimeout(() => {
          updateCards();
          grid.classList.remove('page-exit');
          grid.classList.add('page-enter');
          window.setTimeout(() => grid.classList.remove('page-enter'), 360);
        }, 180);
      } else {
        updateCards();
      }
      pagination.innerHTML = `<button type="button" data-page="previous"><span class="page-arrow">‹</span><span>Previous</span></button>${Array.from({ length: pageCount }, (_, index) => `<button type="button" data-page="${index + 1}">${index + 1}</button>`).join('')}<button class="next" type="button" data-page="next"><span>Next</span><span class="page-arrow">›</span></button>`;
      pagination.querySelectorAll('button').forEach(button => {
        const target = button.dataset.page;
        button.classList.toggle('selected', Number(target) === currentPage);
        button.disabled = target === 'previous' ? currentPage === 1 : target === 'next' && currentPage === pageCount;
        button.addEventListener('click', () => {
          if (target === 'previous') currentPage -= 1;
          else if (target === 'next') currentPage += 1;
          else currentPage = Number(target);
          renderPagination(true);
        });
      });
    };
    renderPagination();
    return () => cards.forEach(card => { card.style.display = ''; });
  }, [results]);
  const sortOptions = [['featured', 'Recommended'], ['newest', 'Newest first'], ['oldest', 'Oldest first'], ['low', 'Price: Low to High'], ['high', 'Price: High to Low']];
  const selectedSort = sortOptions.find(([value]) => value === sort)?.[1] || 'Recommended';

  return <section className="catalog-section" id="accounts"><div className="section-heading"><div><p className="eyebrow">FREE FIRE ACCOUNTS</p><h2>{results.length * 35 + 3} offers available</h2></div><p className="section-note">Verified inventory<br />Updated today</p></div><div className="catalog-toolbar"><div className="filter-group">{filters.map(({ key, label, icon }) => <div key={key} className={`filter-wrap ${key === 'all' && priceOpen || key === 'mythic' && gameVersionOpen || key === 'diamond' && serverOpen || key === 'starter' && tierOpen || key === 'more' && moreOpen ? 'is-open' : ''}`}><button className={`filter-button ${(filter === key || key === 'mythic' && gameVersion !== 'all' || key === 'diamond' && server !== 'all' || key === 'starter' && tier !== 'all') ? 'active' : ''}`} onClick={() => handleFilterClick(key)}><span className="filter-icon">{icon}</span><span>{key === 'diamond' && server !== 'all' ? server : key === 'starter' && tier !== 'all' ? tier : label}</span><span className="filter-chevron">⌄</span></button>{key === 'all' && priceOpen && <div className="price-panel"><div className="price-values"><span>{priceRange.min}</span><span>{priceRange.max}</span></div><div className="range-track"><input type="range" min="0" max="9999" value={priceRange.min} onChange={event => setPriceRange(current => ({ ...current, min: Math.min(Number(event.target.value), current.max - 1) }))} /><input type="range" min="0" max="9999" value={priceRange.max} onChange={event => setPriceRange(current => ({ ...current, max: Math.max(Number(event.target.value), current.min + 1) }))} /></div><div className="range-labels"><span>0</span><span>{priceRange.max}</span></div></div>}{key === 'mythic' && gameVersionOpen && <div className="game-version-panel"><button className={gameVersion === 'Free Fire' ? 'selected' : ''} onClick={() => { setGameVersion('Free Fire'); setGameVersionOpen(false); }}><span>Free Fire</span><i></i></button><button className={gameVersion === 'Free Fire Max' ? 'selected' : ''} onClick={() => { setGameVersion('Free Fire Max'); setGameVersionOpen(false); }}><span>Free Fire Max</span><i></i></button></div>}{key === 'diamond' && serverOpen && <div className="server-panel"><label className="server-search"><span>⌕</span><input value={serverSearch} onChange={event => setServerSearch(event.target.value)} placeholder="Search" /></label><div className="server-options">{visibleServers.map(option => <button key={option} className={server === option ? 'selected' : ''} onClick={() => { setServer(option); setServerOpen(false); }}><span>{option}</span><i></i></button>)}</div></div>}{key === 'starter' && tierOpen && <div className="tier-panel"><label className="tier-search"><span>⌕</span><input value={tierSearch} onChange={event => setTierSearch(event.target.value)} placeholder="Search" /></label><div className="tier-options">{visibleTiers.map(option => <button key={option} className={tier === option ? 'selected' : ''} onClick={() => { setTier(option); setTierOpen(false); }}><span>{option}</span><i></i></button>)}</div></div>}{key === 'more' && moreOpen && <div className="more-panel">{moreOptions.map(option => <button key={option}><span>{option}</span><b>›</b></button>)}</div>}</div>)}</div></div><div className="account-grid">{results.map(account => <AccountCard key={account.id} account={account} isFavorite={favorites.has(account.id)} onFavorite={onFavorite} onDetails={onDetails} onBuy={onBuy} />)}</div>{!results.length && <div className="empty-state">No accounts match that search. Try a different drop.</div>}<div className="pagination"><button>‹ <span>Previous</span></button><strong>1</strong><button>2</button><button>3</button><button>4</button><button>5</button><i>...</i><button>9</button><button className="next">Next ›</button></div></section>;
}

function InformationSection() {
  return <section className="information-section"><h2>Free Fire Accounts for Sale</h2><p>Want to jump straight into the action? Peter Shop has verified Free Fire accounts for sale, giving you a faster way to access rare bundles, powerful weapons, and hard-earned progress.</p><p>Every listing is checked before it goes live. Browse detailed inventories, compare account levels, and choose the loadout that fits your style.</p><h3>Why Players Buy Free Fire Accounts</h3><p>Building a competitive account from scratch can take hundreds of hours. A ready-made account gives you more time to enjoy the game and less time repeating the same unlocks.</p><ul><li>Jump into matches with rare weapons and exclusive bundles.</li><li>Skip long progression grinds and start playing at a higher level.</li><li>Compare account inventories before you buy.</li><li>Find accounts with mythic costumes, emotes, characters, and vehicles.</li></ul><h3>What Makes a Good Free Fire Account?</h3><p>A strong account is more than a high level. Look for a balanced inventory, useful EVO guns, rare cosmetics, and a seller with clear listing details.</p><ul><li>High level and useful rank history.</li><li>Rare weapons, mythic outfits, and valuable collections.</li><li>Multiple characters, emotes, backpacks, and vehicles.</li><li>Clear screenshots and accurate inventory descriptions.</li></ul><h3>How It Works</h3><ol><li>Browse the available accounts and compare their details.</li><li>Choose the listing that matches your budget and play style.</li><li>Review the inventory and click <strong>Buy now</strong>.</li><li>Receive your account delivery instructions after checkout.</li></ol><h3>FAQ</h3><h4>Why do players buy Free Fire accounts?</h4><p>Many players choose an account with rare items, a higher level, or a stronger collection so they can start playing immediately.</p><h4>Is it safe to buy a Free Fire account?</h4><p>Only buy from listings with clear details, verified sellers, and buyer protection. Peter Shop is designed to make those details easy to review before checkout.</p><h4>Can I find cheap Free Fire accounts?</h4><p>Yes. Use the price and account filters above to find starter accounts and budget-friendly inventories.</p></section>;
}

function CartDrawer({ cart, onRemove, onClose, onCheckout }) { const total = cart.reduce((sum, item) => sum + item.price, 0); return <><div className="cart-drawer open"><div className="drawer-head"><div><p className="eyebrow">YOUR DROP</p><h2>Cart <span>{cart.length}</span></h2></div><button className="close-button" onClick={onClose} aria-label="Close cart">×</button></div><div className="cart-items">{cart.length ? cart.map(item => <div className="cart-item" key={item.id}><img src={item.image} alt="" /><div className="cart-item-info"><strong>{item.title}</strong><span>{formatCurrency(item.price, window.peterShopCurrency || 'USD')}</span></div><button className="remove-item" onClick={() => onRemove(item.id)} aria-label={`Remove ${item.title}`}>×</button></div>) : <p className="cart-empty">Your cart is waiting.<br />Find an account worth keeping.</p>}</div><div className="cart-footer"><div><span>Total</span><strong>{formatCurrency(total, window.peterShopCurrency || 'USD')}</strong></div><button className="primary-button checkout-button" onClick={onCheckout}>Secure checkout <span>→</span></button></div></div><div className="overlay active" onClick={onClose} /> </>; }

function FavoritesDrawer({ favorites, accounts, onRemove, onClose, onDetails, onBuy }) {
  const savedAccounts = accounts.filter(account => favorites.has(account.id));
  return <><aside className="favorites-drawer open" aria-label="Favorite accounts"><div className="drawer-head"><div><p className="eyebrow">YOUR PICKS</p><h2>Favorites <span>{savedAccounts.length}</span></h2></div><button className="close-button" onClick={onClose} aria-label="Close favorites">×</button></div><div className="favorite-items">{savedAccounts.length ? savedAccounts.map(account => <article className="favorite-item" key={account.id}><button className="favorite-image" onClick={() => onDetails(account)} aria-label={`View ${account.title}`}><img src={account.image} alt="" /></button><div className="favorite-item-info"><button className="favorite-title" onClick={() => onDetails(account)}>{account.title}</button><span>{account.tier} · Level {account.level}</span><strong>{formatCurrency(account.price, window.peterShopCurrency || 'USD')}</strong></div><button className="remove-item" onClick={() => onRemove(account.id)} aria-label={`Remove ${account.title} from favorites`}>×</button><button className="favorite-buy" onClick={() => onBuy(account)}>Buy</button></article>) : <p className="cart-empty">No favorites yet.<br />Tap the heart on an account to save it here.</p>}</div></aside><div className="overlay active" onClick={onClose} /> </>;
}

function DetailsDialog({ account, onClose }) {
  const [imageIndex, setImageIndex] = useState(0);
  const images = account?.images?.length ? account.images : account ? [account.image] : [];

  useEffect(() => {
    setImageIndex(0);
  }, [account]);

  useEffect(() => {
    if (!account) return undefined;
    const handleKeyDown = event => {
      if (event.key === 'Escape') onClose();
      if (event.key === 'ArrowLeft') setImageIndex(current => (current - 1 + images.length) % images.length);
      if (event.key === 'ArrowRight') setImageIndex(current => (current + 1) % images.length);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [account, images.length, onClose]);

  if (!account) return null;
  const moveImage = direction => setImageIndex(current => (current + direction + images.length) % images.length);

  return <dialog open className="gallery-dialog"><button className="gallery-close" onClick={onClose} aria-label="Close image viewer">×</button><span className="gallery-counter">{imageIndex + 1} / {images.length}</span><button className="gallery-arrow gallery-prev" onClick={() => moveImage(-1)} aria-label="Previous image">‹</button><img src={images[imageIndex]} alt={`${account.title} image ${imageIndex + 1}`} /><button className="gallery-arrow gallery-next" onClick={() => moveImage(1)} aria-label="Next image">›</button></dialog>;
}

function PaymentModal({ account, email, onEmailChange, onClose, onPay, exchangeRate }) {
  const [method, setMethod] = useState('Bank Transfer');
  const [availableMethods, setAvailableMethods] = useState(null);
  useEffect(() => {
    let mounted = true;
    fetch(`api/payment-settings.php?product_id=${encodeURIComponent(account.id)}`, { cache: 'no-store' }).then(response => response.json()).then(result => {
      if (!mounted) return;
      const bank = result.settings?.bank || {};
      const crypto = result.settings?.crypto || {};
      const bankReady = Object.values(bank).length > 0 && Object.values(bank).every(Boolean);
      const cryptoReady = Object.values(crypto).length > 0 && Object.values(crypto).every(Boolean);
      setAvailableMethods({ bank: bankReady, crypto: cryptoReady });
      if (!bankReady && cryptoReady) setMethod('BTC, ETH, USDT, USDC and more');
    }).catch(() => mounted && setAvailableMethods({ bank: false, crypto: false }));
    return () => { mounted = false; };
  }, [account]);
  const methods = availableMethods ? [['Bank Transfer', 'BANK', 'No fee', availableMethods.bank], ['BTC, ETH, USDT, USDC and more', '◉ CRYPTO', '+ 5.9%', availableMethods.crypto]].filter(methodOption => methodOption[3]) : [];
  if (!availableMethods) return <div className="payment-backdrop"><section className="payment-modal" role="dialog" aria-modal="true"><button className="payment-close" onClick={onClose} aria-label="Close payment modal">×</button><h2 id="payment-title">Loading payment methods</h2></section></div>;
  if (availableMethods && methods.length === 0) return <div className="payment-backdrop"><section className="payment-modal" role="dialog" aria-modal="true"><button className="payment-close" onClick={onClose} aria-label="Close payment modal">×</button><h2 id="payment-title">Payment unavailable</h2><p>No payment account has been configured for this listing yet.</p></section></div>;
  const offer = Number(account.price);
  const vat = offer * 0.2;
  const commission = offer * 0.055;
  const hasVat = method !== 'Bank Transfer';
  const displayCurrency = method === 'Bank Transfer' ? 'NGN' : 'USD';
  const total = offer + (hasVat ? vat : 0) + commission;
  return <div className="payment-backdrop"><section className="payment-modal" role="dialog" aria-modal="true" aria-labelledby="payment-title"><button className="payment-close" onClick={onClose} aria-label="Close payment modal">×</button><h2 id="payment-title">Payment method</h2><label className="payment-email-field">Email for receipt<input type="email" value={email} onChange={event => onEmailChange(event.target.value)} required placeholder="you@example.com" /></label><div className="payment-layout"><div className="payment-methods">{methods.map(([name, logo, fee]) => <button key={name} className={`payment-method ${method === name ? 'selected' : ''}`} onClick={() => setMethod(name)}><span className="payment-logo">{logo}</span><strong>{name}</strong><b>{fee}</b></button>)}</div><div className="payment-summary"><div><span>Offer's price</span><strong>{formatCurrency(offer, displayCurrency)}</strong></div>{hasVat && <div><span>VAT</span><strong>{formatCurrency(vat, displayCurrency)}</strong></div>}<div><span>Payment commission</span><strong>{formatCurrency(commission, displayCurrency)}</strong></div><div className="payment-total"><span>Total price</span><strong>{formatCurrency(total, displayCurrency)}</strong></div><button className="payment-buy" disabled={!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)} onClick={() => onPay(total, displayCurrency, method)}>Buy now <span>♢</span></button><div className="secure-note">◈ SECURE<br /><small>SSL ENCRYPTION</small><p>We protect your privacy with advanced encryption</p></div></div></div></section></div>;
}

function ProcessingOverlay() {
  return <div className="processing-backdrop"><div className="processing-card"><div className="processing-orbit"><i></i><b></b></div><h2>We're processing your order</h2><p>It usually takes a few seconds</p></div></div>;
}

function ProductPage({ account, accounts, favorites, onFavorite, onBack, onBuy, onRelated, currency, exchangeRate }) {
  const images = account.images?.length ? account.images : [account.image];
  const [imageIndex, setImageIndex] = useState(0);
  useEffect(() => {
    const image = document.querySelector('.product-image-frame img');
    const arrows = document.querySelectorAll('.product-gallery-arrow');
    arrows.forEach(arrow => { arrow.disabled = images.length < 2; });
    if (!image) return undefined;
    image.hidden = false;
    image.parentElement?.classList.remove('image-unavailable');
    image.parentElement?.querySelector('.image-unavailable-label')?.remove();
    const showUnavailable = () => {
      image.hidden = true;
      const frame = image.parentElement;
      if (!frame || frame.querySelector('.image-unavailable-label')) return;
      frame.classList.add('image-unavailable');
      const label = document.createElement('span');
      label.className = 'image-unavailable-label';
      label.textContent = 'Photo unavailable';
      label.style.cssText = 'position:absolute;inset:0;display:grid;place-items:center;color:#b9c1c8;font-size:14px;font-weight:600;';
      frame.appendChild(label);
    };
    image.addEventListener('error', showUnavailable, { once: true });
    if (image.complete && image.naturalWidth === 0) showUnavailable();
    return () => image.removeEventListener('error', showUnavailable);
  }, [account, imageIndex, images.length]);
  useEffect(() => {
    const main = document.querySelector('.product-main');
    const layout = main?.querySelector('.product-layout');
    if (!main || !layout || main.querySelector('.product-intro')) return;
    main.querySelector(':scope > .product-breadcrumb')?.remove();
    const intro = document.createElement('section');
    intro.className = 'product-intro';
    intro.innerHTML = `<div class="product-intro-top"><button class="product-back" type="button">‹ <span>Accounts</span></button><button class="product-favorite" type="button">Add to Favorites <span>♡</span></button></div><h1>${account.tier} · Level: ${account.level}</h1><p class="product-highlights">${account.description} · Verified inventory · Premium setup · High-level account · Instant delivery</p>`;
    intro.querySelector('.product-back').addEventListener('click', onBack);
    main.insertBefore(intro, layout);
  }, [account, onBack]);
  useEffect(() => {
    const favoriteButton = document.querySelector('.product-favorite');
    if (!favoriteButton) return undefined;
    const updateFavoriteButton = () => {
      const saved = favorites.has(account.id);
      favoriteButton.classList.toggle('saved', saved);
      favoriteButton.innerHTML = `${saved ? 'Saved to Favorites' : 'Add to Favorites'} <span>${saved ? '♥' : '♡'}</span>`;
      favoriteButton.setAttribute('aria-pressed', String(saved));
    };
    const toggleProductFavorite = () => onFavorite(account.id);
    favoriteButton.addEventListener('click', toggleProductFavorite);
    updateFavoriteButton();
    return () => favoriteButton.removeEventListener('click', toggleProductFavorite);
  }, [account, favorites, onFavorite]);
  useEffect(() => {
    const gallery = document.querySelector('.product-gallery');
    const summary = document.querySelector('.product-summary');
    if (gallery && summary && summary.parentElement !== gallery) gallery.appendChild(summary);
  }, [account]);
  useEffect(() => {
    const checkoutRow = document.querySelector('.checkout-total, [classname="checkout-total"]');
    if (checkoutRow) checkoutRow.className = 'checkout-total';
    const checkoutTotal = checkoutRow?.querySelector('strong');
    if (checkoutTotal) checkoutTotal.textContent = formatCurrency(account.price, window.peterShopCurrency || currency || 'USD');
    document.querySelectorAll('.recommended-footer strong').forEach((price, index) => {
      const item = accounts.filter(entry => entry.id !== account.id).slice(0, 3)[index];
      if (item) price.textContent = formatCurrency(item.price, window.peterShopCurrency || currency || 'USD');
    });
  }, [account, accounts, currency, exchangeRate]);
  useEffect(() => {
    const refreshProductPrices = () => {
      const selectedCurrency = window.peterShopCurrency || 'USD';
      const checkoutRow = document.querySelector('.checkout-total, [classname="checkout-total"]');
      if (checkoutRow) checkoutRow.className = 'checkout-total';
      const checkoutTotal = checkoutRow?.querySelector('strong');
      if (checkoutTotal) checkoutTotal.textContent = formatCurrency(account.price, selectedCurrency);
      document.querySelectorAll('.recommended-footer strong').forEach((price, index) => {
        const item = accounts.filter(entry => entry.id !== account.id).slice(0, 3)[index];
        if (item) price.textContent = formatCurrency(item.price, selectedCurrency);
      });
    };
    window.addEventListener('peter-shop-currency-change', refreshProductPrices);
    return () => window.removeEventListener('peter-shop-currency-change', refreshProductPrices);
  }, [account, accounts]);

  useEffect(() => {
    const button = document.querySelector('.product-buy-panel button');
    if (!button) return undefined;
    const handleTopBuy = event => {
      event.preventDefault();
      event.stopImmediatePropagation();
      const emailInput = document.querySelector('.checkout-email');
      if (emailInput?.value && emailInput.checkValidity()) {
        onBuy(account, emailInput.value.trim());
      } else {
        emailInput?.focus();
        emailInput?.classList.add('input-error');
      }
    };
    button.addEventListener('click', handleTopBuy, true);
    return () => button.removeEventListener('click', handleTopBuy, true);
  }, [account, onBuy]);

  useEffect(() => {
    const sellerCard = document.querySelector('.product-seller-card');
    const checkoutButton = document.querySelector('.fast-checkout .checkout-buy');
    const sold = account.status === 'sold';
    const likeCount = sellerCard?.querySelector('.product-like-button .like-count');
    if (likeCount) likeCount.textContent = Number(account.likes || 0).toLocaleString();
    const sellerRating = sellerCard?.querySelector('span');
    if (sellerRating) sellerRating.textContent = `★ ${account.rating || '5.0'}`;
    if (sellerCard) {
      let soldLabel = sellerCard.querySelector('.product-sold-label');
      if (sold && !soldLabel) {
        soldLabel = document.createElement('strong');
        soldLabel.className = 'product-sold-label';
        soldLabel.textContent = 'SOLD';
        sellerCard.appendChild(soldLabel);
      } else if (!sold && soldLabel) {
        soldLabel.remove();
      }
    }
    if (checkoutButton) {
      checkoutButton.disabled = sold;
      checkoutButton.textContent = sold ? 'Sold' : 'Buy now ♢';
    }
  }, [account]);

  useEffect(() => {
    const summary = document.querySelector('.product-summary');
    const featureGrid = summary?.querySelector('.product-feature-grid');
    if (!summary || !featureGrid || summary.querySelector('.product-seller-card')) return;
    const weaponCategory = account.category ? account.category.charAt(0).toUpperCase() + account.category.slice(1) : 'All';
    featureGrid.innerHTML = `<span><b>Prime:</b> ${account.gameVersion || 'Prime 1'}</span><span><b>Server:</b> ${account.server || 'Bangladesh'}</span><span><b>Tier:</b> ${account.tier || 'Grand Master'}</span><span><b>Account level:</b> ${account.level || '78'}</span><span><b>Weapon category:</b> ${weaponCategory}</span><span><b>Weapon type tag:</b> ${account.tag || 'All 367 weapons'}</span><span><b>EVO guns:</b> ${account.evoGuns ?? 1}</span><span><b>Max EVO guns:</b> ${account.maxEvoGuns || 'Not specified'}</span><span><b>Outfits:</b> ${account.outfits || 'Not specified'}</span><span><b>Emotes:</b> ${account.emotes || 'Not specified'}</span><span><b>Arrival animation:</b> ${account.arrivalAnimation || 'Not specified'}</span><span><b>Look changer:</b> ${account.lookChanger || 'Not specified'}</span><span><b>Characters:</b> ${account.characters ?? 0}</span><span><b>Inventory summary:</b> ${account.meta || 'Not specified'}</span><span><b>Booyah Pass:</b> ${account.booyahPass || 'No'}</span><span><b>Elite Pass:</b> ${account.elitePass || 'No'}</span>`;
    const highlights = document.createElement('p');
    highlights.className = 'product-detail-highlights';
    highlights.textContent = 'Verified account · Premium loadout · High-level inventory · Ready to play · Fast delivery';
    featureGrid.after(highlights);
    const sellerCard = document.createElement('div');
    sellerCard.className = 'product-seller-card';
    sellerCard.innerHTML = `<div class="product-seller-avatar">★</div><div class="product-seller-info"><strong>${account.seller || 'Peter Shop Seller'}</strong><span>★ ${account.rating || '5.0'}</span><small>Verified seller since 2026</small><b>${Number(account.reviews || 0).toLocaleString()} reviews</b><button class="product-like-button ${isSellerLiked(account.sellerKey) ? 'is-liked' : ''}" data-account-id="${account.id}" data-seller-key="${account.sellerKey || ''}" type="button"><span class="like-label">Like</span><span class="like-count">${Number(account.likes || 0).toLocaleString()}</span></button></div>${account.status === 'sold' ? '<strong class="product-sold-label">SOLD</strong>' : ''}`;
    sellerCard.querySelector('.product-like-button').insertAdjacentHTML('afterbegin', '<span class="like-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z"/></svg></span>');
    sellerCard.querySelector('.product-like-button').addEventListener('click', event => window.peterShopLike?.(account.id, event.currentTarget));
    const report = document.createElement('button');
    report.className = 'product-report';
    report.type = 'button';
    report.textContent = 'Report offer';
    featureGrid.after(sellerCard, report);
  }, [account]);

  useEffect(() => {
    const main = document.querySelector('.product-main');
    const layout = main?.querySelector('.product-layout');
    if (!main || !layout || main.querySelector('.fast-checkout')) return;
    const checkout = document.createElement('section');
    checkout.className = 'fast-checkout';
    checkout.innerHTML = `<div class="checkout-heading"><h2>Fast checkout</h2><div class="checkout-trust"><span>✹ <b>Delivery within 24h</b></span><span>⬡ <b>Account creds can be changed</b></span><span>♧ <b>Seller approved by Peter Shop</b></span></div></div><div class="checkout-grid"><div class="checkout-benefits"><article><i>♢</i><strong>Full Protection</strong><p>We'll help secure your account and change the password.</p></article><article><i>♡</i><strong>2-Month Safety</strong><p>Get a full refund if anything goes wrong - guaranteed.</p></article><article><i>ϟ</i><strong>Instant Delivery</strong><p>Payment check in 1-15 min. Credentials drop instantly.</p></article></div><div class="checkout-card"><label><input type="checkbox" checked /> Lifetime warranty <span>+€33.56 ⓘ</span></label><div className="checkout-total"><small>Total</small><strong>${formatCurrency(account.price, window.peterShopCurrency || 'USD')}<em></em></strong></div><small class="checkout-vat">excl VAT</small><input class="checkout-email" type="email" placeholder="Enter your email" /><p class="checkout-cashback">$2.01 cashback after purchase</p><button class="checkout-buy" type="button" ${account.status === 'sold' ? 'disabled' : ''}>${account.status === 'sold' ? 'Sold' : 'Buy now ♢'}</button></div></div>`;
    const totalRow = checkout.querySelector('[classname="checkout-total"]');
    if (totalRow) {
      totalRow.className = 'checkout-total';
      const totalValue = totalRow.querySelector('strong');
      if (totalValue) totalValue.textContent = formatCurrency(account.price, window.peterShopCurrency || currency || 'USD');
    }
    checkout.querySelector('.checkout-buy').addEventListener('click', () => {
      if (account.status === 'sold') return;
      const emailInput = checkout.querySelector('.checkout-email');
      if (!emailInput.value || !emailInput.checkValidity()) {
        emailInput.focus();
        emailInput.classList.add('input-error');
        return;
      }
      onBuy(account, emailInput.value.trim());
    });
    layout.after(checkout);
  }, [account, onBuy]);

  useEffect(() => {
    const main = document.querySelector('.product-main');
    if (!main || main.querySelector('.product-faq')) return;
    const faq = document.createElement('section');
    faq.className = 'product-faq';
    faq.innerHTML = '<h2>FAQ</h2>';
    [['How will I receive the Free Fire account after purchase?', 'After payment confirmation, your seller will message you in a private chat with the full login credentials and instructions to access the account immediately.'], ['Can I change the email and account details?', 'Yes. You can update the email and password after receiving the account to fully secure and personalize it.'], ['Do Free Fire accounts include unlocked characters?', 'Yes. Depending on the listing, accounts may include a wide variety of characters, from none to a lot, based on your needs.'], ['Is it safe to buy Free Fire accounts from Peter Shop?', 'Yes. All accounts are verified before listing and delivered securely to ensure a smooth and reliable transaction.']].forEach(([question, answer], index) => {
      const item = document.createElement('article');
      item.className = 'faq-item';
      item.innerHTML = `<button type="button"><strong>${question}</strong><span>⌄</span></button><p>${answer}</p>`;
      item.querySelector('button').addEventListener('click', () => {
        item.classList.toggle('open');
        item.querySelector('button span').textContent = item.classList.contains('open') ? '⌃' : '⌄';
      });
      faq.appendChild(item);
    });
    main.appendChild(faq);
  }, [account]);

  useEffect(() => {
    const main = document.querySelector('.product-main');
    if (!main || main.querySelector('.customer-reviews')) return;
    let reviewEntries = [];
    const escapeReviewHtml = value => {
      const node = document.createElement('span');
      node.textContent = String(value ?? '');
      return node.innerHTML;
    };

    const buildReviewMarkup = (entry) => {
      const title = escapeReviewHtml(entry.title || 'Verified customer');
      const text = escapeReviewHtml(entry.text || entry.review || '');
      const author = escapeReviewHtml(entry.author || entry.name || 'Customer');
      const date = escapeReviewHtml(entry.date || 'Recently');
      const rating = Number(entry.rating || 5);
      const stars = Array.from({ length: 5 }, (_, index) => `<span class="review-star ${index < rating ? 'is-active' : ''}">★</span>`).join('');
      if (!rating) return `<div class="review-slide"><article class="review-card review-empty-state"><strong>${title}</strong><span>${text}</span></article></div>`;
      return `<div class="review-slide"><article class="review-card"><div class="review-stars">${stars}</div><h3>${title}</h3><p>${text}</p><small>${author}, ${date}</small></article></div>`;
    };

    const styleId = 'peter-shop-review-styles';
    if (!document.getElementById(styleId)) {
      const style = document.createElement('style');
      style.id = styleId;
      style.textContent = `
        .customer-reviews { margin-top: 28px; background: rgba(16,19,25,.82); border-radius: 24px; padding: 28px 26px 20px; border: 1px solid rgba(255,255,255,.08); }
        .reviews-heading { display: flex; align-items: center; justify-content: space-between; margin-bottom: 18px; }
        .reviews-heading h2 { margin: 0; font-size: clamp(2rem, 3vw, 4rem); font-weight: 900; line-height: .9; letter-spacing: -0.06em; text-transform: uppercase; }
        .reviews-nav { display: flex; gap: 10px; }
        .reviews-nav button { width: 42px; height: 42px; border-radius: 12px; background: transparent; border: 1px solid rgba(255,255,255,.25); color: #fff; font-size: 22px; cursor: pointer; }
        .customer-review-form { margin-top: 22px; padding-top: 18px; border-top: 1px solid rgba(255,255,255,.08); }
        .review-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
        .customer-review-form label { display: flex; flex-direction: column; gap: 8px; font-size: 12px; letter-spacing: .08em; text-transform: uppercase; color: rgba(255,255,255,.75); }
        .customer-review-form input, .customer-review-form textarea { width: 100%; border: 1px solid rgba(255,255,255,.13); background: rgba(255,255,255,.02); border-radius: 12px; color: #fff; padding: 12px 14px; font: inherit; }
        .customer-review-form textarea { min-height: 110px; resize: vertical; }
        .rating-row { display: flex; align-items: center; justify-content: space-between; gap: 14px; margin: 18px 0 16px; }
        .rating-stars { display: flex; gap: 6px; }
        .star-button { background: transparent; border: none; padding: 0; font-size: 28px; line-height: 1; cursor: pointer; color: #fff; transition: transform .12s ease; }
        .star-button.is-active { color: #d8ff3e; }
        .star-button:hover, .star-button:focus-visible { transform: translateY(-1px); }
        .review-submit-btn { border: none; border-radius: 12px; background: #fff; color: #0f1115; font-weight: 700; padding: 12px 20px; cursor: pointer; }
        .review-modal-backdrop { position: fixed; inset: 0; background: rgba(10,12,16,.7); display: grid; place-items: center; z-index: 40; }
        .review-modal-backdrop.hidden { display: none; }
        .review-modal { background: #12151d; border: 1px solid rgba(255,255,255,.12); border-radius: 18px; padding: 28px 26px; width: min(440px, calc(100vw - 30px)); text-align: center; }
        .review-modal-icon { width: 56px; height: 56px; margin: 0 auto 10px; display: grid; place-items: center; border-radius: 50%; background: #d8ff3e; color: #111; font-size: 28px; font-weight: 900; }
        .review-modal h3 { margin: 0 0 10px; font-size: 30px; }
        .review-modal p { margin: 0; color: rgba(255,255,255,.8); line-height: 1.6; }
        .review-modal button { margin-top: 18px; border: none; border-radius: 12px; background: #fff; color: #111; padding: 10px 18px; font-weight: 700; cursor: pointer; }
        .review-slide { display: block; }
        .review-card { min-height: 220px; }
        .review-stars { display: flex; gap: 4px; margin-bottom: 12px; }
        .review-star { font-size: 18px; color: rgba(255,255,255,.38); }
        .review-star.is-active { color: #d8ff3e; }
        .review-empty-state { display: grid; min-height: 220px; place-content: center; gap: 8px; color: #b9c1c8; text-align: center; }
        .review-empty-state strong { color: #f4f6f8; font-size: 18px; }
        .review-empty-state span { font-size: 13px; }
        @media (max-width: 760px) { .review-form-row { grid-template-columns: 1fr; } .reviews-heading h2 { font-size: 2.1rem; } }
      `;
      document.head.appendChild(style);
    }

    const section = document.createElement('section');
    section.className = 'customer-reviews';
    let autoplayTimer = null;
    let autoplayPaused = false;

    const renderReviews = () => {
      window.clearInterval(autoplayTimer);
      const allReviews = reviewEntries.length ? reviewEntries : [{ title: 'No reviews yet', text: 'Be the first customer to review this seller.', author: account.seller || 'Seller', date: '', rating: 0 }];
      const reviewSlides = allReviews.map(buildReviewMarkup);
      const visibleReviews = window.innerWidth <= 760 ? 1 : 4;
      const slideCount = Math.max(1, reviewSlides.length - visibleReviews + 1);
      section.innerHTML = `
        <div class="reviews-heading">
          <h2>What our customers are saying</h2>
          <div class="reviews-nav">
            <button class="reviews-prev" type="button" aria-label="Previous reviews">‹</button>
            <button class="reviews-next" type="button" aria-label="Next reviews">›</button>
          </div>
        </div>
        <div class="reviews-grid">${reviewSlides.join('')}</div>
        <div class="reviews-dots">${Array.from({ length: slideCount }, (_, index) => `<i class="${index === 0 ? 'active' : ''}"></i>`).join('')}</div>
        <form class="customer-review-form" novalidate>
          <div class="review-form-row">
            <label>
              Name
              <input name="name" type="text" required placeholder="Your name" />
            </label>
            <label>
              Email
              <input name="email" type="email" required placeholder="Your email" />
            </label>
          </div>
          <label style="margin-top:14px;">
            Title
            <input name="title" type="text" required placeholder="Title" />
          </label>
          <div class="rating-row">
            <span>Rating</span>
            <div class="rating-stars" aria-label="Rating stars">
              ${[1, 2, 3, 4, 5].map(value => `<button class="star-button" type="button" data-value="${value}" aria-label="${value} star${value > 1 ? 's' : ''}">★</button>`).join('')}
            </div>
          </div>
          <label>
            Review
            <textarea name="review" required placeholder="Tell us about your experience"></textarea>
          </label>
          <div style="display:flex; justify-content:flex-end; margin-top:14px;">
            <button class="review-submit-btn" type="submit">Send</button>
          </div>
        </form>
        <div class="review-modal-backdrop hidden" aria-live="polite">
          <div class="review-modal">
            <div class="review-modal-icon">✓</div>
            <h3>Thanks for your review</h3>
            <button type="button" class="review-modal-close">Close</button>
          </div>
        </div>
      `;

      const grid = section.querySelector('.reviews-grid');
      const dots = [...section.querySelectorAll('.reviews-dots i')];
      let currentSlide = 0;
      if (grid) {
        grid.style.display = 'flex';
        grid.style.width = `${reviewSlides.length * (100 / visibleReviews)}%`;
        [...grid.children].forEach(slide => {
          slide.style.flex = `0 0 ${100 / reviewSlides.length}%`;
          slide.style.minWidth = '0';
        });
      }
      const showSlide = nextSlide => {
        currentSlide = Math.max(0, Math.min(nextSlide, slideCount - 1));
        if (grid) grid.style.transform = `translateX(-${currentSlide * (100 / reviewSlides.length)}%)`;
        dots.forEach((dot, index) => dot.classList.toggle('active', index === currentSlide));
      };

      const prevButton = section.querySelector('.reviews-prev');
      const nextButton = section.querySelector('.reviews-next');
      if (prevButton) prevButton.addEventListener('click', () => showSlide(currentSlide - 1));
      if (nextButton) nextButton.addEventListener('click', () => showSlide(currentSlide + 1));
      dots.forEach((dot, index) => dot.addEventListener('click', () => showSlide(index)));

      const stars = [...section.querySelectorAll('.star-button')];
      let selectedRating = 5;
      const updateStars = value => {
        selectedRating = value;
        stars.forEach(star => star.classList.toggle('is-active', Number(star.dataset.value) <= value));
      };
      stars.forEach(star => {
        star.addEventListener('click', () => updateStars(Number(star.dataset.value)));
      });
      updateStars(selectedRating);

      const form = section.querySelector('.customer-review-form');
      const modal = section.querySelector('.review-modal-backdrop');
      const closeModal = () => modal?.classList.add('hidden');
      section.querySelector('.review-modal-close')?.addEventListener('click', closeModal);
      modal?.addEventListener('click', event => { if (event.target === modal) closeModal(); });

      const startAutoplay = () => {
        window.clearInterval(autoplayTimer);
        if (!autoplayPaused && slideCount > 1) {
          autoplayTimer = window.setInterval(() => showSlide((currentSlide + 1) % slideCount), 6000);
        }
      };
      section.onmouseenter = () => {
        autoplayPaused = true;
        window.clearInterval(autoplayTimer);
      };
      section.onmouseleave = () => {
        autoplayPaused = false;
        startAutoplay();
      };
      section.onfocusin = () => {
        autoplayPaused = true;
        window.clearInterval(autoplayTimer);
      };
      section.onfocusout = event => {
        if (!section.contains(event.relatedTarget)) {
          autoplayPaused = false;
          startAutoplay();
        }
      };

      form?.addEventListener('submit', async event => {
        event.preventDefault();
        if (!form.checkValidity()) {
          form.reportValidity();
          return;
        }

        const formData = new FormData(form);
        const name = String(formData.get('name') || '').trim();
        const email = String(formData.get('email') || '').trim();
        const title = String(formData.get('title') || '').trim();
        const review = String(formData.get('review') || '').trim();
        const rating = Number(selectedRating || 5);

        const submitButton = form.querySelector('.review-submit-btn');
        submitButton.disabled = true;
        try {
          const response = await fetch('api/seller-reviews.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ listing_id: String(account.id), name, email, title, review, rating: String(rating) })
          });
          const result = await response.json();
          if (!response.ok || !result.ok) throw new Error(result.message || 'Could not submit your review.');
          const reviewResponse = await fetch(`api/seller-reviews.php?listing_id=${encodeURIComponent(account.id)}`, { cache: 'no-store' });
          const reviewResult = await reviewResponse.json();
          if (!reviewResponse.ok || !reviewResult.ok) throw new Error(reviewResult.message || 'Your review was saved, but the review list could not be refreshed.');
          reviewEntries = reviewResult.reviews || [];
          const productRating = document.querySelector('.product-rating strong');
          const productReviewCount = document.querySelector('.product-rating span');
          if (productRating) productRating.textContent = `★ ${reviewResult.seller.rating}`;
          if (productReviewCount) productReviewCount.textContent = `${Number(reviewResult.seller.reviews).toLocaleString()} reviews`;
          form.reset();
          updateStars(5);
          renderReviews();
          section.querySelector('.review-modal-backdrop')?.classList.remove('hidden');
        } catch (error) {
          window.alert(error.message || 'Could not submit your review.');
        } finally {
          submitButton.disabled = false;
        }
      });

      showSlide(0);
      startAutoplay();
    };

    fetch(`api/seller-reviews.php?listing_id=${encodeURIComponent(account.id)}`, { cache: 'no-store' })
      .then(response => response.json())
      .then(result => {
        if (!result.ok) throw new Error(result.message || 'Could not load seller reviews.');
        reviewEntries = result.reviews || [];
        renderReviews();
      })
      .catch(() => { reviewEntries = []; renderReviews(); });
    const checkoutSection = main.querySelector('.fast-checkout');
    if (checkoutSection) checkoutSection.after(section);
    else main.appendChild(section);
    return () => window.clearInterval(autoplayTimer);
  }, [account]);

  useEffect(() => {
    const main = document.querySelector('.product-main');
    if (!main || main.querySelector('.recommended-section')) return;
    const related = accounts.filter(item => item.id !== account.id).slice(0, 3);
    if (!related.length) return;
    const section = document.createElement('section');
    section.className = 'recommended-section';
    section.innerHTML = '<h2>You may also like</h2><div class="recommended-grid"></div>';
    related.forEach(item => {
      const card = document.createElement('article');
      card.className = 'recommended-card';
      card.innerHTML = `<div class="recommended-head"><strong>${item.tier} · Level ${item.level}</strong><span>♡</span></div><div class="recommended-image"><img src="${item.image}" alt="${item.title}" /><b>▧ ${item.images?.length || 1}</b></div><p>${item.description}</p><div class="recommended-meta"><span>▦ Prime ${String(item.gameVersion).replace('Prime ', '')}</span><span>◉ ${item.server}</span></div><div class="recommended-footer"><strong>${formatCurrency(item.price, window.peterShopCurrency || 'USD')}</strong><button type="button">Buy now <span>→</span></button></div>`;
      card.querySelector('img').addEventListener('click', () => onRelated(item));
      card.querySelector('button').addEventListener('click', () => onRelated(item));
      section.querySelector('.recommended-grid').appendChild(card);
    });
    main.appendChild(section);
  }, [account, accounts, onBuy]);

  return <div className="product-page"><header className="product-topbar"><button className="product-back" onClick={onBack}>← Back to accounts</button><Brand /><div className="product-top-actions"><span>♡</span><span>Cart</span></div></header><main className="product-main"><div className="product-breadcrumb">Free Fire Accounts <span>›</span> {account.server} <span>›</span> {account.title}</div><div className="product-layout"><section className="product-gallery"><div className="product-image-frame"><img src={images[imageIndex]} alt={`${account.title} preview ${imageIndex + 1}`} /><span className="product-image-counter">{imageIndex + 1} / {images.length}</span><button className="product-gallery-arrow product-gallery-prev" onClick={() => setImageIndex(current => (current - 1 + images.length) % images.length)} aria-label="Previous image">‹</button><button className="product-gallery-arrow product-gallery-next" onClick={() => setImageIndex(current => (current + 1) % images.length)} aria-label="Next image">›</button></div><div className="product-thumbnails">{images.map((image, index) => <button key={`${image}-${index}`} className={index === imageIndex ? 'active' : ''} onClick={() => setImageIndex(index)}><img src={image} alt="" /></button>)}</div></section><section className="product-summary"><div className="product-label">VERIFIED PETER SHOP LISTING</div><h1>{account.title}</h1><p className="product-subtitle">{account.tier} account · Level {account.level} · {account.server}</p><div className="product-rating"><strong>★ {account.rating || '4.9'}</strong><span>{Number(account.reviews || 0).toLocaleString()} reviews</span><span className="product-online">● Seller online</span></div><p className="product-description">{account.description}. Ready to play with instant delivery and verified account details.</p><div className="product-feature-grid"><span>▦ <b>Prime</b>{account.gameVersion}</span><span>◉ <b>Server</b>{account.server}</span><span>♧ <b>Characters</b>{account.characters}</span><span>⚙ <b>Evo Guns</b>{account.evoGuns ?? 1}</span><span>◍ <b>Booyah Pass</b>{account.booyahPass ?? 'No'}</span><span>◌ <b>Elite Pass</b>{account.elitePass ?? 'No'}</span><span><b>Outfits:</b> ${account.outfits || 'Not specified'}</span><span><b>Emotes:</b> ${account.emotes || 'Not specified'}</span><span><b>Arrival animation:</b> ${account.arrivalAnimation || 'Not specified'}</span><span><b>Look changer:</b> ${account.lookChanger || 'Not specified'}</span></div><div className="product-buy-panel"><div><small>Total price</small><strong>${account.price}<em>.00</em></strong></div><button onClick={() => onBuy(account)}>Buy account <span>→</span></button><p>Instant delivery · Buyer protection included</p></div></section></div></main></div>;
}

function App() {
  const [currency, setCurrency] = useState(() => window.peterShopCurrency || localStorage.getItem('peter-shop-currency') || 'USD');
  const [exchangeRate, setExchangeRate] = useState(() => getNgnRate());
  useEffect(() => { const handleCurrencyChange = event => setCurrency(event.detail); window.addEventListener('peter-shop-currency-change', handleCurrencyChange); return () => window.removeEventListener('peter-shop-currency-change', handleCurrencyChange); }, []);
  useEffect(() => { const handleRateChange = event => setExchangeRate(Number(event.detail) || getNgnRate()); window.addEventListener('peter-shop-exchange-rate-change', handleRateChange); return () => window.removeEventListener('peter-shop-exchange-rate-change', handleRateChange); }, []);
  const [accounts, setAccounts] = useState([]); const [favorites, setFavorites] = useState(() => new Set(JSON.parse(localStorage.getItem('peter-shop-favorites') || '[]').map(Number))); const [cart, setCart] = useState([]); const [details, setDetails] = useState(null); const [product, setProduct] = useState(null); const [checkoutAccount, setCheckoutAccount] = useState(null); const [checkoutEmail, setCheckoutEmail] = useState(''); const [processing, setProcessing] = useState(false); const [cartOpen, setCartOpen] = useState(false); const [favoritesOpen, setFavoritesOpen] = useState(false); const [toast, setToast] = useState(''); const [loading, setLoading] = useState(true);
  useEffect(() => {
    const refreshInventory = () => fetch(API_URL).then(response => response.json()).then(data => {
      const loadedAccounts = data.accounts || [];
      setAccounts(loadedAccounts);
      const productId = Number(new URLSearchParams(window.location.search).get('product'));
      if (productId) {
        const refreshedProduct = loadedAccounts.find(account => Number(account.id) === productId) || null;
        setProduct(current => current && refreshedProduct && current.status === refreshedProduct.status && current.likes === refreshedProduct.likes && current.rating === refreshedProduct.rating ? current : refreshedProduct);
      }
      setLoading(false);
    }).catch(() => {
      if (loading) setToast('Could not load the PHP inventory');
      setLoading(false);
    });
    refreshInventory();
    const refreshTimer = window.setInterval(refreshInventory, 30000);
    return () => window.clearInterval(refreshTimer);
  }, []);
  useEffect(() => { localStorage.setItem('peter-shop-favorites', JSON.stringify([...favorites])); const button = document.getElementById('favorites-toggle'); const count = button?.querySelector('.action-count'); if (count) count.textContent = favorites.size; if (button) button.setAttribute('aria-expanded', String(favoritesOpen)); }, [favorites, favoritesOpen]);
  useEffect(() => { const button = document.getElementById('favorites-toggle'); if (!button) return undefined; const openFavorites = () => setFavoritesOpen(true); button.addEventListener('click', openFavorites); return () => button.removeEventListener('click', openFavorites); }, []);
  useEffect(() => { if (!toast) return; const timer = setTimeout(() => setToast(''), 2200); return () => clearTimeout(timer); }, [toast]);
  const toggleFavorite = id => { setFavorites(current => { const next = new Set(current); next.has(id) ? next.delete(id) : next.add(id); setToast(next.has(id) ? 'Added to favorites' : 'Removed from favorites'); return next; }); };
  useEffect(() => {
    window.peterShopLike = async (id, button) => {
      const sellerKey = String(button?.dataset.sellerKey || '');
      if (!sellerKey) return;
      const likedKeys = (() => {
        try { return JSON.parse(localStorage.getItem('peter-shop-liked-sellers') || '[]').map(String); }
        catch (error) { return []; }
      })();
      const wasLiked = likedKeys.includes(sellerKey);
      const nextLikedKeys = wasLiked ? likedKeys.filter(key => key !== sellerKey) : [...likedKeys, sellerKey];
      localStorage.setItem('peter-shop-liked-sellers', JSON.stringify(nextLikedKeys));
      document.querySelectorAll(`.product-like-button[data-seller-key="${sellerKey}"]`).forEach(likeButton => likeButton.classList.toggle('is-liked', !wasLiked));
      try {
        const response = await fetch(API_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: wasLiked ? 'unlike' : 'like', id, visitor_id: getVisitorId() }) });
        const result = await response.json();
        if (!response.ok || !result.ok) throw new Error(result.message || 'Could not like this listing.');
        document.querySelectorAll(`.product-like-button[data-seller-key="${sellerKey}"] .like-count`).forEach(count => { count.textContent = Number(result.account.likes || 0).toLocaleString(); });
        setAccounts(current => current.map(account => account.sellerKey === sellerKey ? { ...account, likes: result.account.likes } : account));
        setProduct(current => current && current.sellerKey === sellerKey ? { ...current, likes: result.account.likes } : current);
      } catch (error) {
        localStorage.setItem('peter-shop-liked-sellers', JSON.stringify(likedKeys));
        document.querySelectorAll(`.product-like-button[data-seller-key="${sellerKey}"]`).forEach(likeButton => likeButton.classList.toggle('is-liked', wasLiked));
        setToast(error.message || 'Could not like this listing.');
      }
    };
    return () => { delete window.peterShopLike; };
  }, []);
  const addToCart = account => { setCart(current => current.some(item => item.id === account.id) ? current : [...current, account]); setDetails(null); setCartOpen(true); setToast('Account added to your cart'); };
  const startCheckout = (account, email = '') => { setCheckoutAccount(account); setCheckoutEmail(email); };
  const completePayment = (total, selectedCurrency = 'USD', method = 'Bank Transfer') => { const liveRate = getNgnRate(); const usdTotal = selectedCurrency === 'NGN' ? total / liveRate : total; setCheckoutAccount(null); setProcessing(true); window.setTimeout(() => { window.location.replace(`payment.php?amount=${encodeURIComponent(usdTotal.toFixed(2))}&exchange_rate=${encodeURIComponent(liveRate)}&method=${encodeURIComponent(method === 'Bank Transfer' ? 'bank' : 'crypto')}&email=${encodeURIComponent(checkoutEmail)}&product=${encodeURIComponent(checkoutAccount?.product_id || checkoutAccount?.title || 'Free Fire account')}&product_id=${encodeURIComponent(checkoutAccount?.product_id || '')}&listing_id=${encodeURIComponent(checkoutAccount?.id || '')}`); }, 3000); };
  const openProductPage = account => { window.location.href = `product.php?product=${account.id}`; };
  if (product) return <><ProductPage account={product} accounts={accounts} favorites={favorites} onFavorite={toggleFavorite} onBack={() => { window.location.href = 'index.php'; }} onBuy={startCheckout} onRelated={openProductPage} currency={currency} exchangeRate={exchangeRate} />{checkoutAccount && <PaymentModal account={checkoutAccount} email={checkoutEmail} onEmailChange={setCheckoutEmail} onClose={() => setCheckoutAccount(null)} onPay={completePayment} exchangeRate={exchangeRate} />}{processing && <ProcessingOverlay />}{toast && <div className="toast show" role="status">{toast}</div>}</>;
  return <>{checkoutAccount && <PaymentModal account={checkoutAccount} email={checkoutEmail} onEmailChange={setCheckoutEmail} onClose={() => setCheckoutAccount(null)} onPay={completePayment} exchangeRate={exchangeRate} />}{processing && <ProcessingOverlay />}<div className="marketplace-body"><main className="market-main" id="top"><Hero /><TrustStrip />{loading ? <section className="catalog-section"><div className="empty-state">Loading verified accounts...</div></section> : <Catalog accounts={accounts} favorites={favorites} onFavorite={toggleFavorite} onDetails={setDetails} onBuy={openProductPage} />}<InformationSection /></main></div>{cartOpen && <CartDrawer cart={cart} onRemove={id => setCart(cart.filter(item => item.id !== id))} onClose={() => setCartOpen(false)} onCheckout={() => { if (cart.length !== 1) { setToast('Checkout is currently available for one account at a time.'); return; } setCartOpen(false); openProductPage(cart[0]); }} />}{favoritesOpen && <FavoritesDrawer favorites={favorites} accounts={accounts} onRemove={toggleFavorite} onClose={() => setFavoritesOpen(false)} onDetails={account => { setFavoritesOpen(false); setDetails(account); }} onBuy={openProductPage} />}{details && <DetailsDialog account={details} onClose={() => setDetails(null)} />}{toast && <div className="toast show" role="status">{toast}</div>}</>;
}

function StoreFooter() {
  const groups = [['Company', ['About us', 'Blog', 'Contact us', 'Become a PRO', 'Cashback', 'Legit']], ['Work with us', ['Booster', 'Gold Seller', 'Account / Item Seller', 'Content Creator', 'Influencer']], ['Customer Service', ['Login as PRO', 'Sitemaps', 'Billing support', 'FAQ']], ['Legal & Policies', ['Terms and Conditions', 'Terms for Sellers', 'Privacy policy', 'Cookie policy', 'Report DMCA']]];
  const marketGroups = [['Boosting', ['WoW', 'Destiny 2', 'CoD', 'Division 2', 'All Boosting']], ['Accounts', ['Fortnite', 'Call of Duty', 'Clash of Clans', 'Pokemon GO', 'All Accounts']], ['Currency', ['WoW', 'FC 27', 'PoE 2', 'Final Fantasy XIV', 'All Currency']], ['Items', ['Grow a Garden 2', 'Steal a Brainrot', 'ARC Raiders', 'Roblox', 'All Items']], ['Top-ups', ['Fortnite', 'Pokemon GO', 'Genshin Impact', 'Roblox', 'All Top-ups']]];
  return <footer className="store-footer" id="support"><div className="footer-main"><div className="footer-topline"><div className="footer-logo"><span className="brand-mark">P</span><strong>PETER SHOP</strong></div><div className="language-picker">EN 🇬🇧 <span>FR 🇫🇷</span><span>ES 🇪🇸</span><span>DE 🇩🇪</span></div><div className="social-links"><a href="#support" aria-label="Instagram">◎</a><a href="#support" aria-label="Facebook">f</a><a href="#support" aria-label="YouTube">▶</a></div></div><div className="footer-columns">{groups.map(([title, links]) => <div key={title}><h3>{title}</h3>{links.map(link => <a href="#support" key={link}>{link}</a>)}</div>)}<div className="contact-card"><strong>+1 555 401 11 56</strong><span>support@vaultdrop.gg</span><button onClick={() => window.location.href = 'mailto:support@vaultdrop.gg'}>Chat with us&nbsp; ◌</button></div></div><div className="footer-market-links">{marketGroups.map(([title, links]) => <div key={title}><h3>{title}</h3>{links.map(link => <a href="#accounts" key={link}>{link}</a>)}</div>)}</div><div className="footer-bottom"><div className="app-badges"><a href="#support"> <span>Download on the<br /><b>App Store</b></span></a><a href="#support">▶ <span>GET IT ON<br /><b>Google Play</b></span></a></div><small>© 2024 — 2026 All rights reserved<br />VaultDrop, your independent Free Fire marketplace.</small></div><p className="legal-copy">Peter Shop is an independent service provider and is not endorsed by, directly affiliated with, maintained, authorized, or sponsored by any third-party company, publisher, developer, rights holder, or franchise owner. All trademarks, service marks, logos, brand names, and copyrighted materials referenced on this platform belong to their respective owners.</p></div></footer>;
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
