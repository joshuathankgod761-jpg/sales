(() => {
  const greeting = document.getElementById('dashboard-greeting');
  const dateLabel = document.getElementById('dashboard-local-date');
  if (!greeting || !dateLabel) return;

  const timezone = greeting.dataset.timezone || undefined;
  const userName = greeting.dataset.name || 'User';
  const updateGreeting = () => {
    const now = new Date();
    let hour;
    let dateText;
    try {
      hour = Number(new Intl.DateTimeFormat('en', { hour: 'numeric', hour12: false, timeZone: timezone }).format(now));
      dateText = new Intl.DateTimeFormat('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: timezone }).format(now);
    } catch (error) {
      hour = now.getHours();
      dateText = new Intl.DateTimeFormat('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(now);
    }

    const greetingText = hour >= 5 && hour < 12 ? 'Good morning'
      : hour >= 12 && hour < 18 ? 'Good afternoon'
        : 'Good night';
    greeting.textContent = `${greetingText}, ${userName}.`;
    dateLabel.textContent = dateText.toUpperCase();
  };

  updateGreeting();
  window.setInterval(updateGreeting, 60 * 1000);
})();