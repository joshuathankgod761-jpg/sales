(() => {
  const mountWidget = (container, source, config) => {
    const script = document.createElement('script');
    script.type = 'text/javascript';
    script.async = true;
    script.src = source;
    script.textContent = JSON.stringify(config);
    container.appendChild(script);
  };

  const chartContainer = document.querySelector('.chart-frame .tradingview-widget-container');
  if (chartContainer) {
    mountWidget(chartContainer, 'https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js', {
      allow_symbol_change: true,
      calendar: false,
      details: true,
      hide_side_toolbar: false,
      hide_top_toolbar: false,
      hide_legend: false,
      hide_volume: true,
      interval: '1',
      locale: 'en',
      save_image: false,
      style: '1',
      symbol: 'FX_IDC:USDNGN',
      theme: 'dark',
      timezone: 'Etc/UTC',
      backgroundColor: '#151b1d',
      gridColor: 'rgba(145, 160, 161, 0.12)',
      withdateranges: true,
      watchlist: [],
      compareSymbols: [],
      studies: [],
      support_host: 'https://www.tradingview.com',
      autosize: true
    });
  }

  const crossRatesContainer = document.querySelector('.cross-rates-frame .tradingview-widget-container');
  if (crossRatesContainer) {
    mountWidget(crossRatesContainer, 'https://s3.tradingview.com/external-embedding/embed-widget-forex-cross-rates.js', {
      width: '100%',
      height: 380,
      currencies: ['USD', 'NGN', 'EUR', 'GBP', 'JPY', 'CHF', 'CAD', 'AUD'],
      isTransparent: false,
      colorTheme: 'dark',
      locale: 'en',
      backgroundColor: '#151b1d'
    });
  }
})();