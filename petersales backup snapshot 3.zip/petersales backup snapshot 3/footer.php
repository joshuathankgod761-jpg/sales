<footer class="store-footer shared-footer" id="support">
  <div class="footer-main">
    <div class="footer-topline">
      <div class="footer-logo"><span class="brand-mark">P</span><strong>PETER SHOP</strong></div>
      <div class="social-links"><a href="#support" aria-label="Instagram">&#9678;</a><a href="#support" aria-label="Facebook">f</a><a href="#support" aria-label="YouTube">&#9654;</a></div>
    </div>
    <div class="footer-columns">
      <div><h3>Company</h3><a href="#support">About us</a><a href="#support">Contact us</a><a href="#support">Become a PRO</a></div>
      <div><h3>Customer Service</h3><a href="#support">Billing support</a><a href="#support">FAQ</a><a href="#support">Privacy policy</a></div>
      <div class="contact-card"><span>support@vaultdrop.gg</span><a class="whatsapp-link" href="https://wa.me/2348102755894" target="_blank" rel="noopener noreferrer" aria-label="Chat with Peter Shop on WhatsApp"><svg viewBox="0 0 32 32" aria-hidden="true"><path d="M16 3.2A12.5 12.5 0 0 0 5.3 22.2L3.6 28.4l6.4-1.7A12.5 12.5 0 1 0 16 3.2Zm0 22.7a10.1 10.1 0 0 1-5.1-1.4l-.4-.2-3.8 1 1-3.7-.3-.4A10.1 10.1 0 1 1 16 25.9Zm5.5-7.6c-.3-.2-1.8-.9-2.1-1s-.5-.2-.7.2-.8 1-.9 1.1-.3.2-.6.1a8.2 8.2 0 0 1-2.4-1.5 9 9 0 0 1-1.7-2.1c-.2-.3 0-.5.1-.6l.5-.6.3-.5c.1-.2 0-.4 0-.5l-.9-2.2c-.2-.6-.5-.5-.7-.5h-.6a1.2 1.2 0 0 0-.9.4 3.8 3.8 0 0 0-1.2 2.8 6.6 6.6 0 0 0 1.4 3.5 15 15 0 0 0 5.8 5.1c.8.3 1.4.6 1.9.7.8.3 1.5.2 2.1.1a3.4 3.4 0 0 0 2.2-1.6 2.7 2.7 0 0 0 .2-1.6c-.1-.1-.3-.2-.6-.4Z"/></svg><span>Chat on WhatsApp</span></a></div>
    </div>
    <div class="footer-bottom"><small>&copy; 2024 &mdash; 2026 All rights reserved<br>Peter Shop, your independent Free Fire marketplace.</small></div>
  </div>
</footer>
