<?php
$requiredArea = 'adminseller';
require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../api/db.php';
petershop_db_bootstrap();
$listingPosterName = (string) ($_SESSION['auth_user']['name'] ?? '');
$dashboardUserName = trim((string) ($_SESSION['auth_user']['name'] ?? 'User'));
$adminSettings = petershop_admin_settings_record();
$dashboardTimezone = 'Africa/Lagos';
foreach (($adminSettings['sellers'] ?? []) as $sellerProfile) {
  if (strtolower((string) ($sellerProfile['email'] ?? '')) !== strtolower((string) ($_SESSION['auth_user']['email'] ?? ''))) continue;
  $dashboardTimezone = preg_replace('/\s+\([^)]*\)$/', '', (string) ($sellerProfile['timezone'] ?? $dashboardTimezone));
  break;
}
try {
  new DateTimeZone($dashboardTimezone);
} catch (Throwable $error) {
  $dashboardTimezone = 'Africa/Lagos';
}
$pageTitle = 'Peter Shop Admin';
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@500;600;700&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="admin.css?v=<?= filemtime(__DIR__ . '/admin.css') ?>">
  <style>
    .image-upload-label { gap: 7px; }
    .image-upload { position: relative; display: grid; place-items: center; min-height: 112px; padding: 18px; border: 1px dashed rgba(216,255,62,.4); border-radius: 9px; background: rgba(216,255,62,.04); text-align: center; cursor: pointer; transition: border-color .2s, background .2s; }
    .image-upload:hover { border-color: var(--acid); background: rgba(216,255,62,.08); }
    .image-upload input { position: absolute; width: 1px; height: 1px; overflow: hidden; opacity: 0; }
    .upload-icon { display: grid; width: 30px; height: 30px; place-items: center; margin-bottom: 7px; border-radius: 8px; background: rgba(216,255,62,.14); color: var(--acid); font-size: 16px; }
    .image-upload strong { color: var(--ink); font-size: 11px; }
    .image-upload small { margin-top: 4px; color: var(--muted); font-size: 9px; font-weight: 400; }
    .inventory-row-actions { display: flex; gap: 6px; }
    .inventory-action { padding: 6px 8px; border: 1px solid var(--line); border-radius: 5px; background: transparent; color: var(--ink); font-size: 10px; cursor: pointer; white-space: nowrap; }
    .inventory-action:hover { border-color: var(--acid); color: var(--acid); }
    .inventory-action.danger:hover { border-color: #ff6c48; color: #ff6c48; }
    .sold-status { border-color: rgba(255,108,72,.3); background: rgba(255,108,72,.1); color: #ff9b83; }
    .pending-orders-count { color: #ff6c48 !important; }
    .pending-orders-card strong { color: #ff6c48; }
    .stat-card-link { color: inherit; text-decoration: none; cursor: pointer; }
    .stat-card-link:hover { border-color: rgba(117,75,255,.55); transform: translateY(-2px); }
    .image-preview { margin-top: 12px; border: 1px solid var(--line); border-radius: 8px; overflow: hidden; background: var(--panel-light); }
    .image-preview { display: grid; grid-template-columns: repeat(5, 1fr); gap: 6px; padding: 6px; }
    .image-preview img { display: block; width: 100%; aspect-ratio: 1; object-fit: cover; border-radius: 5px; }
    .account-modal { max-height: calc(100vh - 40px); overflow-y: auto; }
    .guns-group { grid-column: 1 / -1; min-width: 0; padding: 16px; border: 1px solid var(--line); border-radius: 8px; background: rgba(255,255,255,.02); }
    .guns-group h3 { margin: 0 0 14px; color: var(--ink); font-size: 13px; }
    .guns-fields { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 15px; min-width: 0; }
    .guns-fields label { display: grid; min-width: 0; gap: 7px; color: #aab6b8; font-size: 10px; font-weight: 700; }
    .guns-fields input, .guns-fields select, .guns-fields textarea { width: 100%; min-width: 0; box-sizing: border-box; padding: 11px; border: 1px solid var(--line); border-radius: 7px; outline: 0; background: var(--panel-light); color: var(--ink); font-size: 11px; }
    .guns-fields textarea { min-height: 100px; resize: vertical; }
    .guns-fields .full-width { grid-column: 1 / -1; }
    .guns-fields select,
    .guns-fields textarea { width: 100%; }
    @media (max-width: 500px) { .guns-fields { grid-template-columns: 1fr; } .guns-fields .full-width { grid-column: auto; } }
  </style>
</head>
<body>
  <div class="admin-shell">
    <?php include __DIR__ . '/nav.php'; ?>
    <main class="admin-main" id="dashboard">
      <header class="admin-topbar"><button class="mobile-menu" type="button" aria-label="Open menu">☰</button><div><p class="eyebrow" id="dashboard-local-date" data-timezone="<?= htmlspecialchars($dashboardTimezone, ENT_QUOTES, 'UTF-8') ?>"></p><h1 id="dashboard-greeting" data-name="<?= htmlspecialchars($dashboardUserName, ENT_QUOTES, 'UTF-8') ?>" data-timezone="<?= htmlspecialchars($dashboardTimezone, ENT_QUOTES, 'UTF-8') ?>"></h1></div><div class="top-actions"><button class="outline-button" type="button" id="open-add-account">+ Add account</button><button class="notification-button" type="button" aria-label="Notifications">◌<i></i></button></div></header>
      <section class="admin-content">
        <div class="stats-grid">
          <article class="stat-card"><div class="stat-icon lime">$</div><div><span>Total sales</span><strong id="total-sales">$0.00</strong><small class="positive" id="total-sales-note">Confirmed orders</small></div><span class="sparkline">▁▂▃▃▄▅▆▇</span></article>
          <a class="stat-card stat-card-link" id="pending-orders-card" href="orders.php"><div class="stat-icon purple">◇</div><div><span>Pending orders</span><strong id="orders-total">0</strong><small><em>Awaiting payment review</em></small></div><span class="sparkline purple-line">▂▃▂▄▅▄▆▇</span></a>
          <article class="stat-card"><div class="stat-icon blue">▤</div><div><span>Active listings</span><strong id="active-listings">0</strong><small><em>Across all categories</em></small></div><span class="sparkline blue-line">▅▄▅▆▅▇▆▇</span></article>
          <a class="stat-card stat-card-link" id="fx-rate-card" href="../exchange-rates.php"><div class="stat-icon orange">₦</div><div><span>USD to NGN</span><strong class="fx-rate-value">Loading...</strong><small class="fx-rate-updated">Fetching latest rate</small></div><span class="sparkline orange-line">↗</span></a>
        </div>
        <section class="dashboard-grid">
          <article class="panel sales-panel" id="analytics"><div class="panel-heading"><div><p class="eyebrow">PERFORMANCE</p><h2>Sales overview</h2></div><select id="sales-period" aria-label="Sales period"><option value="30">Last 30 days</option><option value="7">Last 7 days</option><option value="year">This year</option></select></div><div class="chart"><div class="chart-y"><span>$0</span><span>$0</span><span>$0</span><span>$0</span><span>$0</span><span>$0</span></div><div class="chart-body"><div class="grid-lines"><i></i><i></i><i></i><i></i><i></i><i></i></div><svg viewBox="0 0 700 230" role="img" aria-label="Sales trend chart"><defs><linearGradient id="chart-fill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#d8ff3e" stop-opacity=".25"/><stop offset="1" stop-color="#d8ff3e" stop-opacity="0"/></linearGradient></defs><path class="chart-area" d="M0 210 L700 210 Z"/><path class="chart-line" d="M0 210 L700 210"/></svg><div class="chart-x"><span></span><span></span><span></span><span></span><span></span></div></div></div></article>
          <article class="panel activity-panel"><div class="panel-heading"><div><p class="eyebrow">LIVE FEED</p><h2>Recent activity</h2></div><a class="text-button" href="orders.php">View all</a></div><div class="activity-list" id="dashboard-activity"><div class="activity-empty">Loading activity...</div></div></article>
        </section>
        <section class="panel inventory-panel" id="inventory"><div class="panel-heading inventory-heading"><div><p class="eyebrow">CATALOG</p><h2>Inventory</h2><span class="panel-subtitle">Manage your active account listings</span></div><div class="inventory-actions"><label class="admin-search"><span>⌕</span><input id="inventory-search" type="search" placeholder="Search listings..." /></label><select id="inventory-filter" aria-label="Filter inventory"><option value="all">All listings</option><option value="mythic">Mythic</option><option value="diamond">Diamond</option><option value="starter">Starter</option></select></div></div><div class="table-wrap"><table><thead><tr><th>LISTING</th><th>SELLER</th><th>SERVER</th><th>PRICE</th><th>STATUS</th><th></th></tr></thead><tbody id="inventory-rows"><tr><td colspan="6" class="table-loading">Loading inventory...</td></tr></tbody></table></div><div class="table-footer"><span id="inventory-summary">Showing inventory</span><button class="text-button" type="button">Manage all listings <span>→</span></button></div></section>
      </section>
    </main>
  </div>
  <div class="modal-backdrop" id="account-modal" hidden><section class="account-modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><button class="modal-close" type="button" aria-label="Close">×</button><p class="eyebrow">NEW LISTING</p><h2 id="modal-title">Add an account</h2><p class="modal-copy">Create a listing draft for the Peter Shop catalog.</p><form id="account-form"><input type="hidden" name="product_id" value="" /><div class="form-grid"><label>Listing title<input name="title" required placeholder="e.g. FF01" /></label><label>Price in USD<input name="price" type="number" min="1" step="0.01" required placeholder="49.00" /></label><label>Tier<select name="tier"><option>Bronze</option><option>Silver</option><option>Gold</option><option>Platinum</option><option>Diamond</option><option>Heroic</option><option>Grand Master</option></select></label><label>Account level<input name="level" type="number" min="1" max="100" required placeholder="58" /></label><label>Game version<select name="gameVersion"><option>Prime 1</option><option>Prime 2</option><option>Prime 3</option><option>Prime 4</option><option>Prime 5</option><option>Prime 6</option><option>Free Fire Max</option></select></label><label>Server<select name="server"><option>Indonesia</option><option>Brazil</option><option>LATAM</option><option>Pakistan</option><option>India</option><option>Europe</option></select></label><label>Weapon category<select name="category"><option value="all">All</option><option value="artifact">Artifact</option><option value="legendary">Legendary</option><option value="epic">Epic</option><option value="rare">Rare</option><option value="uncommon">Uncommon</option></select></label><label>Weapon type tag<input name="tag" placeholder="All 367 weapons" /></label><label>Outfits<input name="outfits" type="text" placeholder="e.g. 35" /></label><label>Emotes<input name="emotes" type="text" placeholder="e.g. 35" /></label><label>Arrival animation<input name="arrivalAnimation" type="text" placeholder="e.g. 35" /></label><label>Look changer<input name="lookChanger" type="text" placeholder="e.g. 35" /></label><label>Characters<input name="characters" type="number" min="0" placeholder="39" /></label><label>EVO guns<input name="evoGuns" type="number" min="0" placeholder="1" /></label><label>Booyah Pass<select name="booyahPass"><option>No</option><option>Yes</option></select></label><label>Elite Pass<select name="elitePass"><option>No</option><option>Yes</option></select></label><label>Seller name<input name="seller" required placeholder="Seller handle" /></label><label>Rating<input name="rating" type="number" min="0" max="5" step="0.1" placeholder="4.9" /></label><label>Review count<input name="reviews" type="number" min="0" placeholder="128" /></label><label class="full-field">Description<textarea name="description" rows="3" required placeholder="FF275 | Lv58/292 Weapon ..."></textarea></label><label class="full-field image-upload-label">Listing image<span class="image-upload"><input id="listing-image" name="image" type="file" accept="image/png,image/jpeg,image/webp" required /><span class="upload-icon">▧</span><strong id="image-upload-title">Choose listing image</strong><small id="image-upload-name">PNG, JPG or WEBP up to 10MB</small></span></label></div><div class="image-preview" id="image-preview" hidden><img id="image-preview-img" alt="Listing image preview" /></div><div class="modal-actions"><button class="cancel-button" type="button">Cancel</button><button class="primary-admin-button" type="submit">Publish to store</button></div></form></section></div>
  <script>
    const rows = document.getElementById('inventory-rows');
    const search = document.getElementById('inventory-search');
    const filter = document.getElementById('inventory-filter');
    let accounts = [];
    const money = value => `$${Number(value).toFixed(2)}`;
    const renderInventory = () => {
      const term = search.value.toLowerCase().trim();
      const selectedFilter = filter.value;
      const visible = accounts.filter(account => (!term || `${account.title} ${account.seller} ${account.server} ${account.product_id || account.id}`.toLowerCase().includes(term)) && (selectedFilter === 'all' || account.category === selectedFilter));
      rows.innerHTML = visible.length ? visible.map(account => {
        const productId = account.product_id || account.title || `P-${account.id}`;
        const sold = account.status === 'sold';
        return `<tr><td><div class="listing-cell"><img src="${account.image}" alt="" onerror="this.onerror=null;this.src='https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=900&q=85';"><span><strong>${productId}</strong><small>Listing #${account.id} · ${account.tier} · Level ${account.level}</small></span></div></td><td>${account.seller}</td><td>${account.server}</td><td><strong>${money(account.price)}</strong></td><td><span class="status-pill ${sold ? 'sold-status' : 'active-status'}">${sold ? 'Sold' : 'Active'}</span></td><td><div class="inventory-row-actions"><button class="inventory-action" type="button" data-action="images" data-id="${account.id}">Add images (${account.images?.length || 0})</button><button class="inventory-action" type="button" data-action="status" data-status="${sold ? 'active' : 'sold'}" data-id="${account.id}">${sold ? 'Restore' : 'Mark sold'}</button><button class="inventory-action danger" type="button" data-action="delete" data-id="${account.id}">Delete</button></div></td></tr>`;
      }).join('') : '<tr><td colspan="6" class="table-empty">No listings match your search.</td></tr>';
      document.getElementById('inventory-summary').textContent = `Showing ${visible.length} of ${accounts.length} listings`;
    };
    const updateInventoryCounts = () => {
      document.getElementById('active-listings').textContent = accounts.filter(account => account.status !== 'sold').length;
      document.getElementById('nav-inventory-count').textContent = accounts.length;
    };
    fetch('../api/accounts.php').then(response => response.json()).then(data => {
      accounts = data.accounts || [];
      updateInventoryCounts();
      const productIdInput = modal.querySelector('[name="product_id"]');
      if (productIdInput) {
        const highestId = accounts.reduce((max, account) => {
          const candidate = String(account.product_id || '').match(/^FF(\d+)$/i)?.[1];
          return Math.max(max, candidate ? Number(candidate) : 0);
        }, 0);
        productIdInput.value = `FF${String(highestId + 1).padStart(2, '0')}`;
      }
      renderInventory();
    }).catch(() => { rows.innerHTML = '<tr><td colspan="6" class="table-empty">Could not load inventory.</td></tr>'; });
    search.addEventListener('input', renderInventory); filter.addEventListener('change', renderInventory);
    const loadOrderCount = () => fetch('../api/orders.php', { cache: 'no-store' }).then(response => response.json()).then(data => {
      const count = (data.orders || []).filter(order => order.status === 'pending').length;
      document.getElementById('orders-total').textContent = count;
      document.getElementById('nav-orders-count').textContent = count;
      document.getElementById('orders-total').classList.toggle('pending-orders-count', count > 0);
      document.getElementById('nav-orders-count').classList.toggle('pending-orders-count', count > 0);
      document.getElementById('pending-orders-card').classList.toggle('pending-orders-card', count > 0);
    });
    loadOrderCount().catch(() => {});
    const orderCountTimer = window.setInterval(() => loadOrderCount().catch(() => {}), 5000);
    rows.addEventListener('click', async event => {
      const button = event.target.closest('button[data-action]');
      if (!button) return;
      const id = Number(button.dataset.id);
      const action = button.dataset.action;
      if (action === 'images') {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'image/png,image/jpeg,image/webp';
        input.multiple = true;
        input.onchange = async () => {
          if (!input.files?.length) return;
          const totalBytes = [...input.files].reduce((total, file) => total + file.size, 0);
          if (totalBytes > 100 * 1024 * 1024 || [...input.files].some(file => file.size > 20 * 1024 * 1024)) {
            window.alert('Images must be under 20 MB each and 100 MB total.');
            return;
          }
          const formData = new FormData();
          formData.set('action', 'images');
          formData.set('id', String(id));
          for (const file of input.files) formData.append('images[]', file);
          button.disabled = true;
          try {
            const response = await fetch('../api/accounts.php', { method: 'POST', body: formData });
            const responseText = await response.text();
            let result;
            try {
              result = JSON.parse(responseText);
            } catch (error) {
              throw new Error('The server returned an invalid upload response. Check XAMPP PHP upload limits and try again.');
            }
            if (!response.ok || !result.ok) throw new Error(result.message || 'Could not update listing images.');
            accounts = accounts.map(account => Number(account.id) === id ? result.account : account);
            renderInventory();
            window.alert(`${result.account.images.length} listing images saved.`);
          } catch (error) {
            button.disabled = false;
            window.alert(error.message || 'Could not update listing images.');
          }
        };
        input.click();
        return;
      }
      if (action === 'delete' && !window.confirm('Delete this listing permanently?')) return;
      button.disabled = true;
      try {
        const response = await fetch('../api/accounts.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: action === 'status' ? 'status' : 'delete', id, status: button.dataset.status })
        });
        const result = await response.json();
        if (!response.ok || !result.ok) throw new Error(result.message || 'Could not update listing.');
        accounts = action === 'delete' ? accounts.filter(account => Number(account.id) !== id) : accounts.map(account => Number(account.id) === id ? result.account : account);
        updateInventoryCounts();
        renderInventory();
      } catch (error) {
        button.disabled = false;
        window.alert(error.message || 'Could not update listing.');
      }
    });
    const modal = document.getElementById('account-modal');
    modal.querySelector('[name="title"]').placeholder = 'e.g. Grand Master Level 71';
    const sellerNameInput = modal.querySelector('[name="seller"]');
    if (sellerNameInput) {
      sellerNameInput.value = <?= json_encode($listingPosterName, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>;
      sellerNameInput.readOnly = true;
    }
    const descriptionInput = modal.querySelector('[name="description"]');
    if (descriptionInput) {
      descriptionInput.placeholder = 'Write full details about the account here. You can put emojis too. E.g. Season 2 Hip Hop Bundle, High-Level Evo Gun Skins, 50 Emotes, Entry Animation, 261 Vault, 6 Years Old ID, Level 71';
    }
    const formGrid = modal.querySelector('.form-grid');
    const outfitsField = modal.querySelector('[name="outfits"]')?.closest('label');
    if (formGrid && !modal.querySelector('[name="meta"]')) {
      const summaryField = document.createElement('label');
      summaryField.innerHTML = 'Inventory summary<input name="meta" type="text" maxlength="255" placeholder="e.g. 37 mythics, 118 outfits">';
      if (outfitsField) outfitsField.after(summaryField);
      else formGrid.appendChild(summaryField);
    }
    modal.querySelector('[name="rating"]')?.closest('label')?.remove();
    modal.querySelector('[name="reviews"]')?.closest('label')?.remove();
    if (formGrid && !modal.querySelector('[name="game_email"]')) {
      const credentialFields = document.createElement('div');
      credentialFields.className = 'guns-group credential-fields';
      credentialFields.innerHTML = '<h3>Game account credentials (optional)</h3><div class="guns-fields"><label>Game account email<input name="game_email" type="email" autocomplete="off" placeholder="Login email for this FF ID"></label><label>Game account password<input name="game_password" type="password" autocomplete="new-password" placeholder="Password for this FF ID"></label></div>';
      formGrid.appendChild(credentialFields);
    }
    const categoryField = modal.querySelector('[name="category"]')?.closest('label');
    const originalTagField = modal.querySelector('[name="tag"]')?.closest('label');
    const evoGunsField = modal.querySelector('[name="evoGuns"]')?.closest('label');
    const descriptionField = modal.querySelector('[name="description"]')?.closest('label');
    const categorySelect = modal.querySelector('[name="category"]');
    if (originalTagField) originalTagField.remove();
    const weaponTagPlaceholders = {
      all: 'e.g. All 367 weapons',
      artifact: 'e.g. 7 artifact evo guns 3 max',
      legendary: 'e.g. Legendary 34 weapons',
      epic: 'e.g. Epic 34 weapons',
      rare: 'e.g. Rare 34 weapons',
      uncommon: 'e.g. Uncommon 34 weapons'
    };
    const weaponCategories = Object.keys(weaponTagPlaceholders);
    const categoryTagMap = {};
    const syncWeaponTagFields = () => {
      if (!categorySelect) return;
      const selectedCategory = categorySelect.value || 'all';
      Object.entries(categoryTagMap).forEach(([category, field]) => {
        field.style.display = category === selectedCategory ? 'block' : 'none';
      });
    };
    if (formGrid && categoryField && descriptionField && evoGunsField) {
      const gunsGroup = document.createElement('div');
      gunsGroup.className = 'guns-group';
      gunsGroup.innerHTML = '<h3>Weapons</h3><div class="guns-fields"></div>';
      const gunsFields = gunsGroup.querySelector('.guns-fields');
      formGrid.insertBefore(gunsGroup, categoryField);

      gunsFields.appendChild(categoryField);

      weaponCategories.forEach((category) => {
        const label = document.createElement('label');
        label.className = 'weapon-tag-field';
        label.style.display = category === 'all' ? 'block' : 'none';
        const input = document.createElement('input');
        input.name = `tag_${category}`;
        input.type = 'text';
        input.placeholder = weaponTagPlaceholders[category];
        const text = document.createElement('span');
        text.textContent = 'Weapon type tag';
        label.appendChild(text);
        label.appendChild(input);
        gunsFields.appendChild(label);
        categoryTagMap[category] = label;
      });

      gunsFields.appendChild(evoGunsField);
      const maxEvoGunsField = document.createElement('label');
      maxEvoGunsField.innerHTML = 'Max EVO guns<input name="maxEvoGuns" type="text" maxlength="255" placeholder="e.g. 3 max">';
      gunsFields.appendChild(maxEvoGunsField);
      gunsFields.appendChild(descriptionField);
      descriptionField.classList.add('full-width');
      syncWeaponTagFields();
    }
    if (categorySelect) {
      categorySelect.addEventListener('change', syncWeaponTagFields);
      syncWeaponTagFields();
    }
    const tierSelect = modal.querySelector('[name="tier"]');
    if (tierSelect && !Array.from(tierSelect.options).some(option => option.textContent === 'Master')) {
      const masterOption = document.createElement('option');
      masterOption.value = 'Master';
      masterOption.textContent = 'Master';
      tierSelect.insertBefore(masterOption, tierSelect.querySelector('option:last-child'));
    }
    const gameVersionSelect = modal.querySelector('[name="gameVersion"]');
    if (gameVersionSelect) {
      gameVersionSelect.closest('label').firstChild.textContent = 'Prime';
      gameVersionSelect.querySelector('option:last-child')?.remove();
      ['Prime 7', 'Prime 8'].forEach(version => {
        if (Array.from(gameVersionSelect.options).some(option => option.textContent === version)) return;
        const option = document.createElement('option');
        option.value = version;
        option.textContent = version;
        gameVersionSelect.appendChild(option);
      });
    }
    const serverSelect = modal.querySelector('[name="server"]');
    if (serverSelect && !Array.from(serverSelect.options).some(option => option.textContent === 'Middle East')) {
      const middleEastOption = document.createElement('option');
      middleEastOption.value = 'Middle East';
      middleEastOption.textContent = 'Middle East';
      serverSelect.appendChild(middleEastOption);
    }
    const closeModal = () => { modal.hidden = true; document.body.classList.remove('modal-open'); };
    document.getElementById('open-add-account').addEventListener('click', () => { modal.hidden = false; document.body.classList.add('modal-open'); });
    modal.querySelector('.modal-close').addEventListener('click', closeModal); modal.querySelector('.cancel-button').addEventListener('click', closeModal); modal.addEventListener('click', event => { if (event.target === modal) closeModal(); });
    const imageInput = document.getElementById('listing-image');
    const imagePreview = document.getElementById('image-preview');
    const imageUploadName = document.getElementById('image-upload-name');
    const selectedImageFiles = [];
    imageInput.multiple = true;
    imageInput.max = 50;
    imageInput.name = 'images[]';
    imageInput.accept = 'image/png,image/jpeg,image/webp';
    imageUploadName.textContent = 'PNG, JPG or WEBP · tap again to add more';
    imageInput.addEventListener('change', () => {
      const newlySelected = [...imageInput.files];
      if (!newlySelected.length) return;
      const combinedFiles = [...selectedImageFiles, ...newlySelected];
      const totalBytes = combinedFiles.reduce((total, file) => total + file.size, 0);
      if (combinedFiles.length > 50 || totalBytes > 100 * 1024 * 1024 || combinedFiles.some(file => file.size > 20 * 1024 * 1024)) {
        imageUploadName.textContent = 'Maximum 50 images · 20 MB each · 100 MB total';
        imageInput.value = '';
        return;
      }
      selectedImageFiles.splice(0, selectedImageFiles.length, ...combinedFiles);
      imageInput.required = false;
      imageInput.value = '';
      imageUploadName.textContent = `${selectedImageFiles.length} image${selectedImageFiles.length === 1 ? '' : 's'} selected · tap to add more`;
      for (const previewImage of imagePreview.querySelectorAll('img')) URL.revokeObjectURL(previewImage.src);
      imagePreview.replaceChildren(...selectedImageFiles.map(file => { const image = document.createElement('img'); image.src = URL.createObjectURL(file); image.alt = file.name; return image; }));
      imagePreview.hidden = false;
    });
    document.getElementById('account-form').addEventListener('submit', async event => {
      event.preventDefault();
      if (!selectedImageFiles.length) {
        window.alert('Select at least one listing image.');
        return;
      }
      const form = event.currentTarget;
      const formData = new FormData(form);
      formData.delete('images[]');
      const data = Object.fromEntries([...formData.entries()].filter(([, value]) => !(value instanceof File)));
      const selectedCategory = data.category || 'all';
      const selectedTagInput = form.querySelector(`input[name="tag_${selectedCategory}"]`);
      data.tag = selectedTagInput?.value || data.tag || 'All 367 weapons';
      data.product_id = data.product_id || `FF${String((accounts.reduce((max, account) => {
        const candidate = String(account.product_id || '').match(/^FF(\d+)$/i)?.[1];
        return Math.max(max, candidate ? Number(candidate) : 0);
      }, 0) + 1)).padStart(2, '0')}`;
      data.category = selectedCategory === 'all' ? 'mythic' : selectedCategory;
      data.price = Number(data.price || 0);
      data.level = Number(data.level || 0);
      data.characters = Number(data.characters || 0);
      data.evoGuns = Number(data.evoGuns || 0);
      data.seller = <?= json_encode($listingPosterName, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>;
      data.featured = false;
      Object.entries(data).forEach(([key, value]) => formData.set(key, String(value)));
      for (const file of selectedImageFiles) formData.append('images[]', file);

      try {
        const response = await fetch('../api/accounts.php', {
          method: 'POST',
          body: formData
        });
        const result = await response.json();
        if (!response.ok || !result.ok) throw new Error(result.message || 'Unable to publish listing.');
        form.reset();
        closeModal();
        alert('Listing published to the store successfully.');
        window.location.reload();
      } catch (error) {
        alert(error.message || 'Could not publish the listing.');
      }
    });
  </script>
</body>
</html>
