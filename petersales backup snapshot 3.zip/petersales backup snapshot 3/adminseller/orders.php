<?php
$requiredArea = 'adminseller';
require_once __DIR__ . '/../auth.php';
$pageTitle = 'Orders | Peter Shop Admin';
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@500;600;700&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="admin.css?v=<?= filemtime(__DIR__ . '/admin.css') ?>">
  <style>
    .orders-page-content { padding-top: 30px; }
    .orders-page-panel { margin: 0; }
    .orders-page-panel .table-wrap { overflow-x: auto; }
    .orders-page-panel td small { display: block; margin-top: 4px; color: var(--muted); font-size: 10px; font-weight: 400; }
    .order-method { color: var(--ink); font-weight: 700; }
    .order-method small { display: block; margin-top: 4px; color: var(--muted); font-size: 10px; font-weight: 400; }
    .order-method.crypto-method { color: #c3adff; }
    .order-date { white-space: nowrap; }
    .receipt-link { color: var(--blue); font-size: 11px; font-weight: 700; }
    .pending-status { border-color: rgba(255,171,101,.3); background: rgba(255,171,101,.1); color: #ffc38e; }
    .order-status-select { min-width: 100px; padding: 7px 8px; border: 1px solid var(--line); border-radius: 6px; background: var(--panel-light); color: var(--ink); }
    .order-actions { display: grid; gap: 6px; }
    .order-delete { padding: 6px 8px; border: 1px solid var(--line); border-radius: 5px; background: transparent; color: var(--ink); font-size: 10px; cursor: pointer; }
    .order-delete:hover { border-color: #ff6c48; color: #ff6c48; }
    .approval-backdrop { position: fixed; z-index: 30; inset: 0; display: grid; place-items: center; padding: 20px; background: rgba(0,0,0,.72); }
    .approval-backdrop[hidden] { display: none; }
    .approval-dialog { width: min(460px, 100%); padding: 24px; border: 1px solid var(--line); border-radius: 12px; background: var(--panel); }
    .approval-dialog h2 { margin: 0 0 8px; font-size: 22px; }
    .approval-dialog p { color: var(--muted); }
    .approval-dialog label { display: grid; gap: 6px; margin-top: 14px; color: var(--muted); }
    .approval-product-id { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin: 18px 0; padding: 12px; border: 1px solid var(--line); border-radius: 7px; background: var(--panel-light); }
    .approval-product-id strong { color: var(--acid); font-size: 18px; }
    .approval-product-id button { padding: 7px 9px; border: 1px solid var(--line); border-radius: 5px; background: transparent; color: var(--ink); }
    .approval-product-id a { color: var(--blue); font-size: 12px; }
    .approval-actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 20px; }
    .approval-actions button { padding: 10px 14px; border-radius: 6px; background: var(--panel-light); color: var(--ink); }
    .approval-actions .approve-submit { background: var(--acid); color: var(--bg); font-weight: 700; }
    .orders-page-panel .inventory-actions { flex-wrap: wrap; }
    @media (max-width: 700px) { .orders-page-panel .panel-heading { align-items: flex-start; flex-direction: column; }.orders-page-panel .inventory-actions { width: 100%; }.orders-page-panel .admin-search { flex: 1 1 100%; } }
  </style>
</head>
<body>
  <div class="admin-shell">
    <?php include __DIR__ . '/nav.php'; ?>
    <main class="admin-main">
      <header class="admin-topbar"><button class="mobile-menu" type="button" aria-label="Open menu">☰</button><div><p class="eyebrow">PAYMENT MANAGEMENT</p><h1>Orders</h1></div><div class="top-actions"><a class="outline-button" href="admin.php#dashboard">← Dashboard</a></div></header>
      <section class="admin-content orders-page-content">
        <section class="panel orders-page-panel"><div class="panel-heading inventory-heading"><div><p class="eyebrow">PAYMENTS</p><h2>All orders <small id="orders-count">0</small></h2><span class="panel-subtitle">Bank-transfer orders and crypto requests</span></div><div class="inventory-actions"><label class="admin-search"><span>⌕</span><input id="orders-search" type="search" placeholder="Search orders..." /></label><select id="orders-method-filter" aria-label="Filter orders by method"><option value="all">All methods</option><option value="Bank Transfer">Bank transfer</option><option value="Crypto">Crypto</option></select><select id="orders-status-filter" aria-label="Filter orders by status"><option value="all">All statuses</option><option value="pending">Pending</option><option value="confirmed">Confirmed</option><option value="rejected">Rejected</option></select></div></div><div class="table-wrap"><table><thead><tr><th>ORDER</th><th>CUSTOMER</th><th>PRODUCT</th><th>METHOD</th><th>AMOUNT</th><th>PROOF</th><th>STATUS</th><th>ACTION</th></tr></thead><tbody id="orders-rows"><tr><td colspan="8" class="table-loading">Loading orders...</td></tr></tbody></table></div><div class="table-footer"><span id="orders-summary">Loading orders</span></div></section>
      </section>
    </main>
  </div>
  <div class="approval-backdrop" id="approval-backdrop" hidden><form class="approval-dialog" id="approval-form"><h2>Approve payment</h2><p>Find the saved login details by this FF ID before approving.</p><div class="approval-product-id"><strong id="approval-product-id">FF01</strong><button type="button" id="copy-approval-product-id">Copy ID</button><a id="open-credentials-lookup" href="account-credentials.php" target="_blank" rel="noopener">Open lookup</a></div><p id="approval-message" role="status"></p><div class="approval-actions"><button type="button" id="approval-cancel">Cancel</button><button class="approve-submit" type="submit">Approve payment</button></div></form></div>
  <script>
    const ordersRows = document.getElementById('orders-rows');
    const approvalBackdrop = document.getElementById('approval-backdrop');
    const approvalForm = document.getElementById('approval-form');
    let orders = [];
    let pendingApproval = null;
    const escapeHtml = value => { const node = document.createElement('span'); node.textContent = String(value ?? ''); return node.innerHTML; };
    const renderOrders = () => {
      const term = document.getElementById('orders-search').value.trim().toLowerCase();
      const method = document.getElementById('orders-method-filter').value;
      const status = document.getElementById('orders-status-filter').value;
      const visible = orders.filter(order => (!term || `${order.order_id} ${order.customer_name} ${order.email} ${order.product} ${order.transaction_id}`.toLowerCase().includes(term)) && (method === 'all' || order.method === method) && (status === 'all' || order.status === status));
      ordersRows.innerHTML = visible.length ? visible.map(order => `<tr><td><strong>${escapeHtml(order.order_id)}</strong><small class="order-date">${new Date(order.created_at).toLocaleString()}</small></td><td>${escapeHtml(order.customer_name)}<small>${escapeHtml(order.email)}</small></td><td>${escapeHtml(order.product)}<small class="order-ff-id">${escapeHtml(order.product_id || 'Missing FF ID')} <button class="copy-order-ffid" data-product-id="${escapeHtml(order.product_id || '')}" type="button" aria-label="Copy FF ID">Copy</button></small></td><td><span class="order-method ${order.method === 'Crypto' ? 'crypto-method' : ''}">${escapeHtml(order.method)}${order.payment_detail ? `<small>${escapeHtml(order.payment_detail)}</small>` : ''}</span></td><td><strong>${order.currency === 'NGN' ? '₦' : '$'}${Number(order.amount).toFixed(2)}</strong></td><td>${order.receipt ? `<a class="receipt-link" href="${escapeHtml(order.receipt)}" target="_blank" rel="noopener">View receipt</a>` : '<small>No file</small>'}<small>${escapeHtml(order.transaction_id)}</small></td><td><span class="status-pill ${order.status === 'confirmed' ? 'active-status' : order.status === 'rejected' ? 'sold-status' : 'pending-status'}">${escapeHtml(order.status)}</span></td><td><div class="order-actions"><select class="order-status-select" data-order-id="${escapeHtml(order.order_id)}" aria-label="Update ${escapeHtml(order.order_id)} status"><option value="pending" ${order.status === 'pending' ? 'selected' : ''}>Pending</option><option value="confirmed" ${order.status === 'confirmed' ? 'selected' : ''}>Confirmed</option><option value="rejected" ${order.status === 'rejected' ? 'selected' : ''}>Rejected</option></select><button class="order-delete" data-order-id="${escapeHtml(order.order_id)}" type="button">Delete</button></div></td></tr>`).join('') : '<tr><td colspan="8" class="table-empty">No orders match these filters.</td></tr>';
      document.getElementById('orders-count').textContent = orders.length;
      document.getElementById('nav-orders-count').textContent = orders.length;
      document.getElementById('orders-summary').textContent = `Showing ${visible.length} of ${orders.length} orders`;
    };
    const loadOrders = () => fetch('../api/orders.php').then(response => response.json()).then(data => { orders = data.orders || []; renderOrders(); }).catch(() => { ordersRows.innerHTML = '<tr><td colspan="8" class="table-empty">Could not load orders.</td></tr>'; });
    loadOrders();
    window.setInterval(loadOrders, 10000);
    ['orders-search', 'orders-method-filter', 'orders-status-filter'].forEach(id => document.getElementById(id).addEventListener(id === 'orders-search' ? 'input' : 'change', renderOrders));
    const updateOrderStatus = async (orderId, status, credentials = {}) => {
      const response = await fetch('../api/orders.php', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ action: 'status', order_id: orderId, status, ...credentials }) });
      const result = await response.json();
      if (!response.ok || !result.ok) throw new Error(result.message || 'Could not update order.');
      orders = orders.map(order => order.order_id === result.order.order_id ? result.order : order);
      renderOrders();
    };
    document.getElementById('copy-approval-product-id').addEventListener('click', async () => {
      const productId = pendingApproval?.productId || '';
      await navigator.clipboard?.writeText(productId);
      document.getElementById('approval-message').textContent = `${productId} copied.`;
    });
    document.getElementById('approval-cancel').addEventListener('click', () => {
      approvalBackdrop.hidden = true;
      if (pendingApproval) pendingApproval.select.value = pendingApproval.previousStatus;
      pendingApproval = null;
      approvalForm.reset();
    });
    approvalForm.addEventListener('submit', async event => {
      event.preventDefault();
      if (!pendingApproval) return;
      const submit = approvalForm.querySelector('.approve-submit');
      submit.disabled = true;
      try {
        await updateOrderStatus(pendingApproval.orderId, 'confirmed');
        approvalBackdrop.hidden = true;
        approvalForm.reset();
        pendingApproval = null;
      } catch (error) {
        document.getElementById('approval-message').textContent = error.message;
        if (pendingApproval) pendingApproval.select.value = pendingApproval.previousStatus;
      }
      finally { submit.disabled = false; }
    });
    ordersRows.addEventListener('change', async event => {
      const select = event.target.closest('.order-status-select');
      if (!select) return;
      const order = orders.find(item => item.order_id === select.dataset.orderId);
      const previousStatus = order?.status || 'pending';
      if (select.value === 'confirmed') {
        pendingApproval = { orderId: select.dataset.orderId, select, previousStatus, productId: String(order?.product_id || '').toUpperCase() };
        const productId = String(order?.product_id || '').toUpperCase();
        const listingId = String(order?.listing_id || '');
        document.getElementById('approval-product-id').textContent = listingId ? `${productId} · Listing #${listingId}` : `${productId} · Listing ID unavailable`;
        document.getElementById('open-credentials-lookup').href = listingId ? `account-credentials.php?listing_id=${encodeURIComponent(listingId)}` : 'account-credentials.php';
        document.getElementById('approval-message').textContent = listingId ? '' : 'This order has no unique listing ID. Confirmation is blocked to protect account credentials.';
        approvalBackdrop.hidden = false;
        document.getElementById('copy-approval-product-id').focus();
        return;
      }
      select.disabled = true;
      try {
        await updateOrderStatus(select.dataset.orderId, select.value);
      } catch (error) { window.alert(error.message); select.disabled = false; select.value = previousStatus; }
    });
    ordersRows.addEventListener('click', async event => {
      const copyButton = event.target.closest('.copy-order-ffid');
      if (copyButton) {
        await navigator.clipboard?.writeText(copyButton.dataset.productId);
        copyButton.textContent = 'Copied';
        window.setTimeout(() => { if (copyButton.isConnected) copyButton.textContent = 'Copy'; }, 1200);
        return;
      }
      const button = event.target.closest('.order-delete');
      if (!button || !window.confirm(`Delete order ${button.dataset.orderId}?`)) return;
      button.disabled = true;
      try {
        const response = await fetch('../api/orders.php', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ action: 'delete', order_id: button.dataset.orderId }) });
        const result = await response.json();
        if (!response.ok || !result.ok) throw new Error(result.message || 'Could not delete order.');
        orders = orders.filter(order => order.order_id !== result.deleted);
        renderOrders();
      } catch (error) { window.alert(error.message); button.disabled = false; }
    });
  </script>
</body>
</html>
