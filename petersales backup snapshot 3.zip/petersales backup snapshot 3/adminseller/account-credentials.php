<?php
$requiredArea = 'adminseller';
require_once __DIR__ . '/../auth.php';
$pageTitle = 'Account Credentials | Peter Shop Admin';
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@500;600;700&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="admin.css?v=<?= filemtime(__DIR__ . '/admin.css') ?>">
  <style>
    .credential-content { padding-top: 30px; }
    .credential-panel { width: min(720px, 100%); }
    .credential-search { display: flex; gap: 10px; margin-top: 20px; }
    .credential-search input { flex: 1; min-width: 0; padding: 12px 14px; border: 1px solid var(--line); border-radius: 7px; background: var(--panel-light); color: var(--ink); }
    .credential-search button, .copy-button { padding: 11px 15px; border-radius: 7px; background: var(--acid); color: var(--bg); font-weight: 700; }
    .credential-result { display: grid; gap: 12px; margin-top: 22px; }
    .credential-result[hidden] { display: none; }
    .credential-editor { display: grid; gap: 12px; margin-top: 22px; }
    .credential-editor[hidden] { display: none; }
    .credential-editor label { display: grid; gap: 6px; color: var(--muted); }
    .credential-editor input { width: 100%; padding: 11px 12px; border: 1px solid var(--line); border-radius: 7px; background: var(--panel-light); color: var(--ink); }
    .credential-value { padding: 14px; border: 1px solid var(--line); border-radius: 8px; background: var(--panel-light); }
    .credential-value small { display: block; margin-bottom: 6px; color: var(--muted); }
    .credential-value strong { display: block; overflow-wrap: anywhere; font-size: 15px; }
    .credential-message { min-height: 20px; margin: 12px 0 0; color: var(--muted); }
    .credential-message.error { color: #ff9b83; }
    .credential-note { color: var(--muted); line-height: 1.55; }
  </style>
</head>
<body>
  <div class="admin-shell">
    <?php include __DIR__ . '/nav.php'; ?>
    <main class="admin-main">
      <header class="admin-topbar"><button class="mobile-menu" type="button" aria-label="Open menu">☰</button><div><p class="eyebrow">PRIVATE INVENTORY</p><h1>Account credentials</h1></div><div class="top-actions"><a class="outline-button" href="orders.php">← Orders</a></div></header>
      <section class="admin-content credential-content">
        <article class="panel credential-panel"><div class="panel-heading"><div><p class="eyebrow">PRIVATE INVENTORY</p><h2>Find a game account</h2><span class="panel-subtitle">Search by the unique listing ID to view credentials for your own listing.</span></div></div>
          <form id="credential-search" class="credential-search"><input name="listing_id" type="search" inputmode="numeric" pattern="[0-9]+" autocomplete="off" placeholder="Enter listing ID, e.g. 8" required><button type="submit">Search</button></form>
          <p id="credential-message" class="credential-message" role="status">Credentials are shown only on this admin lookup page.</p>
          <section id="credential-result" class="credential-result" hidden><div class="credential-value"><small>Listing ID</small><strong id="credential-listing-id"></strong></div><div class="credential-value"><small>Product ID</small><strong id="credential-product-id"></strong></div><div class="credential-value"><small>Game account email</small><strong id="credential-email"></strong></div><div class="credential-value"><small>Game account password</small><strong id="credential-password"></strong></div><button class="copy-button" id="copy-credentials" type="button">Copy credentials</button></section>
          <form id="credential-editor" class="credential-editor" hidden><label>Game account email<input name="game_email" type="email" required autocomplete="off"></label><label>Game account password<input name="game_password" type="password" required autocomplete="new-password"></label><button class="copy-button" type="submit">Save credentials to this listing</button></form>
        </article>
      </section>
    </main>
  </div>
  <script>
    const form = document.getElementById('credential-search');
    const message = document.getElementById('credential-message');
    const resultPanel = document.getElementById('credential-result');
    const credentialEditor = document.getElementById('credential-editor');
    let currentCredentials = null;
    form.addEventListener('submit', async event => {
      event.preventDefault();
      const listingId = String(new FormData(form).get('listing_id') || '').trim();
      message.classList.remove('error');
      message.textContent = 'Searching inventory...';
      resultPanel.hidden = true;
      credentialEditor.hidden = true;
      try {
        const response = await fetch(`../api/account-credentials.php?listing_id=${encodeURIComponent(listingId)}`, { cache: 'no-store', credentials: 'same-origin' });
        const data = await response.json();
        if (!response.ok || !data.ok) throw new Error(data.message || 'Could not find credentials.');
        currentCredentials = data;
        document.getElementById('credential-listing-id').textContent = data.listing_id;
        document.getElementById('credential-product-id').textContent = data.product_id;
        document.getElementById('credential-email').textContent = data.email;
        document.getElementById('credential-password').textContent = data.password;
        resultPanel.hidden = false;
        message.textContent = 'Credentials found.';
      } catch (error) {
        currentCredentials = null;
        message.classList.add('error');
        message.textContent = error.message || 'Could not find credentials.';
        if (message.textContent.includes('Credentials have not been saved')) credentialEditor.hidden = false;
      }
    });
    credentialEditor.addEventListener('submit', async event => {
      event.preventDefault();
      const listingId = String(form.elements.listing_id.value || '').trim();
      const formData = new FormData(credentialEditor);
      try {
        const response = await fetch(`../api/account-credentials.php?listing_id=${encodeURIComponent(listingId)}`, { method: 'POST', body: new URLSearchParams(formData), credentials: 'same-origin' });
        const data = await response.json();
        if (!response.ok || !data.ok) throw new Error(data.message || 'Could not save credentials.');
        message.classList.remove('error');
        message.textContent = 'Credentials saved. Reloading this listing...';
        form.requestSubmit();
      } catch (error) {
        message.classList.add('error');
        message.textContent = error.message || 'Could not save credentials.';
      }
    });
    const requestedListingId = new URLSearchParams(window.location.search).get('listing_id');
    if (requestedListingId) {
      form.elements.listing_id.value = requestedListingId;
      form.requestSubmit();
    }
    document.getElementById('copy-credentials').addEventListener('click', async () => {
      if (!currentCredentials) return;
      await navigator.clipboard?.writeText(`Listing ID: ${currentCredentials.listing_id}\nProduct ID: ${currentCredentials.product_id}\nEmail: ${currentCredentials.email}\nPassword: ${currentCredentials.password}`);
      message.classList.remove('error');
      message.textContent = 'Credentials copied.';
    });
  </script>
</body>
</html>
