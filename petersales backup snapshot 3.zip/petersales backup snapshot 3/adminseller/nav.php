<?php
$adminPage = basename($_SERVER['PHP_SELF']);
$isDashboard = $adminPage === 'admin.php';
$isOrders = $adminPage === 'orders.php';
$isCredentials = $adminPage === 'account-credentials.php';
$isSettings = $adminPage === 'settings.php';
$isPaymentSettings = $adminPage === 'payment-settings.php';
$navUserName = trim((string) ($_SESSION['auth_user']['name'] ?? 'Seller'));
$navUserRole = trim((string) ($_SESSION['auth_user']['role'] ?? 'Seller'));
$navUserInitial = strtoupper(substr($navUserName, 0, 1));
?>
<style>
  body { overflow-x: hidden; }
  .admin-sidebar { position: sticky; top: 0; height: 100vh; min-height: 0; overflow-y: auto; }
  .admin-topbar { position: sticky; top: 0; z-index: 20; }
  .pending-orders-count { color: #ff6c48 !important; }
  .admin-user { position: relative; }
  .admin-user button { min-width: 28px; min-height: 28px; padding: 0; }
  .admin-signout { display: none; position: absolute; right: 0; bottom: calc(100% + 8px); align-items: center; gap: 7px; padding: 8px 10px; border: 1px solid var(--line); border-radius: 7px; background: var(--panel-light); color: var(--ink); font-size: 11px; white-space: nowrap; }
  .admin-signout.visible { display: inline-flex; }
  .admin-sidebar-close { display: none; }
  @media (max-width: 780px) { .admin-sidebar-close { display: grid; width: 32px; height: 32px; place-items: center; margin: 0 0 14px auto; border: 1px solid var(--line); border-radius: 7px; background: var(--panel-light); color: var(--ink); font-size: 20px; line-height: 1; } }
  @media (max-width: 780px) { .admin-sidebar { position: fixed; height: auto; min-height: 100vh; } }
</style>
<aside class="admin-sidebar">
  <button class="admin-sidebar-close" type="button" aria-label="Close navigation">×</button>
  <a class="admin-brand" href="../index.php" aria-label="Peter Shop home"><span class="brand-mark">P</span><span>PETER <b>SHOP</b></span></a>
  <div class="admin-workspace"><span class="workspace-dot"></span><span><small>WORKSPACE</small><strong id="workspace-name">Shop</strong></span></div>
  <nav class="admin-nav" aria-label="Admin navigation">
    <p class="nav-label">OVERVIEW</p>
    <a class="<?= $isDashboard ? 'active' : '' ?>" href="admin.php#dashboard"><span>▦</span>Dashboard</a>
    <a href="admin.php#inventory"><span>▤</span>Inventory<b id="nav-inventory-count">0</b></a>
    <a class="<?= $isOrders ? 'active' : '' ?>" href="orders.php"><span>◇</span>Orders<b id="nav-orders-count">0</b></a>
    <p class="nav-label">MANAGE</p>
    <a class="<?= $isCredentials ? 'active' : '' ?>" href="account-credentials.php"><span>▣</span>Account credentials</a>
    <a class="<?= $isPaymentSettings ? 'active' : '' ?>" href="payment-settings.php"><span>₿</span>Payment details</a>
  </nav>
  <div class="sidebar-bottom"><a class="<?= $isSettings ? 'active' : '' ?>" href="settings.php"><span>⚙</span>Settings</a><a href="../index.php"><span>↗</span>View storefront</a><div class="admin-user"><span class="user-avatar" id="nav-user-avatar"><?= htmlspecialchars($navUserInitial, ENT_QUOTES, 'UTF-8') ?></span><span><strong id="nav-user-name"><?= htmlspecialchars($navUserName, ENT_QUOTES, 'UTF-8') ?></strong><small id="nav-user-role"><?= htmlspecialchars($navUserRole, ENT_QUOTES, 'UTF-8') ?></small></span><button type="button" id="nav-user-menu" aria-label="User menu" aria-expanded="false">•••</button><button class="admin-signout" id="nav-signout" type="button"><span>↪</span>Sign out</button></div></div>
</aside>
<script>
  fetch('../api/admin-settings.php', { cache: 'no-store' }).then(response => response.json()).then(result => {
    if (!result.ok || !result.settings) return;
    const settings = result.settings;
    const firstName = settings.name.trim().split(/\s+/)[0] || 'Account';
    document.getElementById('workspace-name').textContent = `${firstName} Shop`;
    document.getElementById('nav-user-name').textContent = settings.name;
    document.getElementById('nav-user-role').textContent = settings.role;
    document.getElementById('nav-user-avatar').textContent = settings.name.trim().charAt(0).toUpperCase();
  }).catch(() => {});
  fetch('../api/orders.php', { cache: 'no-store' }).then(response => response.json()).then(data => {
    const count = (data.orders || []).filter(order => order.status === 'pending').length;
    document.querySelectorAll('#nav-orders-count').forEach(element => {
      element.textContent = count;
      element.classList.toggle('pending-orders-count', count > 0);
    });
  }).catch(() => {});
  window.setInterval(() => fetch('../api/orders.php', { cache: 'no-store' }).then(response => response.json()).then(data => {
    const count = (data.orders || []).filter(order => order.status === 'pending').length;
    document.querySelectorAll('#nav-orders-count').forEach(element => {
      element.textContent = count;
      element.classList.toggle('pending-orders-count', count > 0);
    });
  }).catch(() => {}), 5000);
  document.addEventListener('click', event => {
    const menuButton = event.target.closest('.mobile-menu');
    const closeButton = event.target.closest('.admin-sidebar-close');
    const userMenu = event.target.closest('#nav-user-menu');
    const signout = event.target.closest('#nav-signout');
    const sidebar = document.querySelector('.admin-sidebar');
    const signoutButton = document.getElementById('nav-signout');
    if (signout) {
      fetch('../api/auth.php', { method: 'POST', body: new URLSearchParams({ action: 'logout' }) }).finally(() => {
        sessionStorage.clear();
        localStorage.removeItem('peter-shop-admin-session');
        window.location.href = '../index.php';
      });
      return;
    }
    if (userMenu && signoutButton) {
      const visible = signoutButton.classList.toggle('visible');
      userMenu.setAttribute('aria-expanded', visible ? 'true' : 'false');
      return;
    }
    if (signoutButton?.classList.contains('visible') && !event.target.closest('.admin-user')) {
      signoutButton.classList.remove('visible');
      document.getElementById('nav-user-menu')?.setAttribute('aria-expanded', 'false');
    }
    if (closeButton && sidebar) {
      sidebar.classList.remove('open');
      document.querySelector('.mobile-menu')?.setAttribute('aria-expanded', 'false');
      return;
    }
    if (menuButton && sidebar) {
      sidebar.classList.toggle('open');
      menuButton.setAttribute('aria-expanded', sidebar.classList.contains('open') ? 'true' : 'false');
      return;
    }
    if (sidebar?.classList.contains('open') && event.target.closest('.admin-nav a, .sidebar-bottom a')) {
      sidebar.classList.remove('open');
    }
  });
</script>
<?php if ($isDashboard): ?>
<script src="../dashboard-insights.js?v=2" defer></script>
<script src="../dashboard-fx-rate.js?v=2" defer></script>
<script src="../dashboard-greeting.js?v=2" defer></script>
<?php endif; ?>
