<?php
$requiredArea = 'adminseller';
require_once __DIR__ . '/../auth.php';
require __DIR__ . '/../admin/payment-settings.php';
