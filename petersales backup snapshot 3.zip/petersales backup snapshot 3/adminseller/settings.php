<?php
$requiredArea = 'adminseller';
require_once __DIR__ . '/../auth.php';
$pageTitle = 'Settings | Peter Shop Admin';
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="stylesheet" href="admin.css?v=<?= filemtime(__DIR__ . '/admin.css') ?>">
  <style>
    .settings-content { padding-top: 30px; }
    .settings-layout { display: grid; grid-template-columns: minmax(0, 1fr) minmax(280px, 360px); gap: 20px; max-width: 980px; }
    .settings-panel { padding: 24px; }
    .settings-panel h2 { margin: 0 0 6px; }
    .settings-copy { margin: 0; color: var(--muted); line-height: 1.55; }
    .profile-head { display: flex; align-items: center; gap: 14px; margin: 24px 0; padding-bottom: 20px; border-bottom: 1px solid var(--line); }
    .profile-avatar { display: grid; width: 58px; height: 58px; place-items: center; border-radius: 50%; background: var(--acid); color: var(--bg); font: 700 28px 'Barlow Condensed', sans-serif; }
    .profile-head strong { display: block; font-size: 16px; }
    .profile-head span { display: block; margin-top: 3px; color: var(--muted); font-size: 12px; }
    .settings-form { display: grid; gap: 16px; }
    .settings-form label { display: grid; gap: 7px; color: var(--muted); font-size: 12px; font-weight: 600; }
    .settings-form input, .settings-form select { width: 100%; min-height: 42px; padding: 10px 12px; border: 1px solid var(--line); border-radius: 7px; background: var(--panel-light); color: var(--ink); }
    .settings-form input:focus, .settings-form select:focus { outline: 2px solid rgba(216,255,62,.2); border-color: var(--acid); }
    .settings-fields { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
    .settings-actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 6px; padding-top: 18px; border-top: 1px solid var(--line); }
    .settings-actions button { padding: 11px 15px; border-radius: 7px; background: var(--acid); color: var(--bg); font-weight: 700; }
    .settings-actions button[type="reset"] { background: var(--panel-light); color: var(--ink); }
    .settings-side { display: grid; align-content: start; gap: 14px; }
    .settings-side .panel { padding: 20px; }
    .settings-side h3 { margin: 0 0 8px; font-size: 14px; }
    .settings-side p { margin: 0; color: var(--muted); line-height: 1.55; }
    .password-form { display: grid; gap: 12px; margin-top: 16px; }
    .password-form label { display: grid; gap: 7px; color: var(--muted); font-size: 12px; font-weight: 600; }
    .password-form input { width: 100%; min-height: 40px; padding: 9px 11px; border: 1px solid var(--line); border-radius: 7px; background: var(--panel-light); color: var(--ink); }
    .password-form button { justify-self: start; padding: 10px 13px; border-radius: 7px; background: var(--acid); color: var(--bg); font-weight: 700; }
    .settings-status { min-height: 18px; margin: 0; color: var(--acid); font-size: 12px; font-weight: 600; }
    @media (max-width: 850px) { .settings-layout { grid-template-columns: 1fr; } }
    @media (max-width: 560px) { .settings-fields { grid-template-columns: 1fr; } .settings-panel { padding: 18px; } }
  </style>
</head>
<body>
  <div class="admin-shell">
    <?php include __DIR__ . '/nav.php'; ?>
    <main class="admin-main">
      <header class="admin-topbar"><button class="mobile-menu" type="button" aria-label="Open menu">☰</button><div><p class="eyebrow">WORKSPACE SETTINGS</p><h1>Profile settings</h1></div><div class="top-actions"><a class="outline-button" href="admin.php#dashboard">← Dashboard</a></div></header>
      <section class="admin-content settings-content">
        <div class="settings-layout">
          <section class="panel settings-panel">
            <p class="eyebrow">YOUR PROFILE</p>
            <h2>Personal information</h2>
            <p class="settings-copy">Manage the profile details used across your Peter Shop workspace.</p>
            <div class="profile-head"><span class="profile-avatar" id="profile-avatar">P</span><div><strong id="profile-name">Peter Admin</strong><span id="profile-role">Administrator</span></div></div>
            <form class="settings-form" id="profile-settings-form">
              <div class="settings-fields"><label>Full name<input name="name" required></label><label>Role<input name="role" value="Administrator" disabled></label></div>
              <label>Email address<input name="email" type="email" required></label>
              <div class="settings-fields"><label>Timezone<select name="timezone"><option>Africa/Lagos (WAT)</option><option>Europe/London (GMT)</option><option>America/New_York (EST)</option></select></label><label>Language<select name="language"><option>English</option></select></label></div>
              <p class="settings-status" id="settings-status" role="status"></p>
              <div class="settings-actions"><button type="reset">Cancel</button><button type="submit">Save changes</button></div>
            </form>
          </section>
          <aside class="settings-side">
            <section class="panel"><h3>Change password</h3><p>Update your seller password regularly to keep this workspace secure.</p><form class="password-form" id="password-form"><label>Current password<input name="current_password" type="password" required autocomplete="current-password"></label><label>New password<input name="new_password" type="password" minlength="8" required autocomplete="new-password"></label><label>Confirm new password<input name="confirm_password" type="password" minlength="8" required autocomplete="new-password"></label><p class="settings-status" id="password-status" role="status"></p><button type="submit">Update password</button></form></section>
            <section class="panel"><h3>Workspace</h3><p>Seller workspace<br>Personal access only</p></section>
          </aside>
        </div>
      </section>
    </main>
  </div>
  <script>
    const profileForm = document.getElementById('profile-settings-form');
    const passwordForm = document.getElementById('password-form');
    const statusMessage = document.getElementById('settings-status');
    const passwordStatus = document.getElementById('password-status');
    const loadSettings = async () => {
      const response = await fetch('../api/admin-settings.php', { cache: 'no-store' });
      const result = await response.json();
      if (!response.ok || !result.ok) throw new Error(result.message || 'Could not load settings.');
      const settings = result.settings;
      profileForm.elements.name.value = settings.name;
      profileForm.elements.email.value = settings.email;
      profileForm.elements.timezone.value = settings.timezone;
      profileForm.elements.language.value = settings.language;
      document.getElementById('profile-name').textContent = settings.name;
      document.getElementById('profile-role').textContent = settings.role;
      profileForm.elements.role.value = settings.role;
      document.getElementById('profile-avatar').textContent = settings.name.trim().charAt(0).toUpperCase();
    };
    loadSettings().catch(error => { statusMessage.textContent = error.message; });
    profileForm.addEventListener('submit', async event => {
      event.preventDefault();
      statusMessage.textContent = 'Saving profile...';
      try {
        const response = await fetch('../api/admin-settings.php', { method: 'POST', body: new URLSearchParams({ action: 'profile', name: profileForm.elements.name.value.trim(), email: profileForm.elements.email.value.trim(), timezone: profileForm.elements.timezone.value, language: profileForm.elements.language.value }) });
        const result = await response.json();
        if (!response.ok || !result.ok) throw new Error(result.message || 'Could not save profile.');
        document.getElementById('profile-name').textContent = result.settings.name;
        document.getElementById('profile-avatar').textContent = result.settings.name.trim().charAt(0).toUpperCase();
        statusMessage.textContent = 'Profile changes saved.';
      } catch (error) { statusMessage.textContent = error.message || 'Could not save profile.'; }
    });
    profileForm.addEventListener('reset', () => { statusMessage.textContent = ''; });
    passwordForm.addEventListener('submit', async event => {
      event.preventDefault();
      passwordStatus.textContent = 'Updating password...';
      try {
        const response = await fetch('../api/admin-settings.php', { method: 'POST', body: new URLSearchParams({ action: 'password', current_password: passwordForm.elements.current_password.value, new_password: passwordForm.elements.new_password.value, confirm_password: passwordForm.elements.confirm_password.value }) });
        const result = await response.json();
        if (!response.ok || !result.ok) throw new Error(result.message || 'Could not update password.');
        passwordForm.reset();
        passwordStatus.textContent = 'Password updated.';
      } catch (error) { passwordStatus.textContent = error.message || 'Could not update password.'; }
    });
  </script>
</body>
</html>
