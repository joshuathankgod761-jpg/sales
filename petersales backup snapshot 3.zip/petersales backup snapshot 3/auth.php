<?php
session_start();
$requiredArea = $requiredArea ?? null;
$requestPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$projectRoot = preg_replace('#/(admin|adminseller|api)(/.*)?$#', '', $requestPath);
if ($projectRoot === '' || $projectRoot === '/') {
    $loginPath = '/login.php';
} else {
    $loginPath = $projectRoot . '/login.php';
}
if (empty($_SESSION['auth_user']) || ($requiredArea !== null && ($_SESSION['auth_user']['area'] ?? '') !== $requiredArea)) {
    header('Location: ' . $loginPath . '?return=' . rawurlencode($requestPath));
    exit;
}
