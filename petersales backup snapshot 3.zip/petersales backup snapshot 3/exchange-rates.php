<?php
require_once __DIR__ . '/auth.php';
$dashboardUrl = ($_SESSION['auth_user']['area'] ?? '') === 'adminseller' ? 'adminseller/admin.php' : 'admin/admin.php';
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Live exchange rates | Peter Shop</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@500;600;700&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root { color-scheme: dark; --bg:#0d1112; --panel:#151b1d; --panel-soft:#192124; --line:rgba(255,255,255,.09); --ink:#eef2ef; --muted:#91a0a1; --lime:#d8ff3e; --blue:#83d5e8; }
    * { box-sizing:border-box; }
    body { min-height:100vh; margin:0; background:var(--bg); color:var(--ink); font-family:'DM Sans',sans-serif; }
    button,input,select { font:inherit; }
    .rates-shell { width:min(1180px,100%); margin:0 auto; padding:30px 28px 56px; }
    .rates-topbar { display:flex; align-items:center; justify-content:space-between; gap:20px; padding-bottom:22px; border-bottom:1px solid var(--line); }
    .rates-brand { display:flex; align-items:center; gap:10px; font:700 19px 'Barlow Condensed',sans-serif; letter-spacing:.04em; }
    .brand-mark { display:grid; width:30px; height:30px; place-items:center; background:var(--lime); color:#101310; }
    .back-link { color:var(--muted); font-size:13px; font-weight:600; text-decoration:none; }
    .back-link:hover { color:var(--lime); }
    .rates-heading { display:flex; justify-content:space-between; align-items:end; gap:20px; margin:32px 0 24px; }
    .eyebrow { margin:0 0 7px; color:var(--blue); font-size:10px; font-weight:700; letter-spacing:.16em; }
    h1 { margin:0; font:600 38px 'Barlow Condensed',sans-serif; }
    .rates-heading p:last-child { margin:8px 0 0; color:var(--muted); font-size:13px; }
    .rates-actions { display:flex; align-items:center; gap:9px; }
    .refresh-button { display:flex; align-items:center; gap:9px; min-height:40px; padding:0 13px; border:1px solid var(--line); border-radius:7px; background:var(--panel); color:var(--ink); font-size:12px; font-weight:700; text-decoration:none; cursor:pointer; }
    .refresh-button:hover { border-color:var(--lime); }
    .refresh-button:disabled { opacity:.6; cursor:wait; }
    .rate-banner { display:grid; grid-template-columns:minmax(0,1.3fr) minmax(260px,.7fr); gap:32px; padding:26px 0 30px; border-top:1px solid var(--line); border-bottom:1px solid var(--line); }
    .rate-kicker { color:var(--muted); font-size:11px; font-weight:700; letter-spacing:.1em; text-transform:uppercase; }
    .headline-rate { margin-top:8px; font:600 42px 'Barlow Condensed',sans-serif; }
    .headline-rate strong { color:var(--lime); }
    .provider-update { margin-top:8px; color:var(--muted); font-size:12px; }
    .converter { display:grid; grid-template-columns:1fr auto 1fr; align-items:end; gap:10px; }
    .converter label { display:grid; gap:7px; color:var(--muted); font-size:11px; font-weight:700; }
    .converter input { width:100%; min-width:0; height:44px; padding:0 12px; border:1px solid var(--line); border-radius:6px; outline:none; background:var(--panel-soft); color:var(--ink); font-size:15px; }
    .converter input:focus { border-color:var(--lime); }
    .converter-arrow { align-self:center; padding-bottom:10px; color:var(--blue); font-size:20px; }
    .table-heading { display:flex; align-items:end; justify-content:space-between; gap:18px; margin:34px 0 14px; }
    .table-heading h2 { margin:0; font:600 23px 'Barlow Condensed',sans-serif; }
    .table-heading p { margin:4px 0 0; color:var(--muted); font-size:12px; }
    .currency-search { width:min(280px,100%); min-height:40px; padding:0 12px; border:1px solid var(--line); border-radius:6px; outline:none; background:var(--panel); color:var(--ink); font-size:12px; }
    .currency-search:focus { border-color:var(--lime); }
    .rates-table-wrap { overflow:auto; border-top:1px solid var(--line); }
    .rates-table { width:100%; border-collapse:collapse; text-align:left; }
    .rates-table th { position:sticky; top:0; z-index:1; padding:13px 14px; background:#121819; color:var(--muted); font-size:10px; font-weight:700; letter-spacing:.1em; text-transform:uppercase; }
    .rates-table td { padding:12px 14px; border-top:1px solid var(--line); font-size:12px; }
    .rates-table tr:hover td { background:rgba(255,255,255,.025); }
    .currency-name { font-weight:700; }
    .currency-code { color:var(--blue); font-weight:700; }
    .currency-value { font-variant-numeric:tabular-nums; }
    .table-state { padding:28px 14px !important; color:var(--muted); text-align:center; }
    .source-note { margin-top:15px; color:var(--muted); font-size:11px; line-height:1.5; }
    @media (max-width:700px) {
      .rates-shell { padding:18px 16px 40px; }
      .rates-heading { align-items:flex-start; flex-direction:column; }
      .rate-banner { grid-template-columns:1fr; gap:23px; }
      .headline-rate { font-size:35px; }
      .table-heading { align-items:flex-start; flex-direction:column; }
      .currency-search { width:100%; }
      .rates-table th,.rates-table td { padding:11px 9px; }
      .rates-table th:last-child,.rates-table td:last-child { text-align:right; }
    }
  </style>
</head>
<body>
  <main class="rates-shell">
    <header class="rates-topbar"><div class="rates-brand"><span class="brand-mark">P</span><span>PETER SHOP</span></div><a class="back-link" href="<?= htmlspecialchars($dashboardUrl, ENT_QUOTES, 'UTF-8') ?>">← Back to dashboard</a></header>
    <section class="rates-heading"><div><p class="eyebrow">MARKET DATA</p><h1>Live exchange rates</h1><p>Latest available rates from the USD reference market.</p></div><div class="rates-actions"><a class="refresh-button" href="forex-live.php"><span aria-hidden="true">▥</span> View live Forex data</a><button class="refresh-button" id="refresh-rates" type="button"><span aria-hidden="true">↻</span> Refresh rates</button></div></section>
    <section class="rate-banner" aria-label="USD to NGN exchange rate">
      <div><span class="rate-kicker">US dollar to Nigerian naira</span><div class="headline-rate">1 USD <strong>= ₦<span id="ngn-rate">--</span></strong></div><div class="provider-update" id="provider-update" role="status">Loading provider rate...</div></div>
      <div class="converter"><label>USD amount<input id="usd-amount" type="number" min="0" step="any" value="1" inputmode="decimal"></label><span class="converter-arrow" aria-hidden="true">→</span><label>NGN amount<input id="ngn-amount" type="text" readonly value="--"></label></div>
    </section>
    <section class="table-heading"><div><h2>All available currencies</h2><p id="currency-count">Loading rates...</p></div><input class="currency-search" id="currency-search" type="search" placeholder="Search currency or code" aria-label="Search currencies"></section>
    <div class="rates-table-wrap"><table class="rates-table"><thead><tr><th>Currency</th><th>Code</th><th>Per 1 USD</th></tr></thead><tbody id="rates-rows"><tr><td class="table-state" colspan="3">Loading latest exchange rates...</td></tr></tbody></table></div>
    <p class="source-note">Rates are indicative reference data supplied by ExchangeRate-API. Provider updates are published periodically; check the timestamp above before making a transfer.</p>
  </main>
  <script>
    const ratesRows = document.getElementById('rates-rows');
    const currencySearch = document.getElementById('currency-search');
    const currencyCount = document.getElementById('currency-count');
    const usdAmount = document.getElementById('usd-amount');
    const ngnAmount = document.getElementById('ngn-amount');
    let exchangeData = null;
    let currencyEntries = [];
    const currencyNames = new Intl.DisplayNames(['en'], { type: 'currency' });
    const formatRate = value => Number(value).toLocaleString('en-US', { maximumFractionDigits: 6 });
    const renderCurrencyRows = () => {
      if (!exchangeData) return;
      const term = currencySearch.value.trim().toLowerCase();
      const visible = currencyEntries.filter(([code, name]) => `${code} ${name}`.toLowerCase().includes(term));
      currencyCount.textContent = `${visible.length} of ${currencyEntries.length} currencies · Base: USD`;
      ratesRows.replaceChildren();
      if (!visible.length) {
        const row = document.createElement('tr');
        row.innerHTML = '<td class="table-state" colspan="3">No matching currencies.</td>';
        ratesRows.appendChild(row);
        return;
      }
      const fragment = document.createDocumentFragment();
      visible.forEach(([code, name, rate]) => {
        const row = document.createElement('tr');
        const nameCell = document.createElement('td');
        nameCell.className = 'currency-name';
        nameCell.textContent = name;
        const codeCell = document.createElement('td');
        codeCell.className = 'currency-code';
        codeCell.textContent = code;
        const rateCell = document.createElement('td');
        rateCell.className = 'currency-value';
        rateCell.textContent = formatRate(rate);
        row.append(nameCell, codeCell, rateCell);
        fragment.appendChild(row);
      });
      ratesRows.appendChild(fragment);
    };
    const updateConverter = () => {
      if (!exchangeData) return;
      const amount = Math.max(0, Number(usdAmount.value) || 0);
      ngnAmount.value = `₦${(amount * exchangeData.rates.NGN).toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    };
    const loadRates = async () => {
      const button = document.getElementById('refresh-rates');
      button.disabled = true;
      document.getElementById('provider-update').textContent = 'Fetching provider rates...';
      try {
        const response = await fetch('https://open.er-api.com/v6/latest/USD', { cache: 'no-store' });
        if (!response.ok) throw new Error('Rate provider returned an error.');
        const data = await response.json();
        if (data.result !== 'success' || !data.rates || !Number.isFinite(Number(data.rates.NGN))) throw new Error('Rate data is unavailable.');
        exchangeData = data;
        currencyEntries = Object.entries(data.rates).map(([code, rate]) => {
          let name = code;
          try { name = currencyNames.of(code) || code; } catch (error) {}
          return [code, name, Number(rate)];
        }).sort((left, right) => left[1].localeCompare(right[1]));
        document.getElementById('ngn-rate').textContent = Number(data.rates.NGN).toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        document.getElementById('provider-update').textContent = `Provider updated ${new Date(data.time_last_update_utc).toLocaleString()} · Next update ${new Date(data.time_next_update_utc).toLocaleString()}`;
        renderCurrencyRows();
        updateConverter();
      } catch (error) {
        document.getElementById('provider-update').textContent = 'Could not load live exchange rates. Check your connection and retry.';
        ratesRows.innerHTML = '<tr><td class="table-state" colspan="3">Live rate data is currently unavailable.</td></tr>';
        currencyCount.textContent = 'Rates unavailable';
      } finally {
        button.disabled = false;
      }
    };
    currencySearch.addEventListener('input', renderCurrencyRows);
    usdAmount.addEventListener('input', updateConverter);
    document.getElementById('refresh-rates').addEventListener('click', loadRates);
    loadRates();
    window.setInterval(loadRates, 15 * 60 * 1000);
  </script>
</body>
</html>