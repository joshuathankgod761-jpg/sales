<?php
$headerMode = $headerMode ?? 'market';
?>
<header class="topbar shared-header" data-header-mode="<?= htmlspecialchars($headerMode, ENT_QUOTES, 'UTF-8') ?>">
  <a class="brand" href="index.php" aria-label="Peter Shop home"><span class="brand-mark">P</span><span>PETER <span>SHOP</span></span></a>
  <div class="header-actions">
    <button id="favorites-toggle" class="icon-button" type="button" aria-label="View favorites" aria-expanded="false">&#9825;<span class="action-count" aria-live="polite">0</span></button>
    <div class="currency-picker">
      <button class="currency-trigger" type="button" aria-label="Choose currency" aria-expanded="false"><span class="currency-symbol">$</span><span class="currency-code">USD</span><span class="currency-chevron">⌃</span></button>
      <div class="currency-menu" role="menu">
        <button type="button" role="menuitem" data-currency="USD"><span>$</span><strong>USD</strong></button>
        <button type="button" role="menuitem" data-currency="NGN"><span>₦</span><strong>NGN</strong></button>
      </div>
    </div>
    <a class="seller-login-link" href="login.php" aria-label="Login as a seller" title="Login as a seller">
      <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 12a4.25 4.25 0 1 0 0-8.5A4.25 4.25 0 0 0 12 12Zm0 2c-4.05 0-7.25 2.08-7.25 4.75V21h14.5v-2.25C19.25 16.08 16.05 14 12 14Z"/></svg>
      <span class="seller-login-tooltip">Login as a seller</span>
    </a>
    <button class="menu-button" type="button" aria-label="Open navigation">&#9776;</button>
  </div>
</header>
<script>
  (() => {
    const picker = document.querySelector('.currency-picker');
    if (!picker) return;
    const trigger = picker.querySelector('.currency-trigger');
    const symbol = picker.querySelector('.currency-symbol');
    const code = picker.querySelector('.currency-code');
    const currencySymbols = { USD: '$', NGN: '₦' };
    window.peterShopExchangeRate = Number(window.peterShopExchangeRate) || 1500;
    const updateCurrency = currency => {
      const selected = currency === 'NGN' ? 'NGN' : 'USD';
      localStorage.setItem('peter-shop-currency', selected);
      window.peterShopCurrency = selected;
      symbol.textContent = currencySymbols[selected];
      code.textContent = selected;
      window.dispatchEvent(new CustomEvent('peter-shop-currency-change', { detail: selected }));
    };
    updateCurrency(localStorage.getItem('peter-shop-currency') || 'USD');
    const refreshExchangeRate = async () => {
      try {
        const response = await fetch('https://open.er-api.com/v6/latest/USD', { cache: 'no-store' });
        if (!response.ok) return;
        const data = await response.json();
        const rate = Number(data.rates?.NGN);
        if (data.result !== 'success' || !Number.isFinite(rate) || rate <= 0) return;
        window.peterShopExchangeRate = rate;
        window.dispatchEvent(new CustomEvent('peter-shop-exchange-rate-change', { detail: rate }));
      } catch (error) {}
    };
    refreshExchangeRate();
    window.setInterval(refreshExchangeRate, 15 * 60 * 1000);
    picker.querySelectorAll('[data-currency]').forEach(option => option.addEventListener('click', () => updateCurrency(option.dataset.currency)));
    picker.addEventListener('mouseenter', () => trigger.setAttribute('aria-expanded', 'true'));
    picker.addEventListener('mouseleave', () => trigger.setAttribute('aria-expanded', 'false'));
  })();
</script>
