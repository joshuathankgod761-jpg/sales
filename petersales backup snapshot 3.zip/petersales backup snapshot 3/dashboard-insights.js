(() => {
  const periodSelect = document.getElementById('sales-period');
  const activityList = document.getElementById('dashboard-activity');
  const chart = document.querySelector('.sales-panel svg');
  const salesValue = document.getElementById('total-sales');
  if (!periodSelect || !activityList || !chart || !salesValue) return;

  let listings = [];
  let orders = [];
  const currency = amount => `$${Number(amount || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  const usdAmount = order => {
    const amount = Number(order.amount || 0);
    return String(order.currency || 'USD').toUpperCase() === 'NGN' ? amount / 1500 : amount;
  };
  const dateFrom = value => {
    const date = new Date(value || '');
    return Number.isNaN(date.getTime()) ? null : date;
  };
  const startOfDay = date => new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const chartBuckets = period => {
    const today = startOfDay(new Date());
    if (period === 'year') {
      return Array.from({ length: 12 }, (_, month) => ({
        start: new Date(today.getFullYear(), month, 1),
        label: new Date(today.getFullYear(), month, 1).toLocaleDateString(undefined, { month: 'short' }),
        amount: 0
      }));
    }
    const count = Number(period) === 7 ? 7 : 30;
    return Array.from({ length: count }, (_, index) => {
      const date = new Date(today);
      date.setDate(date.getDate() - (count - index - 1));
      return { start: date, label: date.toLocaleDateString(undefined, { day: '2-digit', month: 'short' }), amount: 0 };
    });
  };
  const renderChart = () => {
    const buckets = chartBuckets(periodSelect.value);
    const confirmed = orders.filter(order => order.status === 'confirmed');
    confirmed.forEach(order => {
      const date = dateFrom(order.updated_at || order.created_at);
      if (!date) return;
      const bucketIndex = periodSelect.value === 'year'
        ? (date.getFullYear() === buckets[0].start.getFullYear() ? date.getMonth() : -1)
        : Math.floor((startOfDay(date) - buckets[0].start) / 86400000);
      if (bucketIndex >= 0 && bucketIndex < buckets.length) buckets[bucketIndex].amount += usdAmount(order);
    });

    const maximum = Math.max(0, ...buckets.map(bucket => bucket.amount));
    const magnitude = maximum > 0 ? 10 ** Math.floor(Math.log10(maximum)) : 1;
    const axisTop = maximum > 0 ? Math.ceil(maximum / magnitude) * magnitude : 1;
    const points = buckets.map((bucket, index) => ({
      x: buckets.length === 1 ? 350 : index * 700 / (buckets.length - 1),
      y: 210 - (bucket.amount / axisTop) * 190
    }));
    const linePath = points.map((point, index) => `${index ? 'L' : 'M'}${point.x.toFixed(1)} ${point.y.toFixed(1)}`).join(' ');
    const areaPath = `${linePath} L700 220 L0 220 Z`;
    chart.querySelector('.chart-line')?.setAttribute('d', linePath || 'M0 210 L700 210');
    chart.querySelector('.chart-area')?.setAttribute('d', areaPath || 'M0 210 L700 210 Z');
    chart.setAttribute('aria-label', `Confirmed sales trend for ${periodSelect.options[periodSelect.selectedIndex].text}`);

    const axisLabels = [...document.querySelectorAll('.sales-panel .chart-y span')];
    axisLabels.forEach((label, index) => {
      label.textContent = currency(axisTop * (axisLabels.length - index - 1) / (axisLabels.length - 1)).replace(/\.00$/, '');
    });
    const xLabels = [...document.querySelectorAll('.sales-panel .chart-x span')];
    const tickIndices = xLabels.map((_, index) => Math.round(index * (buckets.length - 1) / Math.max(1, xLabels.length - 1)));
    xLabels.forEach((label, index) => {
      const bucket = buckets[tickIndices[index]];
      label.textContent = periodSelect.value === 'year'
        ? bucket.label
        : (index === xLabels.length - 1 ? 'Today' : bucket.label);
    });
  };
  const timeAgo = value => {
    const date = dateFrom(value);
    if (!date) return 'Date unavailable';
    const seconds = Math.max(0, Math.floor((Date.now() - date.getTime()) / 1000));
    if (seconds < 60) return 'Just now';
    if (seconds < 3600) return `${Math.floor(seconds / 60)} min ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)} hr ago`;
    if (seconds < 604800) return `${Math.floor(seconds / 86400)} days ago`;
    return date.toLocaleDateString();
  };
  const appendActivity = (events, { product, time, message, amount, tag, color }) => {
    const row = document.createElement('div');
    const avatar = document.createElement('span');
    avatar.className = `activity-avatar ${color}`;
    avatar.textContent = 'F';
    const description = document.createElement('p');
    const title = document.createElement('strong');
    title.textContent = product;
    description.append(title, document.createTextNode(` ${message}`));
    const when = document.createElement('small');
    when.textContent = timeAgo(time);
    description.appendChild(when);
    row.append(avatar, description);
    const trailing = document.createElement(amount === null ? 'em' : 'b');
    trailing.textContent = amount === null ? tag : `+${currency(amount)}`;
    row.appendChild(trailing);
    events.push({ time: dateFrom(time)?.getTime() || 0, row });
  };
  const renderActivity = () => {
    const events = [];
    const colors = ['lime', 'purple', 'blue', 'orange'];
    listings.forEach(listing => {
      if (!listing.created_at) return;
      appendActivity(events, {
        product: listing.product_id || listing.title || 'Listing',
        time: listing.created_at,
        message: 'was added',
        amount: null,
        tag: 'New listing',
        color: colors[Number(listing.id || 0) % colors.length]
      });
    });
    orders.forEach(order => {
      const confirmed = order.status === 'confirmed';
      const rejected = order.status === 'rejected';
      const amount = confirmed ? usdAmount(order) : null;
      appendActivity(events, {
        product: order.product_id || order.product || 'Order',
        time: confirmed || rejected ? (order.updated_at || order.created_at) : order.created_at,
        message: confirmed ? 'payment confirmed' : rejected ? 'payment rejected' : 'purchase submitted',
        amount,
        tag: confirmed ? '' : rejected ? 'Rejected' : 'In review',
        color: colors[Number(String(order.order_id || '').slice(-1)) % colors.length]
      });
    });
    events.sort((left, right) => right.time - left.time);
    activityList.replaceChildren();
    if (!events.length) {
      const empty = document.createElement('div');
      empty.className = 'activity-empty';
      empty.textContent = 'No recent listing or order activity.';
      activityList.appendChild(empty);
      return;
    }
    events.slice(0, 4).forEach(event => activityList.appendChild(event.row));
  };
  const refresh = async () => {
    try {
      const [inventoryResponse, ordersResponse] = await Promise.all([
        fetch('../api/accounts.php?mine=1', { cache: 'no-store', credentials: 'same-origin' }),
        fetch('../api/orders.php', { cache: 'no-store', credentials: 'same-origin' })
      ]);
      if (!inventoryResponse.ok || !ordersResponse.ok) throw new Error('Could not load dashboard data.');
      const [inventoryData, ordersData] = await Promise.all([inventoryResponse.json(), ordersResponse.json()]);
      listings = inventoryData.accounts || [];
      orders = ordersData.orders || [];
      const lifetimeSales = orders.filter(order => order.status === 'confirmed').reduce((total, order) => total + usdAmount(order), 0);
      salesValue.textContent = currency(lifetimeSales);
      const pendingOrders = document.getElementById('orders-total');
      if (pendingOrders) pendingOrders.textContent = orders.filter(order => order.status === 'pending').length;
      renderChart();
      renderActivity();
    } catch (error) {
      activityList.textContent = 'Could not load dashboard activity.';
    }
  };

  periodSelect.addEventListener('change', renderChart);
  refresh();
  window.setInterval(refresh, 30000);
})();