(() => {
  const card = document.getElementById('fx-rate-card');
  if (!card) return;
  const rateValue = card.querySelector('.fx-rate-value');
  const updatedLabel = card.querySelector('.fx-rate-updated');

  const refreshRate = async () => {
    try {
      const response = await fetch('https://open.er-api.com/v6/latest/USD', { cache: 'no-store' });
      if (!response.ok) throw new Error('Rate provider unavailable.');
      const data = await response.json();
      const rate = Number(data.rates?.NGN);
      if (data.result !== 'success' || !Number.isFinite(rate) || rate <= 0) throw new Error('NGN rate unavailable.');
      rateValue.textContent = `₦${rate.toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
      updatedLabel.textContent = `Updated ${new Date(data.time_last_update_utc).toLocaleString()}`;
      card.dataset.exchangeRates = JSON.stringify(data);
    } catch (error) {
      if (rateValue.textContent === 'Loading...') rateValue.textContent = 'Unavailable';
      updatedLabel.textContent = 'Live rate unavailable';
    }
  };

  refreshRate();
  window.setInterval(refreshRate, 15 * 60 * 1000);
})();