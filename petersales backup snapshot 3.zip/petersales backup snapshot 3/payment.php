<?php
require_once __DIR__ . '/api/db.php';
require_once __DIR__ . '/api/payment-settings-store.php';
petershop_db_bootstrap();
$amount = htmlspecialchars($_GET['amount'] ?? '0.00', ENT_QUOTES, 'UTF-8');
$email = htmlspecialchars($_GET['email'] ?? '', ENT_QUOTES, 'UTF-8');
$product = htmlspecialchars($_GET['product'] ?? 'Free Fire account', ENT_QUOTES, 'UTF-8');
$amountUsd = (float) $amount;
$exchangeRate = (float) ($_GET['exchange_rate'] ?? 1500);
if (!is_finite($exchangeRate) || $exchangeRate <= 0) $exchangeRate = 1500;
$amountNgn = $amountUsd * $exchangeRate;
$amountNgnDisplay = number_format($amountNgn, 2, '.', ',');
$paymentId = substr(md5($email . $amount), 0, 8);
$isCrypto = ($_GET['method'] ?? 'bank') === 'crypto';
if (!$isCrypto) {
  $amountUsd *= $exchangeRate;
  $amountNgn = $amountUsd * $exchangeRate;
  $amountNgnDisplay = number_format($amountNgn, 2, '.', ',');
}
$productId = trim((string) ($_GET['product_id'] ?? ''));
$listingId = trim((string) ($_GET['listing_id'] ?? ''));
$productRowId = $listingId !== '' ? 0 : (ctype_digit($productId) ? (int) $productId : 0);
$listedAccounts = petershop_listings_array();
foreach ($listedAccounts as $listedAccount) {
  $matchesListingId = $listingId !== '' && (string) ($listedAccount['id'] ?? '') === $listingId;
  $matchesProduct = $listingId === '' && (strtoupper((string) ($listedAccount['product_id'] ?? '')) === strtoupper($productId) || (ctype_digit($productId) && (int) ($listedAccount['id'] ?? 0) === $productRowId));
  if ($matchesListingId || $matchesProduct) {
    $productId = (string) ($listedAccount['product_id'] ?? $productId);
    $productRowId = (int) ($listedAccount['id'] ?? $productRowId);
    break;
  }
}
$ownerEmail = $productRowId > 0 ? peter_payment_account_owner((string) $productRowId) : null;
$paymentSettings = $ownerEmail !== null ? peter_payment_for_owner(peter_payment_store_load(), $ownerEmail) : peter_payment_defaults();
$methodSettings = $isCrypto ? $paymentSettings['crypto'] : $paymentSettings['bank'];
$methodReady = !in_array('', $methodSettings, true);
$returnUrl = $productRowId ? 'product.php?product=' . $productRowId : 'index.php';
$orderProduct = (string) ($_GET['product'] ?? 'Free Fire account');
$orderEmail = (string) ($_GET['email'] ?? '');
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Select Payment Method | Peter Shop</title>
  <style>
    :root { font-family: Arial, sans-serif; color: #202633; background: #f2f3f5; }
    * { box-sizing: border-box; }
    body { min-height: 100vh; margin: 0; padding: 24px; display: grid; place-items: center; }
    .payment-page { width: min(1000px, 100%); min-height: 650px; position: relative; display: grid; grid-template-columns: 42% 58%; overflow: hidden; border-radius: 25px; background: #fff; box-shadow: 0 14px 45px rgba(20,29,42,.12); }
    .order-panel { padding: 53px 48px; color: #fff; background: #202a33; position: relative; overflow: hidden; }
    .order-panel:before, .order-panel:after { content: ''; position: absolute; width: 300px; height: 300px; border-radius: 50%; border: 18px solid rgba(255,255,255,.035); }
    .order-panel:before { top: -100px; right: -120px; }.order-panel:after { bottom: 80px; left: 90px; }
    .shop-logo { position: relative; z-index: 1; font-size: 26px; font-weight: 800; letter-spacing: -1px; }.shop-logo b { display: inline-grid; width: 26px; height: 26px; margin-right: 10px; place-items: center; color: #090a0b; background: #d8ff3e; }
    .amount { position: relative; z-index: 1; margin: 32px 0 280px; font-size: 52px; font-weight: 300; letter-spacing: -3px; }.amount small { margin-left: 8px; font-size: 18px; letter-spacing: 0; }
    .order-details { position: relative; z-index: 1; border-top: 1px solid rgba(255,255,255,.12); padding-top: 24px; }.order-details h3 { margin: 0 0 12px; font-size: 13px; }.order-details p { margin: 0 0 23px; color: #d9dfe4; font-size: 13px; line-height: 1.45; }
    .checkout-panel { padding: 53px 68px 38px; }.checkout-panel h1 { margin: 0 0 22px; font-size: 25px; font-weight: 500; }.locale { position: relative; float: right; display: inline-flex; align-items: center; gap: 0; padding: 0; margin: 0; color: #202633; font-size: 0; font-weight: 700; line-height: 1; }.locale-flag { width: 22px; height: 14px; display: inline-block; border-radius: 2px; overflow: hidden; background: linear-gradient(to right, #008753 0 35%, #fff 35% 65%, #008753 65% 100%); box-shadow: inset 0 0 0 1px rgba(0,0,0,.08); position: relative; margin-right: 4px; }.locale-flag::before { content: ''; position: absolute; inset: 0; background: linear-gradient(to right, transparent 0 35%, #fff 35% 65%, transparent 65% 100%); }.locale-text { display: inline-block; font-size: 13px; }.pay-tabs { display: flex; gap: 9px; margin-bottom: 18px; }.pay-tabs button { width: 100%; height: 54px; border: 1px solid #e4e5e8; border-radius: 12px; background: #f1f2f4; color: #202633; font-size: 15px; font-weight: 600; }.pay-tabs button.active { border: 2px solid #6676ff; background: #f4f5ff; }.payment-brief { padding: 18px 16px; border: 1px solid #edf0f4; border-radius: 14px; background: #f9fafd; margin-bottom: 16px; }.payment-brief strong { display: block; margin-bottom: 6px; font-size: 15px; }.payment-brief span { color: #677387; font-size: 12px; line-height: 1.5; }.bank-transfer-box { margin-top: 8px; padding: 16px; border: 1px solid #e7ebf3; border-radius: 14px; background: #fff; }.bank-transfer-box h3 { margin: 0 0 12px; font-size: 13px; color: #6d7786; text-transform: uppercase; letter-spacing: .08em; }.bank-row { display: flex; justify-content: space-between; gap: 12px; padding: 8px 0; border-bottom: 1px solid #eef1f5; font-size: 13px; }.bank-row:last-child { border-bottom: 0; }.bank-row span { color: #768092; }.bank-row strong { text-align: right; color: #232b36; }.save-card { display: flex; gap: 12px; align-items: center; margin: 12px 0; font-size: 13px; }.save-card input { width: 18px; height: 18px; }.pay-submit { width: 100%; margin-top: 35px; padding: 14px; border: 0; border-radius: 30px; background: #cbd2ff; color: #fff; font-size: 15px; }.powered { margin-top: 17px; color: #b8bac0; text-align: center; font-size: 11px; }
    .transfer-proof { display: none; margin: 0 0 16px; padding: 14px; border: 1px solid #e7ebf3; border-radius: 12px; background: #f9fafd; }.transfer-proof.visible { display: block; }.transfer-proof label { display: block; margin-bottom: 6px; color: #677387; font-size: 12px; font-weight: 600; }.transfer-proof input[type="text"] { width: 100%; min-height: 42px; margin-bottom: 12px; padding: 10px 11px; border: 1px solid #dfe4ec; border-radius: 8px; background: #fff; color: #202633; font: inherit; font-size: 13px; }.transfer-proof input:focus { outline: 2px solid rgba(102,118,255,.2); border-color: #6676ff; }.receipt-upload { display: flex !important; min-height: 64px; margin: 0 !important; padding: 12px; flex-direction: column; justify-content: center; gap: 4px; border: 1px dashed #bfc8da; border-radius: 9px; background: #fff; color: #202633 !important; cursor: pointer; transition: border-color .2s, background .2s; }.receipt-upload:hover { border-color: #6676ff; background: #f4f5ff; }.receipt-upload span { color: #34405a; font-size: 13px; font-weight: 700; }.receipt-upload small { color: #8791a1; font-size: 11px; font-weight: 400; }.transfer-proof input[type="file"] { position: absolute; width: 1px; height: 1px; opacity: 0; pointer-events: none; }
    .crypto-checkout h1 { margin-bottom: 22px; }.crypto-total { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; color: #768092; font-size: 13px; }.crypto-total strong { color: #232b36; font-size: 16px; }.crypto-label { display: block; margin: 0 0 7px; color: #677387; font-size: 13px; font-weight: 600; }.crypto-picker { position: relative; margin-bottom: 14px; }.crypto-select { display: flex; align-items: center; justify-content: space-between; width: 100%; min-height: 44px; padding: 10px 12px; border: 1px solid #dfe4ec; border-radius: 8px; background: #fff; color: #202633; font: inherit; font-size: 13px; text-align: left; }.crypto-select span { color: #667184; font-size: 16px; }.crypto-options { position: absolute; z-index: 4; top: calc(100% + 4px); right: 0; left: 0; display: grid; padding: 5px; border: 1px solid #dfe4ec; border-radius: 8px; background: #fff; box-shadow: 0 12px 24px rgba(20,29,42,.15); opacity: 0; pointer-events: none; transform: translateY(-4px); transition: opacity .15s, transform .15s; }.crypto-picker.open .crypto-options { opacity: 1; pointer-events: auto; transform: translateY(0); }.crypto-options button { padding: 10px 11px; border-radius: 6px; background: transparent; color: #202633; font-size: 13px; text-align: left; }.crypto-options button:hover { background: #6676ff; color: #fff; }.crypto-wallet { display: flex; flex-direction: column; gap: 6px; margin-bottom: 14px; padding: 13px; border: 1px solid #e7ebf3; border-radius: 10px; background: #f9fafd; }.crypto-wallet span { color: #768092; font-size: 12px; }.crypto-wallet strong { overflow-wrap: anywhere; color: #232b36; font-size: 13px; }.crypto-checkout .save-card { margin: 14px 0; }.crypto-checkout .transfer-proof { margin-top: 8px; }.crypto-checkout .pay-submit { margin-top: 24px; }
    .payment-back-link { position: absolute; z-index: 3; top: 18px; right: 28px; color: #6676ff; font-size: 12px; font-weight: 700; text-decoration: none; }.payment-back-link:hover { color: #4558e8; }
    .payment-review-backdrop { position: fixed; z-index: 50; inset: 0; display: grid; place-items: center; padding: 20px; background: rgba(8,12,17,.72); }
    .payment-review-backdrop[hidden] { display: none; }
    .payment-review-modal { width: min(440px, 100%); padding: 30px; border-radius: 16px; background: #fff; color: #202633; text-align: center; box-shadow: 0 24px 80px rgba(0,0,0,.3); }
    .payment-review-modal h2 { margin: 12px 0 8px; font-size: 23px; }
    .payment-review-modal p { margin: 0; color: #657080; line-height: 1.55; }
    .review-spinner, .review-result-icon { width: 58px; height: 58px; margin: 0 auto; border-radius: 50%; }
    .review-spinner { border: 5px solid #e9edf2; border-top-color: #6676ff; animation: payment-spin .8s linear infinite; }
    @keyframes payment-spin { to { transform: rotate(360deg); } }
    .review-result-icon { display: grid; place-items: center; background: #e6f7ec; color: #168543; font-size: 34px; font-weight: 800; }
    .review-result-icon.declined { background: #fff0ee; color: #c84232; }
    .payment-review-modal button { width: 100%; margin-top: 22px; padding: 13px; border-radius: 8px; background: #6676ff; color: #fff; font-weight: 700; }
    .payment-review-modal button[hidden] { display: none; }
    .stay-on-page { margin-top: 16px !important; color: #a05c00 !important; font-size: 12px; font-weight: 700; }
    .pay-submit:disabled { cursor: not-allowed; opacity: .55; }
    .crypto-step-head { display: flex; align-items: center; gap: 8px; margin: -22px 0 22px; color: #8b8b8b; font-size: 11px; }.crypto-step-head span { display: grid; width: 22px; height: 22px; place-items: center; border-radius: 50%; background: #eceef2; color: #858b96; }.crypto-step-head span.active { background: #ffd044; color: #fff; }.crypto-step-head strong { color: #202633; font-weight: 600; }.crypto-step-head i { width: 80px; border-top: 1px solid #dfe2e7; }.crypto-choice-layout { display: grid; grid-template-columns: 175px 1fr; gap: 20px; }.crypto-order-card { padding: 20px 15px; border: 1px solid #e7e1d5; border-radius: 14px; background: #fffdf7; text-align: center; }.crypto-mark { display: grid; width: 42px; height: 42px; margin: 0 auto 8px; place-items: center; border: 3px solid #ffd044; border-radius: 50%; background: #7042ff; color: #fff; font-size: 25px; }.crypto-order-card h2 { margin: 0 0 8px; color: #101820; font-size: 18px; text-transform: none; }.crypto-order-card p { margin: 0; color: #8b756d; font-size: 11px; line-height: 1.45; }.crypto-order-card hr { margin: 16px 10px 12px; border: 0; border-top: 1px solid #e7e1d5; }.crypto-order-card small, .crypto-order-card > strong { display: block; }.crypto-order-card small { color: #9e8b83; font-size: 10px; }.crypto-order-card > strong { margin: 6px 0; color: #111820; font-size: 18px; }.crypto-coin-panel { min-width: 0; padding: 14px; border: 1px solid #e2e0dc; border-radius: 14px; background: #fff; }.crypto-search { display: flex; align-items: center; gap: 8px; padding: 0 12px; border: 1px solid #d8d5d0; border-radius: 9px; }.crypto-search span { color: #a3a5aa; font-size: 21px; }.crypto-search input { width: 100%; padding: 12px 0; border: 0; outline: 0; color: #202633; font-size: 13px; }.crypto-coin-list { max-height: 270px; margin-top: 10px; overflow-y: auto; }.crypto-coin { display: flex; width: 100%; align-items: center; gap: 10px; padding: 10px 8px; border-radius: 8px; background: #fff; color: #202633; text-align: left; }.crypto-coin:hover, .crypto-coin.selected { background: #fff8e7; }.crypto-coin > span:nth-child(2) { display: grid; flex: 1; grid-template-columns: auto auto; column-gap: 8px; align-items: center; }.crypto-coin strong { font-size: 14px; }.crypto-coin small { color: #8b8e96; font-size: 9px; }.crypto-coin em { grid-column: 1 / -1; color: #8b8e96; font-size: 10px; font-style: normal; }.crypto-coin > b { padding: 4px 6px; border: 1px solid #f0be37; border-radius: 10px; color: #b27b00; font-size: 9px; text-transform: capitalize; }.coin-icon { display: grid; width: 32px; height: 32px; place-items: center; border-radius: 50%; background: #f7931a; color: #fff; font-size: 17px; font-weight: 700; }.coin-usdtTron, .coin-usdtEthereum { background: #20a87a; }.coin-litecoin { background: #bdbdbd; }.coin-ethereum { background: #627eea; }.coin-binance { background: #f3ba2f; color: #111; }.crypto-continue { width: 100%; margin-top: 10px; padding: 11px; border-radius: 7px; background: #7042ff; color: #fff; font-size: 13px; font-weight: 700; }.crypto-continue:disabled { opacity: .45; cursor: not-allowed; }
    .coin-usdc { background: #2775ca; }.coin-trx { background: #e5092f; }
    .crypto-rules-backdrop { position: fixed; z-index: 20; inset: 0; display: grid; place-items: center; padding: 20px; background: rgba(18,20,22,.45); }.crypto-rules-modal { width: min(560px, 100%); padding: 26px 32px 24px; border-radius: 14px; background: #fff; color: #514a43; box-shadow: 0 20px 60px rgba(0,0,0,.25); }.crypto-rules-modal h2 { margin: 0 0 18px; color: #322c28; font-size: 23px; }.crypto-rules-summary { display: grid; gap: 15px; padding: 16px; border-radius: 12px; background: #f6f4f1; }.crypto-rules-summary div { display: grid; grid-template-columns: 22px 1fr auto; align-items: center; gap: 10px; }.crypto-rules-summary span { color: #d18b00; font-size: 17px; }.crypto-rules-summary small { color: #948e87; font-size: 11px; font-weight: 700; }.crypto-rules-summary strong, .crypto-rules-summary em { color: #3e3935; font-size: 14px; font-style: normal; text-align: right; }.crypto-warning { margin: 17px 0; color: #756d66; font-size: 12px; line-height: 1.5; }.crypto-rules-modal h3 { margin: 14px 0 8px; color: #756d66; font-size: 12px; }.crypto-rules-modal ul { margin: 0 0 18px; padding-left: 20px; color: #948e87; font-size: 11px; line-height: 1.6; }.crypto-rules-modal > button { width: 100%; padding: 14px; border-radius: 9px; background: #ffd34f; color: #2f2818; font-size: 14px; font-weight: 700; }.crypto-rules-modal > button:hover { background: #ffca27; }
    .crypto-send-head { margin-bottom: 14px; }.crypto-send-head .crypto-step-head { margin: 0 0 15px; }.crypto-send-head .crypto-step-head span.complete { background: #ffd044; color: #fff; font-size: 0; }.crypto-send-head .crypto-step-head span.complete::after { content: '1'; font-size: 11px; }.crypto-send-head .crypto-step-head span.active { background: #eceef2; color: #858b96; }.crypto-send-title { display: flex; align-items: center; gap: 10px; padding: 14px; border-radius: 10px; background: #f5f3f1; }.crypto-send-title strong { flex: 1; color: #202633; font-size: 16px; }.crypto-send-title b { color: #202633; font-size: 17px; }.crypto-send-tabs { display: grid; grid-template-columns: 1fr 1fr; margin: 14px 0 18px; padding: 4px; border-radius: 9px; background: #f5f3f1; }.crypto-send-tabs button { padding: 11px; border-radius: 7px; background: transparent; color: #777; font-size: 12px; font-weight: 700; }.crypto-send-tabs button.active { background: #fff; color: #202633; box-shadow: 0 1px 4px rgba(0,0,0,.08); }.crypto-send-label { margin: 13px 0 7px; color: #d28b00; font-size: 11px; font-weight: 700; }.crypto-send-amount, .crypto-send-address { display: flex; align-items: center; gap: 10px; padding: 10px 12px; border: 1px solid #f0d47b; border-radius: 10px; background: #fffaf0; }.crypto-send-address { border-color: #e2e0dc; background: #f6f4f1; }.crypto-send-amount strong, .crypto-send-address strong { flex: 1; overflow-wrap: anywhere; color: #202633; font-size: 13px; }.crypto-send-amount strong { font-size: 22px; }.crypto-copy { padding: 10px 12px; border: 1px solid #ddd8d0; border-radius: 7px; background: #fff; color: #a66a00; font-size: 11px; font-weight: 700; }.crypto-tronlink { display: flex; align-items: center; justify-content: space-between; width: 100%; min-height: 44px; margin-top: 12px; padding: 0 12px 0 10px; border: 1px solid rgba(74, 122, 255, 0.35); border-radius: 12px; background: linear-gradient(180deg, #edf5ff 0%, #e6f0ff 100%); color: #0a4ec7; font-size: 14px; font-weight: 700; text-decoration: none; box-shadow: inset 0 1px 0 rgba(255,255,255,.8); }.crypto-tronlink::before { content: '▧'; display: grid; place-items: center; width: 22px; height: 22px; margin-right: 10px; border-radius: 8px; background: linear-gradient(180deg, #5d96ff 0%, #1d59d8 100%); color: #fff; font-size: 12px; box-shadow: inset 0 0 0 1px rgba(255,255,255,.28); }.crypto-tronlink span { display: flex; align-items: center; flex: 1; }.crypto-tronlink b { display: inline-grid; place-items: center; width: 18px; height: 18px; border-radius: 999px; background: rgba(49, 96, 219, 0.08); color: #0a4ec7; font-size: 18px; }.crypto-qr { display: grid; place-items: center; padding: 22px 0 14px; }.crypto-qr img { width: 180px; height: 180px; image-rendering: pixelated; }.crypto-send-note { padding: 12px; border: 1px solid #f0d47b; border-radius: 8px; background: #fffaf0; color: #a36c00; font-size: 11px; line-height: 1.4; }
    .crypto-step-head span.complete { background: #169447; color: #fff; }.crypto-confirm-card { padding: 14px 16px 22px; border: 1px solid #e2e0dc; border-radius: 14px; background: #fff; }.crypto-paying { display: flex; align-items: center; gap: 10px; padding: 12px 14px; border-radius: 10px; background: #f5f3f1; }.crypto-paying > span:nth-child(2) { display: grid; flex: 1; gap: 3px; }.crypto-paying small { color: #999; font-size: 10px; }.crypto-paying strong { color: #202633; font-size: 13px; }.crypto-paying button { border: 0; background: transparent; color: #d58b00; font-size: 12px; font-weight: 700; }.crypto-confirm-total { display: flex; justify-content: space-between; align-items: center; margin: 20px 0; padding: 16px; border: 1px solid #f4d47c; border-radius: 11px; background: #fffaf0; color: #5d5145; font-size: 13px; }.crypto-confirm-total strong { color: #171717; font-size: 22px; }.crypto-confirm-card label { display: grid; gap: 6px; margin-top: 12px; color: #6f6a64; font-size: 12px; }.crypto-confirm-card label b { color: #e13737; }.crypto-confirm-card input { width: 100%; min-height: 44px; padding: 10px 12px; border: 1px solid #d8d5d0; border-radius: 9px; background: #fff; color: #202633; }.crypto-name-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }.crypto-pay-now { width: 100%; margin-top: 20px; padding: 14px; border-radius: 9px; background: #ffd75d; color: #201a0d; font-size: 14px; font-weight: 700; }.crypto-pay-now:hover { background: #ffca2c; }
    .crypto-send-head .crypto-step-head span.complete { background: #169447; color: #fff; font-size: 0; }
    .crypto-send-head .crypto-step-head span.complete::after { content: '✓'; font-size: 12px; }
    .crypto-send-head .crypto-step-head span.active { background: #ffd044; color: #fff; }
    @media (max-width: 700px) { body { padding: 0; }.payment-page { min-height: 100vh; grid-template-columns: 1fr; border-radius: 0; }.order-panel { padding: 35px 28px; }.amount { margin-bottom: 70px; }.checkout-panel { padding: 35px 28px; }.pay-submit { margin-top: 70px; } }
  </style>
</head>
<body>
  <main class="payment-page">
    <?php if (!$methodReady): ?>
    <section class="checkout-panel"><h1><?php echo $isCrypto ? 'Crypto payment unavailable' : 'Bank transfer unavailable'; ?></h1><p>This listing's owner has not configured this payment method.</p><a href="<?php echo htmlspecialchars($returnUrl, ENT_QUOTES, 'UTF-8'); ?>">Return to the listing</a></section>
    <?php else: ?>
    <?php if ($isCrypto): ?>
    <a class="payment-back-link" href="<?php echo htmlspecialchars($returnUrl, ENT_QUOTES, 'UTF-8'); ?>">← Back to product</a>
    <section class="order-panel"><div class="shop-logo"><b>P</b> PETER SHOP</div><div class="amount">$<?php echo number_format($amountUsd * 1.055 * 1.2, 2); ?><small>USD</small></div><div class="order-details"><h3>Payment ID</h3><p><?php echo $paymentId; ?></p><h3>Order</h3><p><?php echo $product; ?><br><?php echo $email; ?></p><a href="index.php" style="color:#fff;font-size:12px">Privacy policy</a>&nbsp;&nbsp;<a href="index.php" style="color:#fff;font-size:12px">Cookie policy</a></div></section>
    <section class="checkout-panel crypto-checkout"><h1>Crypto Payment</h1><div class="crypto-total">Total to pay <strong>$<?php echo number_format($amountUsd * 1.055 * 1.2, 2); ?> USD</strong></div><label class="crypto-label">Select cryptocurrency</label><div class="crypto-picker"><button id="crypto-currency" class="crypto-select" type="button" aria-expanded="false">Select currency <span>⌄</span></button><div class="crypto-options"><button type="button" data-crypto="usd">USD</button><button type="button" data-crypto="bitcoin">Bitcoin</button><button type="button" data-crypto="binance">Binance</button></div></div><div id="crypto-wallet" class="crypto-wallet"><span>Wallet address</span><strong>Select a currency to show the wallet address</strong></div><label id="crypto-check" class="save-card"><input id="crypto-completed" type="checkbox"> I have made the payment</label><div id="crypto-proof" class="transfer-proof"><label for="crypto-transaction-id">Transaction ID</label><input id="crypto-transaction-id" type="text" placeholder="Enter transaction ID"><label for="crypto-receipt">Receipt image</label><label class="receipt-upload" for="crypto-receipt"><span id="crypto-receipt-label">Choose receipt image</span><small>PNG, JPG or WEBP</small></label><input id="crypto-receipt" type="file" accept="image/*"></div><button class="pay-submit" type="button">Submit payment proof →</button><div class="powered">Powered by secure payment processing</div></section>
    <script>
      const cryptoCheckout = document.querySelector('.crypto-checkout');
      const cryptoWallets = { usdtTron: 'TRC20-PETER-SHOP-WALLET', usdtEthereum: 'ERC20-PETER-SHOP-WALLET', bitcoin: 'bc1q-peter-shop-bitcoin-wallet', litecoin: 'ltc1-peter-shop-litecoin-wallet', ethereum: '0x-peter-shop-ethereum-wallet', usdc: '0x-peter-shop-usdc-wallet', trx: 'T-PETER-SHOP-TRON-WALLET', binance: '0x-peter-shop-binance-wallet' };
      const cryptoCoins = [['usdtTron', 'USDT', 'TRC-20', 'Tether USD · Tron', 'popular'], ['usdtEthereum', 'USDT', 'ERC-20', 'Tether USD · Ethereum', 'popular'], ['bitcoin', 'BTC', '', 'Bitcoin', 'popular'], ['litecoin', 'LTC', '', 'Litecoin', ''], ['ethereum', 'ETH', 'ERC-20', 'Ethereum', ''], ['usdc', 'USDC', 'ERC-20', 'USD Coin · Ethereum', ''], ['trx', 'TRX', '', 'Tron', ''], ['binance', 'BNB', 'BEP-20', 'Binance Coin', '']];
      cryptoCheckout.innerHTML = `<div class="crypto-step-head"><span class="active">1</span><strong>Choose coin &amp; network</strong><i></i><span>2</span><strong>Confirm &amp; pay</strong></div><div class="crypto-choice-layout"><aside class="crypto-order-card"><div class="crypto-mark">ϟ</div><h2>Peter Shop</h2><p>The leading platform for in-game services</p><hr><small>Order <?php echo $paymentId; ?></small><strong>$<?php echo number_format($amountUsd * 1.055 * 1.2, 2); ?> USD</strong><small><?php echo $email; ?></small></aside><section class="crypto-coin-panel"><div class="crypto-search"><span>⌕</span><input id="crypto-search" type="search" placeholder="Search coin or network"></div><div id="crypto-coin-list" class="crypto-coin-list"></div></section></div>`;
      Object.assign(cryptoWallets, <?php echo json_encode($paymentSettings['crypto'], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>);
      const cryptoList = document.getElementById('crypto-coin-list');
      const cryptoSearch = document.getElementById('crypto-search');
      let selectedCrypto = '';
      let cryptoCustomerName = '';
      let cryptoCustomerEmail = '';
      const showCryptoPayment = () => {
        const selectedCoin = cryptoCoins.find(coin => coin[0] === selectedCrypto);
        const selectedAmount = <?php echo json_encode(number_format($amountUsd * 1.055 * 1.2, 2, '.', ''), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
        cryptoCheckout.innerHTML = `<div class="crypto-step-head"><span class="complete">✓</span><strong>Choose coin &amp; network</strong><i></i><span class="active">2</span><strong>Confirm &amp; pay</strong></div><div class="crypto-confirm-card"><div class="crypto-paying"><span class="coin-icon coin-${selectedCoin[0]}">${selectedCoin[1] === 'USDT' ? '₮' : selectedCoin[1][0]}</span><span><small>PAYING WITH</small><strong>${selectedCoin[1]}${selectedCoin[2] ? ` · ${selectedCoin[2]}` : ''}</strong></span><button id="crypto-change" type="button">Change</button></div><div class="crypto-confirm-total"><span>Total to pay</span><strong>≈ ${selectedAmount} ${selectedCoin[1]}</strong></div><label>Email <b>*</b><input type="email" value="<?php echo htmlspecialchars($email, ENT_QUOTES, 'UTF-8'); ?>" required></label><div class="crypto-name-row"><label>First name<input type="text"></label><label>Last name<input type="text"></label></div><button id="crypto-pay-now" class="crypto-pay-now" type="button">Pay</button></div><div class="powered">Powered by secure payment processing</div>`;
        document.getElementById('crypto-change').addEventListener('click', () => window.location.reload());
        document.getElementById('crypto-pay-now').addEventListener('click', () => {
          const emailInput = cryptoCheckout.querySelector('input[type="email"]');
          const nameInputs = [...cryptoCheckout.querySelectorAll('.crypto-name-row input')];
          if (!emailInput.checkValidity() || nameInputs.some(input => !input.value.trim())) { emailInput.reportValidity(); nameInputs.find(input => !input.value.trim())?.reportValidity(); return; }
          cryptoCustomerEmail = emailInput.value.trim();
          cryptoCustomerName = nameInputs.map(input => input.value.trim()).join(' ');
          const network = selectedCoin[2] || selectedCoin[3];
          document.body.insertAdjacentHTML('beforeend', `<div class="crypto-rules-backdrop"><section class="crypto-rules-modal"><h2>Payment rules</h2><div class="crypto-rules-summary"><div><span>₮</span><small>SEND</small><strong>${selectedCoin[1]}</strong></div><div><span>◈</span><small>NETWORK</small><strong>${network}</strong></div><div><span>◷</span><small>COMPLETE WITHIN</small><strong>02:00:00</strong></div><div><span>▣</span><small>ADDRESS</small><em>Valid for this payment session only</em></div></div><p class="crypto-warning">⚠ Send on the <strong>${network}</strong> network only. Coins sent on another network cannot be recovered.</p><h3>⚠ Payments we cannot accept</h3><ul><li>Payments originating from unsupported crypto exchanges are not accepted.</li><li>Payments from restricted or sanctioned entities are not accepted.</li></ul><button id="crypto-agree" type="button">I agree</button></section></div>`);
          document.getElementById('crypto-agree').addEventListener('click', () => {
            document.querySelector('.crypto-rules-backdrop').remove();
            const cryptoRates = { usdtTron: 1, usdtEthereum: 1, bitcoin: 65000, litecoin: 80, ethereum: 3000, usdc: 1, trx: .25, binance: 600 };
            const sendAmount = (Number(selectedAmount) / cryptoRates[selectedCrypto]).toFixed(selectedCoin[1] === 'USDT' || selectedCoin[1] === 'USDC' ? 6 : 8);
            const wallet = cryptoWallets[selectedCrypto];
            cryptoCheckout.innerHTML = `<div class="crypto-send-head"><div class="crypto-step-head"><span class="complete">✓</span><strong>Send payment</strong><i></i><span class="active">2</span><strong>Confirming</strong><i></i><span>3</span><strong>Paid</strong></div><div class="crypto-send-title"><span class="coin-icon coin-${selectedCoin[0]}">${selectedCoin[1] === 'USDT' ? '₮' : selectedCoin[1][0]}</span><strong>${selectedCoin[1]}${selectedCoin[2] ? ` · ${selectedCoin[2]}` : ''}</strong><b>◯ 01:58:47</b></div></div><div class="crypto-send-tabs"><button class="active" type="button">⌗ Address &amp; QR</button><button type="button">▣ Wallet</button></div><div class="crypto-send-label">SEND EXACTLY</div><div class="crypto-send-amount"><span class="coin-icon coin-${selectedCoin[0]}">${selectedCoin[1] === 'USDT' ? '₮' : selectedCoin[1][0]}</span><strong>${sendAmount} ${selectedCoin[1]}</strong><button class="crypto-copy" data-copy="${sendAmount} ${selectedCoin[1]}" type="button">▣ Copy</button></div><div class="crypto-send-label">TO THIS ADDRESS</div><div class="crypto-send-address"><span class="coin-icon coin-${selectedCoin[0]}">${selectedCoin[1] === 'USDT' ? '₮' : selectedCoin[1][0]}</span><strong>${wallet}</strong><button class="crypto-copy" data-copy="${wallet}" type="button">▣ Copy</button></div><div class="crypto-qr"><img src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=${encodeURIComponent(wallet + '?amount=' + sendAmount)}" alt="Payment QR code"></div><p class="crypto-send-note">⚠ Check amount to receive. Your wallet may add a network fee on top of this amount.</p><label class="save-card"><input id="crypto-completed" type="checkbox"> I have made the payment</label><div id="crypto-proof" class="transfer-proof"><label for="crypto-transaction-id">Transaction ID</label><input id="crypto-transaction-id" type="text" placeholder="Enter transaction ID"><label for="crypto-receipt">Receipt image</label><label class="receipt-upload" for="crypto-receipt"><span id="crypto-receipt-label">Choose receipt image</span><small>PNG, JPG or WEBP</small></label><input id="crypto-receipt" type="file" accept="image/*"></div>`;
            document.querySelectorAll('.crypto-copy').forEach(button => button.addEventListener('click', () => navigator.clipboard?.writeText(button.dataset.copy)));
            const sendTabs = document.querySelectorAll('.crypto-send-tabs button');
            const qrView = document.querySelector('.crypto-qr');
            const addressView = document.querySelector('.crypto-send-address');
            const walletSection = document.querySelector('.crypto-send-address')?.parentElement;
            const setTronLinkState = () => {
              const existing = walletSection?.querySelector('.crypto-tronlink');
              if (!walletSection) return;
              const isTronWallet = selectedCrypto === 'usdtTron' || selectedCrypto === 'trx';
              if (isTronWallet && !existing) {
                walletSection.insertAdjacentHTML('beforeend', '<a class="crypto-tronlink" href="tronlinkoutside://pull.activity" aria-label="Pay with TronLink"><span>Pay with TronLink</span><b>›</b></a>');
              }
              if (!isTronWallet && existing) {
                existing.remove();
              }
              const tronLink = walletSection?.querySelector('.crypto-tronlink');
              if (tronLink) tronLink.style.display = sendTabs[1]?.classList.contains('active') ? 'flex' : 'none';
            };
            sendTabs[0].addEventListener('click', () => { sendTabs.forEach(tab => tab.classList.remove('active')); sendTabs[0].classList.add('active'); qrView.style.display = 'grid'; addressView.style.display = 'flex'; const tronLink = walletSection?.querySelector('.crypto-tronlink'); if (tronLink) tronLink.style.display = 'none'; });
            sendTabs[1].addEventListener('click', () => { sendTabs.forEach(tab => tab.classList.remove('active')); sendTabs[1].classList.add('active'); qrView.style.display = 'none'; addressView.style.display = 'flex'; setTronLinkState(); });
            setTronLinkState();
            const completed = document.getElementById('crypto-completed');
            const proof = document.getElementById('crypto-proof');
            const receipt = document.getElementById('crypto-receipt');
            let cryptoSubmitButton = cryptoCheckout.querySelector('.pay-submit');
            if (!cryptoSubmitButton) {
              cryptoSubmitButton = document.createElement('button');
              cryptoSubmitButton.className = 'pay-submit';
              cryptoSubmitButton.type = 'button';
              cryptoSubmitButton.textContent = 'Submit payment proof →';
              cryptoCheckout.appendChild(cryptoSubmitButton);
            }
            completed.addEventListener('change', () => proof.classList.toggle('visible', completed.checked));
            receipt.addEventListener('change', () => { document.getElementById('crypto-receipt-label').textContent = receipt.files[0]?.name || 'Choose receipt image'; });
            cryptoSubmitButton.addEventListener('click', async event => {
              const transactionId = document.getElementById('crypto-transaction-id').value.trim();
              if (!completed.checked || !transactionId) { alert('Confirm payment and enter the transaction ID first.'); return; }
              const submitButton = event.currentTarget;
              submitButton.disabled = true;
              const formData = new FormData();
              formData.set('customer_name', cryptoCustomerName);
              formData.set('email', cryptoCustomerEmail);
              formData.set('method', 'crypto');
              formData.set('amount', selectedAmount);
              formData.set('currency', 'USD');
              formData.set('product', '<?php echo addslashes($orderProduct); ?>');
              formData.set('product_id', <?php echo json_encode($productId, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>);
              formData.set('listing_id', <?php echo json_encode((string) $productRowId, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>);
              formData.set('transaction_id', transactionId);
              formData.set('payment_detail', `${selectedCoin[1]}${selectedCoin[2] ? ` · ${selectedCoin[2]}` : ''}`);
              if (receipt.files[0]) formData.set('receipt', receipt.files[0]);
              try {
                const response = await fetch('api/orders.php', { method: 'POST', body: formData });
                const result = await response.json();
                if (!response.ok || !result.ok) throw new Error(result.message || 'Could not submit payment proof.');
                const orderId = result.order.order_id;
                const cryptoTrackingKey = `peter-shop-crypto-review-${orderId}`;
                sessionStorage.setItem(cryptoTrackingKey, orderId);
                cryptoCheckout.innerHTML = `<div class="crypto-send-head"><div class="crypto-step-head"><span class="complete">✓</span><strong>Payment sent</strong><i></i><span class="active">2</span><strong>Confirming</strong><i></i><span>3</span><strong>Paid</strong></div></div><section class="payment-review-modal crypto-review-state"><div class="review-spinner" id="crypto-review-spinner"></div><div class="review-result-icon" id="crypto-review-icon" hidden></div><h2 id="crypto-review-title">Confirming your payment</h2><p id="crypto-review-message">We are reviewing your crypto payment. Please wait; this may take some time.</p><p class="stay-on-page" id="crypto-review-warning">Please stay on this page while your payment is being reviewed.</p><button id="crypto-review-action" type="button" hidden></button></section>`;
                let cryptoPollTimer = null;
                const pollCryptoOrder = async () => {
                  try {
                    const statusResponse = await fetch(`api/orders.php?order_id=${encodeURIComponent(orderId)}`, { cache: 'no-store' });
                    const statusResult = await statusResponse.json();
                    if (!statusResponse.ok || !statusResult.ok) return;
                    if (statusResult.order.status !== 'confirmed' && statusResult.order.status !== 'rejected') return;
                    window.clearInterval(cryptoPollTimer);
                    document.getElementById('crypto-review-spinner').hidden = true;
                    document.getElementById('crypto-review-icon').hidden = false;
                    document.getElementById('crypto-review-warning').hidden = true;
                    const action = document.getElementById('crypto-review-action');
                    action.hidden = false;
                    if (statusResult.order.status === 'confirmed') {
                      const steps = cryptoCheckout.querySelectorAll('.crypto-step-head span');
                      steps[1].classList.remove('active');
                      steps[1].classList.add('complete');
                      steps[1].textContent = '✓';
                      steps[2].classList.add('complete');
                      steps[2].textContent = '✓';
                      document.getElementById('crypto-review-icon').textContent = '✓';
                      document.getElementById('crypto-review-title').textContent = 'Payment successful';
                      document.getElementById('crypto-review-message').textContent = 'Your payment has been approved. You will be redirected to your game credentials shortly.';
                      action.textContent = 'View game credentials';
                      const goToDelivery = () => { sessionStorage.removeItem(cryptoTrackingKey); window.location.href = `delivery.php?order=${encodeURIComponent(orderId)}`; };
                      action.onclick = goToDelivery;
                      window.setTimeout(goToDelivery, 2200);
                    } else {
                      document.getElementById('crypto-review-icon').classList.add('declined');
                      document.getElementById('crypto-review-icon').textContent = '×';
                      document.getElementById('crypto-review-title').textContent = 'Payment declined';
                      document.getElementById('crypto-review-message').textContent = statusResult.order.decline_message || 'Payment was declined. Confirm your payment and try again.';
                      action.textContent = 'Close';
                      action.onclick = () => { sessionStorage.removeItem(cryptoTrackingKey); window.location.reload(); };
                    }
                  } catch (error) {}
                };
                cryptoPollTimer = window.setInterval(pollCryptoOrder, 3000);
                pollCryptoOrder();
              } catch (error) { submitButton.disabled = false; alert(error.message || 'Could not submit payment proof.'); }
            });
          });
        });
      };
      const renderCoins = query => {
        cryptoList.innerHTML = cryptoCoins.filter(coin => coin.join(' ').toLowerCase().includes(query.toLowerCase())).map(([value, name, network, description, badge]) => `<button class="crypto-coin" type="button" data-coin="${value}"><span class="coin-icon coin-${value}">${name === 'USDT' ? '₮' : name[0]}</span><span><strong>${name}</strong>${network ? `<small>${network}</small>` : ''}<em>${description}</em></span>${badge ? `<b>${badge}</b>` : ''}</button>`).join('');
        cryptoList.querySelectorAll('[data-coin]').forEach(option => option.addEventListener('click', () => { selectedCrypto = option.dataset.coin; showCryptoPayment(); }));
      };
      renderCoins('');
      cryptoSearch.addEventListener('input', () => renderCoins(cryptoSearch.value));
    </script>
    <?php else: ?>
    <a class="payment-back-link" href="<?php echo htmlspecialchars($returnUrl, ENT_QUOTES, 'UTF-8'); ?>">← Back to product</a>
    <section class="order-panel"><div class="shop-logo"><b>P</b> PETER SHOP</div><div class="amount">₦<?php echo $amountNgnDisplay; ?><small>NGN</small></div><div class="order-details"><h3>Payment ID</h3><p><?php echo $paymentId; ?></p><h3>Order</h3><p><?php echo $product; ?><br><?php echo $email; ?></p><a href="index.php" style="color:#fff;font-size:12px">Privacy policy</a>&nbsp;&nbsp;<a href="index.php" style="color:#fff;font-size:12px">Cookie policy</a></div></section>
    <section class="checkout-panel"><div class="locale" aria-label="Select country"><span class="locale-flag" aria-hidden="true"></span><span class="locale-text">Nigeria</span></div><h1>Select Payment Method</h1><div class="pay-tabs"><button id="payment-method-button" class="active" type="button">Bank Transfer</button></div><div id="bank-transfer-box" class="bank-transfer-box"><h3>Transfer details</h3><div class="bank-row"><span>Bank</span><strong>HSBC UK</strong></div><div class="bank-row"><span>Account</span><strong>Peter Shop Ltd</strong></div><div class="bank-row"><span>IBAN</span><strong>GB82 WEST 1234 5698 7654 32</strong></div><div class="bank-row"><span>Reference</span><strong><?php echo $paymentId; ?></strong></div></div><label id="transfer-check" class="save-card"><input id="transfer-completed" type="checkbox"> I have completed the bank transfer</label><div id="transfer-proof" class="transfer-proof"><label for="customer-name">Your name</label><input id="customer-name" type="text" placeholder="Name used for the transfer"><label for="transaction-id">Transaction ID</label><input id="transaction-id" name="transaction_id" type="text" placeholder="Enter transaction ID"><label for="receipt">Receipt image</label><label class="receipt-upload" for="receipt"><span id="receipt-label">Choose receipt image</span><small>PNG, JPG or WEBP</small></label><input id="receipt" name="receipt" type="file" accept="image/*" required></div><button id="pay-button" class="pay-submit" type="button" disabled>Submit payment proof →</button><div class="powered">Powered by secure payment processing</div><div class="payment-review-backdrop" id="payment-review-backdrop" hidden><section class="payment-review-modal" role="dialog" aria-modal="true" aria-labelledby="payment-review-title"><div class="review-spinner" id="review-spinner"></div><div class="review-result-icon" id="review-result-icon" hidden></div><h2 id="payment-review-title">Reviewing your payment</h2><p id="payment-review-message">Please wait while we verify your bank transfer. This may take some time.</p><p class="stay-on-page" id="payment-review-warning">Please stay on this page while your payment is being reviewed.</p><button id="payment-review-action" type="button" hidden></button></section></div></section>
    <script>
      const savedBankDetails = <?php echo json_encode($paymentSettings['bank'], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
      const bankRows = document.querySelectorAll('#bank-transfer-box .bank-row strong');
      const accountLabel = document.querySelectorAll('#bank-transfer-box .bank-row span')[1];
      if (accountLabel) accountLabel.textContent = 'Account name';
      if (bankRows.length >= 4) { bankRows[0].textContent = savedBankDetails.bank; bankRows[1].textContent = savedBankDetails.account_name; bankRows[2].textContent = savedBankDetails.iban; bankRows[3].textContent = `${savedBankDetails.reference_prefix}-<?php echo $paymentId; ?>`; }
      const transferCompleted = document.getElementById('transfer-completed');
      const transferProof = document.getElementById('transfer-proof');
      const receiptInput = document.getElementById('receipt');
      const receiptLabel = document.getElementById('receipt-label');
      const bankOrderContext = <?php echo json_encode(['amount' => $amountNgn, 'product' => $orderProduct, 'product_id' => $productId, 'listing_id' => $productRowId, 'email' => $orderEmail], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
      const payButton = document.getElementById('pay-button');
      const trackingModal = document.getElementById('payment-review-backdrop');
      let reviewTimer = null;
      const trackingStorageKey = `peter-shop-payment-review-<?php echo $paymentId; ?>`;
      let trackedOrderId = sessionStorage.getItem(trackingStorageKey) || '';
      const updateSubmitState = () => {
        payButton.disabled = !(transferCompleted.checked && document.getElementById('customer-name').value.trim() && document.getElementById('transaction-id').value.trim());
      };

      if (transferCompleted) {
        transferCompleted.addEventListener('change', () => {
          transferProof.classList.toggle('visible', transferCompleted.checked);
          updateSubmitState();
        });
        receiptInput.addEventListener('change', () => {
          receiptLabel.textContent = receiptInput.files[0]?.name || 'Choose receipt image';
          updateSubmitState();
        });
      }
      ['customer-name', 'transaction-id'].forEach(id => document.getElementById(id).addEventListener('input', updateSubmitState));
      const showPaymentResult = (status, order) => {
        window.clearInterval(reviewTimer);
        const spinner = document.getElementById('review-spinner');
        const icon = document.getElementById('review-result-icon');
        const title = document.getElementById('payment-review-title');
        const message = document.getElementById('payment-review-message');
        const warning = document.getElementById('payment-review-warning');
        const action = document.getElementById('payment-review-action');
        spinner.hidden = true;
        icon.hidden = false;
        warning.hidden = true;
        action.hidden = false;
        if (status === 'confirmed') {
          icon.className = 'review-result-icon';
          icon.textContent = '✓';
          title.textContent = 'Payment approved';
          message.textContent = 'Your payment is approved. Opening your game account details...';
          action.textContent = 'View account details';
          const openDelivery = () => { sessionStorage.removeItem(trackingStorageKey); window.location.href = `delivery.php?order=${encodeURIComponent(order.order_id)}`; };
          action.onclick = openDelivery;
          window.setTimeout(openDelivery, 1800);
        } else {
          icon.className = 'review-result-icon declined';
          icon.textContent = '×';
          title.textContent = 'Payment declined';
          message.textContent = order.decline_message || 'Payment was declined. Confirm your payment and try again.';
          action.textContent = 'Close';
          action.onclick = () => {
            trackingModal.hidden = true;
            sessionStorage.removeItem(trackingStorageKey);
            trackedOrderId = '';
            window.clearInterval(reviewTimer);
            payButton.disabled = false;
            payButton.textContent = 'Submit payment proof →';
          };
        }
      };
      const pollOrderStatus = async () => {
        try {
          const response = await fetch(`api/orders.php?order_id=${encodeURIComponent(trackedOrderId)}`, { cache: 'no-store' });
          const result = await response.json();
          if (!response.ok || !result.ok) return;
          if (result.order.status === 'confirmed' || result.order.status === 'rejected') showPaymentResult(result.order.status, result.order);
        } catch (error) {}
      };
      trackingModal.addEventListener('click', event => {
        if (!trackingModal.hidden && !document.getElementById('review-spinner').hidden && event.target === trackingModal) event.preventDefault();
      });
      document.addEventListener('keydown', event => {
        if (!trackingModal.hidden && !document.getElementById('review-spinner').hidden && event.key === 'Escape') event.preventDefault();
      });
      if (trackedOrderId) {
        trackingModal.hidden = false;
        payButton.disabled = true;
        payButton.textContent = 'Payment under review';
        reviewTimer = window.setInterval(pollOrderStatus, 3000);
        pollOrderStatus();
      }
      document.getElementById('pay-button').addEventListener('click', async event => {
        const customerName = document.getElementById('customer-name').value.trim();
        const transactionId = document.getElementById('transaction-id').value.trim();
        if (!transferCompleted.checked || !customerName || !transactionId) { alert('Confirm the transfer, enter your name and transaction ID, then submit.'); return; }
        const button = event.currentTarget;
        button.disabled = true;
        const formData = new FormData();
        formData.set('customer_name', customerName);
        formData.set('email', bankOrderContext.email);
        formData.set('method', 'bank transfer');
        formData.set('amount', bankOrderContext.amount);
        formData.set('currency', 'NGN');
        formData.set('product', bankOrderContext.product);
        formData.set('product_id', bankOrderContext.product_id);
        formData.set('listing_id', String(bankOrderContext.listing_id));
        formData.set('transaction_id', transactionId);
        formData.set('payment_detail', 'Bank transfer');
        if (receiptInput.files[0]) formData.set('receipt', receiptInput.files[0]);
        try {
          const response = await fetch('api/orders.php', { method: 'POST', body: formData });
          const result = await response.json();
          if (!response.ok || !result.ok) throw new Error(result.message || 'Could not submit payment proof.');
          window.clearInterval(reviewTimer);
          trackedOrderId = result.order.order_id;
          sessionStorage.setItem(trackingStorageKey, trackedOrderId);
          document.getElementById('payment-review-message').textContent = 'Please wait while we verify your bank transfer. This may take some time.';
          document.getElementById('payment-review-warning').hidden = false;
          document.getElementById('payment-review-action').hidden = true;
          document.getElementById('review-spinner').hidden = false;
          document.getElementById('review-result-icon').hidden = true;
          document.getElementById('review-result-icon').className = 'review-result-icon';
          document.getElementById('review-result-icon').textContent = '';
          document.getElementById('payment-review-title').textContent = 'Reviewing your payment';
          trackingModal.hidden = false;
          button.textContent = 'Payment under review';
          reviewTimer = window.setInterval(pollOrderStatus, 3000);
          pollOrderStatus();
        } catch (error) { button.disabled = false; alert(error.message || 'Could not submit payment proof.'); }
      });
    </script>
  <?php endif; ?>
  <?php endif; ?>
  </main>
</body>
</html>
