<?php
require_once __DIR__ . '/auth.php';
$returnUrl = 'exchange-rates.php';
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Live Forex chart | Peter Shop</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@500;600;700&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root { color-scheme:dark; --bg:#0d1112; --panel:#151b1d; --line:rgba(255,255,255,.09); --ink:#eef2ef; --muted:#91a0a1; --lime:#d8ff3e; --blue:#83d5e8; }
    * { box-sizing:border-box; }
    body { min-height:100vh; margin:0; background:var(--bg); color:var(--ink); font-family:'DM Sans',sans-serif; }
    .forex-shell { width:min(1440px,100%); margin:0 auto; padding:26px 24px 56px; }
    .forex-topbar { display:flex; align-items:center; justify-content:space-between; gap:20px; padding-bottom:20px; border-bottom:1px solid var(--line); }
    .forex-brand { display:flex; align-items:center; gap:10px; font:700 19px 'Barlow Condensed',sans-serif; }
    .brand-mark { display:grid; width:30px; height:30px; place-items:center; background:var(--lime); color:#101310; }
    .back-link { color:var(--muted); font-size:13px; font-weight:600; text-decoration:none; }
    .back-link:hover { color:var(--lime); }
    .forex-heading { display:flex; justify-content:space-between; align-items:end; gap:24px; margin:30px 0 20px; }
    .eyebrow { margin:0 0 7px; color:var(--blue); font-size:10px; font-weight:700; letter-spacing:.16em; }
    h1 { margin:0; font:600 38px 'Barlow Condensed',sans-serif; }
    .forex-heading p:last-child { margin:7px 0 0; color:var(--muted); font-size:13px; }
    .feed-note { max-width:350px; color:var(--muted); font-size:11px; line-height:1.5; text-align:right; }
    .market-section { margin-top:22px; }
    .market-section h2 { margin:0 0 12px; font:600 23px 'Barlow Condensed',sans-serif; }
    .market-frame { overflow:hidden; border:1px solid var(--line); border-radius:10px; background:var(--panel); }
    .chart-frame { height:min(72vh,760px); min-height:440px; }
    .cross-rates-frame { min-height:390px; }
    .tradingview-widget-container,.tradingview-widget-container__widget { width:100%; height:100%; }
    .tradingview-widget-copyright { padding:7px 10px; color:var(--muted); font-size:10px; }
    .tradingview-widget-copyright a { color:var(--blue); text-decoration:none; }
    .forex-disclaimer { margin:17px 0 0; color:var(--muted); font-size:11px; line-height:1.55; }
    @media(max-width:700px) {
      .forex-shell { padding:16px 12px 34px; }
      .forex-heading { align-items:flex-start; flex-direction:column; }
      .feed-note { text-align:left; }
      .chart-frame { height:65vh; min-height:420px; }
      .cross-rates-frame { min-height:500px; }
    }
  </style>
</head>
<body>
  <main class="forex-shell">
    <header class="forex-topbar"><div class="forex-brand"><span class="brand-mark">P</span><span>PETER SHOP</span></div><a class="back-link" href="<?= htmlspecialchars($returnUrl, ENT_QUOTES, 'UTF-8') ?>">← Back to exchange rates</a></header>
    <section class="forex-heading"><div><p class="eyebrow">FOREIGN EXCHANGE MARKETS</p><h1>Live Forex data</h1><p>USD/NGN candlesticks and live cross-rates from TradingView.</p></div><div class="feed-note">Feed: FX_IDC:USDNGN · Quotes update when the market data provider publishes them. Forex is not a 24/7 market.</div></section>

    <section class="market-section" aria-labelledby="usdngn-title">
      <h2 id="usdngn-title">U.S. Dollar / Nigerian Naira</h2>
      <div class="market-frame chart-frame">
        <div class="tradingview-widget-container">
          <div class="tradingview-widget-container__widget"></div>
          <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/USDNGN/?exchange=FX_IDC" target="_blank" rel="noopener noreferrer">USD/NGN chart</a><span> by TradingView</span></div>
        </div>
      </div>
    </section>

    <section class="market-section" aria-labelledby="cross-rates-title">
      <h2 id="cross-rates-title">Live currency cross-rates</h2>
      <div class="market-frame cross-rates-frame">
        <div class="tradingview-widget-container">
          <div class="tradingview-widget-container__widget"></div>
          <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/markets/currencies/rates-major/" target="_blank" rel="noopener noreferrer">Forex cross-rates</a><span> by TradingView</span></div>
        </div>
      </div>
    </section>

    <p class="forex-disclaimer">Forex quotes may be indicative or delayed depending on the selected TradingView feed and market hours. Candles reflect the selected symbol's published market data, not a guaranteed executable Peter Shop exchange rate. Cross-rates below are TradingView's supported currency matrix.</p>
  </main>
  <script src="forex-widgets.js?v=1"></script>
</body>
</html>