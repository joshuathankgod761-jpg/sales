(() => {
  const currencyCode = () => window.peterShopCurrency || localStorage.getItem('peter-shop-currency') || 'USD';
  const formatMoney = (amount, currency) => {
    if (currency === 'NGN') {
      return `₦${amount.toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }
    return new Intl.NumberFormat('en-US', { style: 'currency', currency }).format(amount);
  };
  const renderCheckout = () => {
    const card = document.querySelector('.checkout-card');
    if (!card) return;

    card.querySelector('label input[type="checkbox"]')?.closest('label')?.remove();
    const totalRow = card.querySelector('.checkout-total, [classname="checkout-total"]');
    if (totalRow) totalRow.className = 'checkout-total';
    const total = totalRow?.querySelector('strong');
    if (!total) return;

    const liveTotal = total.textContent;
    const amount = Number(liveTotal.replace(/[^0-9.-]/g, ''));
    if (!Number.isFinite(amount)) return;
    const currency = liveTotal.includes('₦') ? 'NGN' : currencyCode();
    const formattedTotal = formatMoney(amount, currency);
    if (total.textContent !== formattedTotal) total.textContent = formattedTotal;

    const cashback = card.querySelector('.checkout-cashback');
    if (cashback) cashback.textContent = `${formatMoney(amount * 0.036, currency)} cashback after purchase`;
  };

  renderCheckout();
  new MutationObserver(renderCheckout).observe(document.body, { childList: true, subtree: true });
})();
